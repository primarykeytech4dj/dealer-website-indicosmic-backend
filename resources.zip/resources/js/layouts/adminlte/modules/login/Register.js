import React, { Component } from 'react'

export default class Register extends Component {
    render() {
        return (
            <div>
                <h1>Register</h1>
            </div>
        )
    }
}