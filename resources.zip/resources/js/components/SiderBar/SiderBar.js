import React, { Component } from 'react'
import { slide as Menu } from 'react-burger-menu';
import "./SideBar.css"
export default class SiderBar extends Component {
    render() {
        return (
            <div>
                <Menu>
                    <a className="menu-item" href="/">
                        Home
                    </a>
                    <a className="menu-item" href="/salads">
                        Salads
                    </a>
                    <a className="menu-item" href="/pizzas">
                        Pizzas
                    </a>
                    <a className="menu-item" href="/desserts">
                        Desserts
                    </a>
                </Menu>
            </div>
        )
    }
}
