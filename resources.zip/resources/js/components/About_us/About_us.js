import React from 'react'
import "../../../css/About_us.css"


function About_us() {
  return (
    <section class="hero_in general">
        <div class="wrapper">
            <div class="container">
                <h1 class="fadeInUp animated"><span></span>About Panagea</h1>
            </div>
        </div>
    </section>
  )
}

export default About_us