import  React, {useState} from 'react';


import Box  from '@mui/material/Box';
import TabContext from '@mui/lab/TabContext';
import { Tabs, Tab } from "@mui/material";
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

import  makeStyles  from "@mui/styles/makeStyles";

import AddPolicy from './AddPolicy/AddPolicy'
import PolicyDetails from './PolicyDetails/PolicyDetails'
import ClaimDetails from './ClaimDetails/ClaimDetails'
import DealersEstimation from './DealersEstimation/DealersEstimation'

import BreadCrumb from '../BreadCrumb/BreadCrumb'

import MetaAndTitle from '../../../MetaAndTitle'
import { constant } from 'lodash';

import withRouter from '../../../withRouter';




 class AddClaim extends React.Component {

  constructor(props){
    super(props)
    this.state = {
      value : this.props.location.state ? this.props.location.state.value : '3',
      policyNo : this.props.policyNo ? this.props.policyNo : null,
      claimCode : null,
      details :  this.props.location.state ? this.props.location.state.details : null,
    }
  }
  

  render(){


    console.log("Location ",this.props.location)
    // const [value, setValue] = useState('1');
    const handleChange = (event, value) => {
      this.setState({value: value});
    };

    
  //  var temp = null;
  const handleNavigation = (data) => {
    // this.setState(param => ({...param ,details: {...data.details}}))
   // console.log("addclaimdata==>",data.details.form_step )
 
    
    this.setState({...data})
    const step=data.details.form_step
    let stepnew= step.slice(5)
    this.setState({value:stepnew})
   // console.log("newsplit==>",stepnew)
    //console.log("=====",this.state);
   }

   console.log("=====",this.state)
  return (
    <>
    <MetaAndTitle/>
      <BreadCrumb breadcrumb="Claim List" breadcrumbItem1='Claim Information' />
      <Box sx={{ width: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px" }}>


        <TabContext value={this.state.value}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={this.state.value} aria-label="Add Claim"  variant={"scrollable"}
            scrollButtons={"auto"} >
 
                    <Tab label={<b>Add Policy</b>} value="1" />
                    <Tab label={<b>Policy Details</b>} value="2" />
                    <Tab label={<b>Claim Details</b>} value="3" />
                    <Tab label={<b>Dealer Estimation</b>} value="4" />
                    {(this.state.value === '5')?
                    <Tab label={<b>Additional Claim</b>} value="5" />
                     : ''}
                </Tabs>
          </Box>
          <TabPanel value="1"><AddPolicy title="Add Policy" func={handleNavigation} /></TabPanel>
          <TabPanel value="2"><PolicyDetails title="Policy Details" func={handleNavigation} data={this.state} /></TabPanel>
          <TabPanel value="3"><ClaimDetails title="Claim Details" func={handleNavigation} data={this.state} /></TabPanel>
          <TabPanel value="4"><DealersEstimation title="Dealer Estimation" func={handleNavigation} type={"claim"} data={this.state}/></TabPanel>
          <TabPanel value="5"><DealersEstimation title="Additional Claim" func={handleNavigation} type={"additional claim"} data={this.state}/></TabPanel>
        </TabContext>

      </Box>
    </>
  )
  }
}

const useTabStyles = makeStyles({
  root: {
    justifyContent: "center"
  },
  scroller: {
    flexGrow: "0"
  }
  
});

export default withRouter(AddClaim)