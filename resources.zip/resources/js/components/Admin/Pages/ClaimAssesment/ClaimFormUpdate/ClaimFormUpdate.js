import React from 'react'

import Box  from '@mui/material/Box';


import MaterialTextField from '../../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../../Tags/MaterialTextArea'
import {CommonPolicyDetail} from '../ClaimIntimation/ClaimIntimation'
import {CommonDriverDetails} from '../../ClaimDetails/ClaimDetails'
export default function ClaimFormUpdate(props) {
    const YesNo = {"1":"Yes","0":"No"};

    const [state, setState] = React.useState({
        details: ''
    })
    const [value, setValue] = React.useState({
        params:{claim_details: props.details}
    });
    const handleChange = (e) => {
        setValue(param => ({...param , params:{...param.params, claim_details : { ...param.params.claim_details,[e.target.name]: e.target.value } }}))
        console.log(value.params.claim_details)
        // props.func({ details: value.params.claim_details});
    }

    const handleCommonDriverDetails = (data) => {
        setValue(param => ({...param , params:{...param.params, claim_details : { ...param.params.claim_details, ...data.details } }}))
        // setState(param =>({...param,  details:{ ...param.details , ...data.details}}))
    }

    const handleCommonPolicyDetails = (data) => {
        setValue(param => ({...param , params:{...param.params, claim_details : { ...param.params.claim_details, ...data.details } }}))
        // setState(param =>({...param,  details:{ ...param.details , ...data.details}}))
    }
  return (
    <>
        <div className="row ml-1">
            <label><b>{props.title}</b></label>
        </div>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <div className="row">
                {/* <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={YesNo}  
                    label="Wait For Dealer Estimation" 
                    name="wait_for_dealer_estimation" 
                    value={value.params.claim_details.wait_for_dealer_estimation ? value.params.claim_details.wait_for_dealer_estimation : ''}
                    value={value.params.claim_details.driver_name ? value.params.claim_details.driver_name : props.details.driver_name} 
                    defaultValue={value.params.claim_details.driver_name ? value.params.claim_details.driver_name : props.details.driver_name} 
                    onChange={(e)=>handleChange(e)} 
                    id="wait_for_dealer_estimation" />
                </div> */}
                <CommonPolicyDetail  func={handleCommonPolicyDetails} {...props} data={{details: props.details, claimCode : props.claim_code}} />
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={YesNo} 
                    label="Has Accident Been Reported To Police" 
                    name="accident_reported_to_police"
                    value={value.params.claim_details.accident_reported_to_police ? value.params.claim_details.accident_reported_to_police : props.details.accident_reported_to_police} 
                  
                    
                    onChange={(e)=>handleChange(e)}
                    id="accident_reported_to_police" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={YesNo} 
                    label="Has Punchnama Been Carried Out" 
                    name="punchnam_carried_out"
                
                    value={value.params.claim_details.punchnam_carried_out ? value.params.claim_details.punchnam_carried_out : props.details.punchnam_carried_out} 
                   
                    onChange={(e)=>handleChange(e)}
                    id="punchnam_carried_out" />
                </div>

                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={YesNo} 
                    label="Injury to Driver/Occupant(if any)" 
                    name="injury_to_driver"

                    value={value.params.claim_details.injury_to_driver ? value.params.claim_details.injury_to_driver : props.details.injury_to_driver} 
                
                    onChange={(e)=>handleChange(e)}
                    id="injury_to_driver" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={YesNo} 
                    label="Was any Third Party involved in accident" 
                    name="third_party_invloved"

                    value={value.params.claim_details.third_party_invloved ? value.params.claim_details.third_party_invloved : props.details.third_party_invloved} 
                   
                    onChange={(e)=>handleChange(e)}
                    id="third_party_invloved" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={YesNo} 
                    label="Particulars of Third Party Injury/Loss" 
                    name="third_party_injury"
                    value={value.params.claim_details.third_party_injury ? value.params.claim_details.third_party_injury : props.details.third_party_injury} 
               
                    onChange={(e)=>handleChange(e)}
                    id="third_party_injury" />
                </div>
            </div>
            
        </Box>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
           <CommonDriverDetails func={handleCommonDriverDetails} {...props}  data={{details: props.details, claimCode : props.claim_code}} />
        </Box>
        <div className="row">
            <div className="col-md-12 mt-4">
                <MaterialButton  name="submit"  className="center" text="Submit" />
            </div>
        </div>
    </>
  )
}
