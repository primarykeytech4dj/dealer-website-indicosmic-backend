import React from 'react'

export default function DealerStatus(props) {
  return (
    <>
        <div className="row ml-1">
            <h2 className="float-right">{props.title}</h2>
        </div>
        <div className="row mt-4">
            <div className="col-md-6">
                <label>Claim Number: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Clm 12345</label><br></br>
                <label>Claim Status: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Completed</label>
            </div>
        </div>
    </>
  )
}
