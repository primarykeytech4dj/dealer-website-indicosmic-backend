import React from 'react'

import Box  from '@mui/material/Box';

import ImageBar from '../../../../../Tags/ImageBar'
import InspectionData from './InspectionData.json'
import Api from '../../../../../api';
export default class VehicleInspection extends React.Component{
    constructor(props) {
        super(props);
        this.apiCtrl = new Api;
        this.state = {
            claim_code : props.claim_code ? props.claim_code : 'n5xVhBYoBXbm',
            data : null,
            isLoading: false,
        

        }
    }

    componentWillMount = () => {
        this.getInspectionList();
       
        
      }

      getInspectionList = () =>{
          if(this.state.claim_code !== null){    
            this.setState(old => ({...old, isLoading:true}))
            this.apiCtrl.callAxios('inspection_detail_list', {claim_code : this.state.claim_code }).then(response => {
                console.log(response);
                
                if(response.success == true){
                    this.setState(old => ({...old, data:response.data.aaData}))
        
                } else {
                    alert("No Data Available")
                }
                this.setState(old => ({...old, isLoading:false}))
                // sessionStorage.setItem('_token', response.data.)
                
            }).catch(function (error) {
                this.setState(old => ({...old, isLoading:false}))
                console.log(error);
            });
        } else {
            alert('Claim Code not found');
        }
        
      }


    render(){

    // const temp = {data-txt:1,data-label:2,data-src:3};
        return (
            <>

            {/* <div className="row ml-1">
                    <label><b style={{color:"black", fontSize:"25px"}}>{props.title}</b></label>
                </div> */}
                <Box >
                    <div className="row">
                        { 
                          ( this.state.data !== null) ?
                            this.state.data.map((value, key)=>{
                                return(
                                    <div className="col-md-4 mb-4"  key={key} >
                                        <ImageBar zoomId={key} imgAlt={value.category} id={key} imgSrc={value.image} {...value} />
                                    </div>

                                )
                            })
                            :
                            <div className="col-md-12 "  >
                                <span>No Images Found</span>  
                            </div>
                        }
                    </div>
                </Box>
            </>
        )
    }
}
