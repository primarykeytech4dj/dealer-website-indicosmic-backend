import React from 'react'

import Box  from '@mui/material/Box';

import DatePicker from '../../../../../Tags/DatePicker'
import MaterialTextField from '../../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../../Tags/MaterialTextArea'
import ReviewImages from '../../ReviewImages/ReviewImages';

 import EditDealerEstimation from '../../DealersEstimation/EditDealerEstimation'
function CommonAmountRemarkSection(props) {
    const [state, setState] = React.useState({
        dealerAmount:props.dealerAmount,
        dealerRemark:props.dealerAmount,
        assessorAmount:props.assessorAmount,
        assessorRemark:props.assessorRemark

    });
    const handleChange = (e) => {
        setState(preState => ({
            ...preState,[e.target.name]: e.target.value
            }))
      };

    return(
        <>
            <div className="row mb-4">
                <div className="col-md-3 mb-2">
                    <MaterialTextField fullWidth value={props.subcategory} label="Sub Category Name" disabled id="wheel-rim-lhs-fr" />
                </div>
                <div className="col-md-2 mb-2">
                    <MaterialTextField onChange={handleChange}  fullWidth value={state.dealerAmount} defaultValue={props.dealerAmount} label="Dealer Amount" name="dealerAmount"  id="dealer-amount" />
                </div>
                <div className="col-md-2 mb-2">
                    <MaterialTextField onChange={handleChange} fullWidth value={state.dealerRemark} defaultValue={props.dealerRemark} label="Dealer Remark" name="dealerRemark"  id="dealer-remark" />
                </div>
                <div className="col-md-2 mb-2">
                    <MaterialTextField onChange={handleChange} fullWidth value={state.assessorAmount} defaultValue={props.assessorAmount} label="Assessor Amount" name="assessorAmount"  id="assessor-amount" />
                </div>
                <div className="col-md-2 mb-2">
                    <MaterialTextField onChange={handleChange} fullWidth value={state.assessorRemark} defaultValue={props.assessorRemark} label="Assessor Remark" name="assessorRemark"  id="assessor-remark"/>
                </div>
            </div>
        </>
    )
}

function CommonTotalGSTGrandTotalAmount(){


    return(
        <>
               <div className="row">
                <div className="col-md-3 mb-2">
                    <MaterialTextField   fullWidth label="Total" disabled id="total" />
                </div>
                <div className="col-md-4 mb-2">
                    <MaterialTextField fullWidth label="Dealer Total Amount" name="dealer-total-amount"  id="dealer-total-amount" />
                </div>
          
                <div className="col-md-4 mb-2">
                    <MaterialTextField fullWidth label="Assessor Total Amount" name="assessor-total-amount"  id="assessor-total-amount" />
                </div>
              
            </div>
            <div className="row">
                <div className="col-md-3 mb-2">
                    <MaterialTextField  fullWidth label="Add GST @ 18%" disabled id="total" />
                </div>
                <div className="col-md-4 mb-2">
                    <MaterialTextField fullWidth label="Dealer GST Amount" name="dealer-gst-amount"  id="dealer-gst-amount" />
                </div>
          
                <div className="col-md-4 mb-2">
                    <MaterialTextField fullWidth label="Assessor GST Amount" name="assessor-gst-amount"  id="assessor-gst-amount" />
                </div>
              
            </div>
            <div className="row">
                <div className="col-md-3 mb-2">
                    <MaterialTextField disabled  fullWidth label="Grand Total"  id="total" />
                </div>
                <div className="col-md-4 mb-2">
                    <MaterialTextField fullWidth label="Dealer Grand Total Amount" name="dealer-grand-total-amount"  id="dealer-grand-total-amount" />
                </div>
          
                <div className="col-md-4 mb-2">
                    <MaterialTextField fullWidth label="Assessor Grand Total Amount" name="assessor-grand-total-amount"  id="assessor-grand-total-amount" />
                </div>
              
            </div>
            </>
    )
}

function Actions(props){
    if(props.name === "pending"){
        return(
           <>
            <div className="col-md-12 mt-4 d-flex" style={{justifyContent: "center"}}>
                <MaterialButton  name="next"  className="float-center" text="Next" />
            </div>
           
           </>
        );
    }else if(props.name === "assessment") {
        return(
            <>
                 <div className="col-md-12 mt-4">
                    <MaterialButton  name="submit"  className="float-center" text="Submit" />
                </div>
            </>
        );
    } else if(props.name === "assessment-update") {
        return(
            <>
                <div className="col-md-6 mt-4">
                    <MaterialButton  name="Accept" color="success" text="Accept" />
                </div>
                <div className="col-md-6 mt-4">
                    <MaterialButton  name="decline" color="warning" className="float-right" text="Decline" />
                </div>
            </>
        );
    } else {
        return true;
    }
   
}

export default function Assesment(props) {
    if(props.name === "pending"){
        return (
            <>
            {/* <div className="row ml-1">
                    <label><b style={{color:"black", fontSize:"25px"}}>{props.title}</b></label>
                </div> */}
      
                <Box sx={{ borderBottom: 1, borderColor: 'divider', marginBottom:"20px" }}>
                    <EditDealerEstimation claimCode={props.claim_code} assessment_id={props.assessment_id} />
         
                </Box>

                
                <div className="row">

            
                <Actions name={props.name ? props.name : ''} />
                </div>

            
            </>
        )
        } else {
            return (
                <>
                {/* <div className="row ml-1">
                        <label><b style={{color:"black", fontSize:"25px"}}>{props.title}</b></label>
                    </div> */}
                    <ReviewImages data={props.data} title="Photo:- Agent Review Images"/>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider', marginBottom:"20px" }}>
  
                        <div className="row">
                            <label style={{marginLeft:"1.4em", marginBottom:"1.6em"}}><b>Metal</b></label>
                        </div>
                
                        
                            <CommonAmountRemarkSection subcategory="Wheel Rim LHS FR" dealerAmount="1000" dealerRemark="Replacement"  assessorAmount="1000" assessorRemark="Replacement"  />
                            <CommonTotalGSTGrandTotalAmount />
                
    
                    </Box>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider', marginBottom:"20px" }}>
                    <div className="row">
                            <label style={{marginLeft:"1.4em", marginBottom:"1.6em"}}><b>Labour Charges</b></label>
                        </div>
                
                        <CommonAmountRemarkSection subcategory="Tie Rod End LHS" dealerAmount="6603" dealerRemark="Repair"  assessorAmount="6642" assessorRemark="Replacement" />
                        <CommonAmountRemarkSection subcategory="Resonator Box" dealerAmount="2323" dealerRemark="Repair"  assessorAmount="34232" assessorRemark="Replacement" />
                        <CommonAmountRemarkSection subcategory="W/s Glass Laminated FR" dealerAmount="3323" dealerRemark="Repair"  assessorAmount="23323" assessorRemark="Replacement" />
                        <CommonTotalGSTGrandTotalAmount />
                    </Box>
    
                    <Box sx={{ borderBottom: 1, borderColor: 'divider', marginBottom:"20px" }}>
                        <div className="row">
                            <label style={{marginLeft:"1.4em", marginBottom:"1.6em"}}><b>Summary of Estimate and Assessment of Loss</b></label>
                        </div>
                        <div className="row">
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Total Cost of Parts" disabled id="total-cost-parts" />
                            </div>
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Total Dealer Amount" name="total-dealer-amount"  id="total-dealer-amount" />
                            </div>
                    
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Total Assessor Amount" name="total-assessor-amount"  id="total-assessor-amount" />
                            </div>
                        
                        </div>
                        <div className="row">
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Net Labour Charges" disabled id="net-labour-charges" />
                            </div>
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Dealer Net Labour Charges" name="dealer-net-labour-charges"  id="dealer-net-labour-charges" />
                            </div>
                    
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Assessor Net Labour Charges" name="assessor-net-labour-charges"  id="assessor-net-labour-charges" />
                            </div>
                        
                        </div>
                        <div className="row">
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Total " disabled id="total" />
                            </div>
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Dealer Labour Charges" name="dealer-labour-charges"  id="dealer-labour-charges"  />
                            </div>
                    
                            <div className="col-md-4 mb-2">
                                <MaterialTextField fullWidth label="Assessor Labour Charges" name="assessor-labour-charges"  id="assessor-labour-charges" />
                            </div>
                        
                        </div>
                    </Box>
    
                    
                    <div className="row">
    
                
                    <Actions name={props.name ? props.name : ''} />
                    </div>
    
                
                </>
            )
        } 

}
