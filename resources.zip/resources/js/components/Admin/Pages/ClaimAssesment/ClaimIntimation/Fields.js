export const Fields = [{
            name:"policy-no",
            type:"TextField",
            label:"Policy No",
            id:"policy-no",
            className:""
        },
        {
            name:"claim-no",
            type:"TextField",
            label:"Claim No",
            id:"claim-no",
            className:""
        },
        {
            name:"date-of-accident",
            type:"DatePicker",
            label:"Date of Accident",
            id:"date-of-accident",
            className:""
        },
        {
            name:"time-of-accident",
            type:"TimePicker",
            label:"Time of Accident",
            id:"time-of-accident",
            className:""
        },
        {
            name:"place-of-accident",
            type:"TextField",
            label:"Place Of Accident",
            id:"place-of-accident",
            className:""
        },
        {
            name:"damage",
            type:"TextField",
            label:"Damage",
            id:"damage",
            className:""
        },
        {
            name:"initial-estimate",
            type:"TextField",
            label:"Initial Estimate",
            id:"initial-estimate",
            className:""
        },
        {
            name:"driver-name",
            type:"TextField",
            label:"Driver Name",
            id:"driver-name",
            className:""
        },
        {
            name:"towing",
            type:"Select",
            label:"Towing",
            id:"towing",
            className:""
        },
        {
            name:"assign-dealer-state",
            type:"Select",
            label:"Assign Dealer State",
            id:"assign-dealer-state",
            className:""
        },
        {
            name:"assign-dealer-city",
            type:"Select",
            label:"Assign Dealer City",
            id:"assign-dealer-city",
            className:""
        },
        {
            name:"assign-dealer-workshop",
            type:"Select",
            label:"Assign Dealer Workshop",
            id:"assign-dealer-workshop",
            className:""
        }
            
    ]
    