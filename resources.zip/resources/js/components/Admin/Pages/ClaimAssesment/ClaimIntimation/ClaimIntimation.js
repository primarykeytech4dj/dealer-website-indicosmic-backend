import React from 'react'

import Box  from '@mui/material/Box';

import DatePickers from '../../../../../Tags/DatePicker'
import MaterialTextField from '../../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../../Tags/MaterialTextArea'

import {Fields} from './Fields'


// function RenderSwitch(param){
//     const YesNo = ["Yes","No"];
//     console.log(param)
//     switch(param.data.type) {
//         case "TextField":
//             return(<><MaterialTextField fullWidth {...param.data} /></>
//                 );
//         case "Select":
//             return true;
//             // return(<> <MaterialSelect data={YesNo}  {...param}  fullWidth/></> )
//         case "DatePickers":
//             return(<> <DatePickers  {...param.data} fullWidth/></>);
//         case "TimePicker":
//             return(<><MaterialTimePicker  {...param.data}  fullWidth /></>)
//     }
// }


export class CommonPolicyDetail extends React.Component{
    constructor(props) {
        super(props);

        this.state = {
            policy : null,
            claim_code : this.props.claim_code,
            details : this.props.details ? this.props.details : '',

        }
    }
    render(){

        const handleChange = (e) => {
            this.setState(param => ({...param , details : { ...param.details,[e.target.name]: e.target.value } }))
            console.log(this.state.details)
            this.props.func({ details: this.state.details});
        }
        
        console.log('Claim Intimation1',this.state)
        console.log('Claim Intimation1 state',this.state)
        const States = {"Arunachal Pradesh": "Arunachal Pradesh","Assam": "Assam","Bihar": "Bihar","Chhattisgarh": "Chhattisgarh","Goa": "Goa","Gujarat": "Gujarat","Haryana": "Haryana","Himachal Pradesh": "Himachal Pradesh","Jammu and Kashmir": "Jammu and Kashmir","Jharkhand": "Jharkhand","Karnataka": "Karnataka","Kerala": "Kerala","Madhya Pradesh": "Madhya Pradesh","Maharashtra": "Maharashtra","Manipur": "Manipur","Meghalaya": "Meghalaya","Mizoram": "Mizoram","Nagaland": "Nagaland","Odisha": "Odisha","Punjab": "Punjab","Rajasthan": "Rajasthan","Sikkim": "Sikkim", "Tamil Nadu": "Tamil Nadu","Telangana": "Telangana","Tripura": "Tripura","Uttarakhand": "Uttarakhand","Uttar Pradesh": "Uttar Pradesh","West Bengal": "West Bengal","Andaman and Nicobar Islands": "Andaman and Nicobar Islands","Chandigarh": "Chandigarh","Dadra and Nagar Haveli": "Dadra and Nagar Haveli","Daman and Diu": "Daman and Diu","Delhi": "Delhi","Lakshadweep": "Lakshadweep","Puducherry": "Puducherry",};

        const City = {"Ahmednagar":'Ahmednagar',"Akola":'Akola', "Amravati":'Amravati',"Aurangabad":'Aurangabad',"Bhandara":'Bhandara',"Beed":'Beed',"Buldhana":'Buldhana',"Chandrapur":'Chandrapur',"Dhule":'Dhule',"Gadchiroli":'Gadchiroli',"Gondia":'Gondia',"Hingoli":'Hingoli',"Jalgaon":'Jalgaon',"Jalna":'Jalna',"Kolhapur":'Kolhapur',"Latur":'Latur',"Mumbai City":'Mumbai City',"Mumbai suburban":'Mumbai suburban',"Nandurbar":'Nandurbar',"Nanded":'Nanded',"Nagpur":'Nagpur',"Nashik":'Nashik',"Osmanabad":'Osmanabad',"Parbhani":'Parbhani',"Pune":'Pune',"Raigad":'Raigad',"Ratnagiri":'Ratnagiri',"Sindhudurg":'Sindhudurg',"Sangli":'Sangli',"Solapur":'Solapur',"Satara":'Satara',"Thane":'Thane',"Wardha":'Wardha',"Washim":'Washim',"Yavatmal":'Yavatmal',
        }
            const YesNo = {"1":"Yes","0":"No"};
            
        return(
            <>
            <div className="col-md-4 mb-4">
                    <MaterialTextField 
                     value={this.state.details.policy_id ? this.state.details.policy_id : this.props.details.policy_id} 
                    defaultValue={this.state.details.policy_id ? this.state.details.policy_id : this.props.details.policy_id} 
                    fullWidth 
                    onChange={(e)=>handleChange(e)}
                    label="Policy No" 
                    name="policy_id" 
                    id="policy_id" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    onChange={(e)=>handleChange(e)}
                    label="Claim No" 
                    name="claim_code" 
                     value={this.state.details.claim_code ? this.state.details.claim_code : this.props.details.claim_code} 
                    defaultValue={this.state.details.claim_code ? this.state.details.claim_code : this.props.details.claim_code} 
                    
                    id="claim_no" />
                </div>
                <div className="col-md-4 mb-4">
                    <DatePickers 
                    onChange={(e)=>handleChange(e)}
                    label="Date Of Accident" 
                    name="date_of_accident" 
                   
                     value={this.state.details.date_of_accident ? this.state.details.date_of_accident : this.props.details.date_of_accident} 
                    defaultValue={this.state.details.date_of_accident ? this.state.details.date_of_accident : this.props.details.date_of_accident} 
                    id="date_of_accident" fullWidth/> 
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTimePicker 
                    onChange={(e)=>handleChange(e)}
                    label="Time Of Accident" 
                    name="time_of_accident" 
                     value={this.state.details.time_of_accident ? this.state.details.time_of_accident : this.props.details.time_of_accident} 
                    defaultValue={this.state.details.time_of_accident ? this.state.details.time_of_accident : this.props.details.time_of_accident} 
                    id="time_of_accident"  fullWidth />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    onChange={(e)=>handleChange(e)}
                    label="Place Of Accident" 
                    name="place_of_accident" 
                     value={this.state.details.place_of_accident ? this.state.details.place_of_accident : this.props.details.place_of_accident} 
                    defaultValue={this.state.details.place_of_accident ? this.state.details.place_of_accident : this.props.details.place_of_accident} 
                    id="place_of_accident" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    onChange={(e)=>handleChange(e)}
                    label="Damage" 
                    name="damage" 
                     value={this.state.details.damage ? this.state.details.damage : this.props.details.damage} 
                    defaultValue={this.state.details.damage ? this.state.details.damage : this.props.details.damage} 
                    id="damage" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    onChange={(e)=>handleChange(e)}
                    label="Initial Estimate" 
                     value={this.state.details.initial_estimate ? this.state.details.initial_estimate : this.props.details.initial_estimate} 
                    defaultValue={this.state.details.initial_estimate ? this.state.details.initial_estimate : this.props.details.initial_estimate} 
                    name="initial_estimate" 
                    id="initial_estimate" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    onChange={(e)=>handleChange(e)}
                    label="Driver Name" 
                    name="driver_name" 
                     value={this.state.details.driver_name ? this.state.details.driver_name : this.props.details.driver_name} 
                    defaultValue={this.state.details.driver_name ? this.state.details.driver_name : this.props.details.driver_name} 
                    id="driver_name" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth  data={YesNo}  
                    onChange={(e)=>handleChange(e)}
                    label="Towing" 
                    name="towing" 
                     value={this.state.details.towing ? this.state.details.towing: this.props.details.towing} 
                  
                    id="towing" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={States} 
                    onChange={(e)=>handleChange(e)}
                    label="Assign Dealer State" 
                    name="assign_dealer_state" 
                    value={this.state.details.assign_dealer_state ? this.state.details.assign_dealer_state: this.props.details.assign_dealer_state} 
                  
                    id="assign_dealer_state" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={City} 
                    onChange={(e)=>handleChange(e)}
                    label="Assign Dealer City" 
                    name="assign_dealer_city" 
                    value={this.state.details.assign_dealer_city ? this.state.details.assign_dealer_city: this.props.details.assign_dealer_city} 
                  
                    id="assign_dealer_city" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect fullWidth data={['Nano','Mini','Mega']} 
                    onChange={(e)=>handleChange(e)}
                    label="Assign Dealer Workshop" 
                    name="assign_dealer_workshop" 
                    value={this.state.details.assign_dealer_workshop ? this.state.details.assign_dealer_workshop: this.props.details.assign_dealer_workshop} 
                   
                    id="assign_dealer_workshop" />
                </div>
            </>
        )
    }
}


export default class ClaimIntimation extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            policy : null,
            claim_code : this.props.claim_code,
            details : this.props.details ? this.props.details : {},
        }
    }


    render(){
        console.log('Claim Intimation',this.state)
        console.log('Claim Intimation state',this.state)
        return (
          <>
              <div className="row ml-1">
                {/* <i># {this.state.details.policy_id}</i> */}
                  <label><b>{this.props.title} </b></label>
              </div>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <div className="row">
                  <CommonPolicyDetail {...this.props}/>
                 
              </div>
              </Box>
              <div className="row">
                  <div className="col-md-12 mt-4">
                      <MaterialButton  
                      name="submit"  className="center" text="Submit" />
                  </div>
              </div>
          </>
        )
    }



}
