import React, { useState } from 'react'
import PropTypes from "prop-types";


import Box  from '@mui/material/Box';

import TabContext from '@mui/lab/TabContext';
import { Tabs, Tab } from "@mui/material";
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

import  makeStyles  from "@mui/styles/makeStyles";

import BreadCrumb from '../../BreadCrumb/BreadCrumb'

import MetaAndTitle from '../../../../MetaAndTitle'

import ClaimIntimation from './ClaimIntimation/ClaimIntimation'
import VehicleInspection from './VehicleInspection/VehicleInspection'
import Assesment from './Assesment/Assesment';
import AddPolicy from './AddPolicy/AddPolicy';
import ClaimFormUpdate from './ClaimFormUpdate/ClaimFormUpdate';
import ReviewImages from '../ReviewImages/ReviewImages';
import DealerStatus from './DealerStatus/DealerStatus';
import AssesmentReport from './AssesmentReport/AssesmentReport';

import Images from './VehicleInspection/InspectionData.json'
import Api from '../../../../api';

import withRouter from '../../../../withRouter';

const useTabStyles = makeStyles({
  root: {
    justifyContent: "center"
  },
  scroller: {
    flexGrow: "0"
  }
});

class ClaimAssesment extends React.Component {

  constructor(props){
    super(props);


    this.apiCtrl = new Api;
    this.state = {
      claim_code : this.props.location.state.claim_code ? this.props.location.state.claim_code : null,
      assessment_id : this.props.location.state.assessment_id ? this.props.location.state.assessment_id : null,
      details : '',
      value : '1',
    }
  }

  getClaimDetails = () => {
   
   

       this.apiCtrl.callAxios('get-claim-details', {claim_code: this.props.location.state.claim_code}).then(response => {

         if(response.success == true) {
        this.setState(old=>({...old, details: response.data}));
      } else {
        // alert('Some Error occured')

      }

      // console.log(response);
      // sessionStorage.setItem('_token', response.data.)
      // console.log('third ' + new Date() + '  ' + response)

    }).catch(function (error) {
      console.log(error);

    });
   
     
  
  }


  componentDidMount () {
    // console.log('first '+ new Date())
    this.getClaimDetails();
  }

 


  render(){

    console.log(this.state);
    

    const handleChange = (event, value) => {
      this.setState(old => ({...old, value: value}));
    };
    
    return (
      <>
          <MetaAndTitle/>
          <BreadCrumb breadcrumb="Assessor" breadcrumbItem1='Claim Assessment' />
          <Box sx={{ width: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px" }}>
  
        
                  
          <TabContext value={this.state.value}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={this.state.value} onChange={handleChange} aria-label="Claim Assessment"  variant={"scrollable"}
            scrollButtons={"auto"}>
              <Tab value="1" label={<b>Claim Intimation</b>} />
              <Tab value="2" label={<b>Add Policy</b>}/>
              <Tab value="3" label={<b>Claim Form Update</b>}/>
              <Tab value="4" label={<b>Assessment</b>}/>
              <Tab value="5" label={<b>Accident Image</b>}/>
              <Tab value="6" label={<b>Vehicle Inspection</b>}/>
              <Tab value="7" label={<b>Pending</b>}/>
              <Tab value="8" label={<b>Dealer Status</b>}/>
              <Tab value="9"  label={<b>Assesment Report</b>}/>
              <Tab value="10"  label={<b>Report Approval</b>}/>
          </Tabs>
          </Box>
          <TabPanel  value="1"><ClaimIntimation title="Claim Intimation" claim_code={this.state.claim_code} details={this.state.details}/></TabPanel> 
          <TabPanel value="2" ><AddPolicy title="Add Policy" claim_code={this.state.claim_code} details={this.state.details} /></TabPanel> 
          <TabPanel value="3" ><ClaimFormUpdate title="Update Claim Form" claim_code={this.state.claim_code} details={this.state.details}/></TabPanel> 
          <TabPanel value="4" ><Assesment title="Assessment" name="assessment" claim_code={this.state.claim_code} data={Images} assessment_id={this.state.assessment_id} /></TabPanel> 
          <TabPanel value="5" ><ReviewImages data={Images} claim_code={this.state.claim_code} title="Accident Images"/></TabPanel> 
          <TabPanel value="6" ><VehicleInspection title="Vehicle Inspection" claim_code={this.state.claim_code} /></TabPanel> 
          <TabPanel value="7" ><Assesment title="Pending" name="pending" claim_code={this.state.claim_code} data={Images} assessment_id={this.state.assessment_id} /></TabPanel> 
          <TabPanel value="8" ><DealerStatus title="Dealer Status" claim_code={this.state.claim_code}/></TabPanel> 
          <TabPanel value="9" ><AssesmentReport title="Assesment Report" claim_code={this.state.claim_code}/></TabPanel> 
          
          <TabPanel value="10" ></TabPanel> 
        </TabContext>
                          
          </Box>
      </>
    )
  }
}


export default withRouter(ClaimAssesment)