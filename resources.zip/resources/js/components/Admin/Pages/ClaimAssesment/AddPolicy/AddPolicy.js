import React from 'react'

import Box  from '@mui/material/Box';

import DatePickers from '../../../../../Tags/DatePicker'
import MaterialTextField from '../../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../../Tags/MaterialTextArea'

export default function AddPolicy(props) {

    const [state, setState] = React.useState({claim_details: props.details})

    const handleChange = (e) => {
        setState(param => ({...param , claim_details : { ...param.claim_details,[e.target.name]: e.target.value } }))
        // console.log(state.params.driver_details)
        props.func({ details: state.claim_details});
    }
  return (
    <>
        {/* <div className="row ml-1">
            <label><b>{props.title}</b></label>
        </div> */}

        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <div className="row ml-1">
                    <label><b>Policy Details</b></label>
                </div>
            <div className="row">
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Policy No" 
                      defaultValue={state.claim_details.policy_id ? state.claim_details.policy_id : props.details.policy_id}
                           onChange={(e)=>handleChange(e)}
                    name="policy_id" 
                    id="policy_id" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Insured Name" 
                      defaultValue={state.claim_details.insured_name ? state.claim_details.insured_name : props.details.insured_name}
                           onChange={(e)=>handleChange(e)}
                    name="insured_name" 
                    id="insured_name" />
                </div>
                <div className="col-md-4 mb-4">
                    <DatePickers fullWidth 
                    label="Period Of Insurance From Date" 
                      defaultValue={state.claim_details.policy_start_date ? state.claim_details.policy_start_date : props.details.policy_start_date}
                           onChange={(e)=>handleChange(e)}
                    name="policy_start_date" 
                    id="policy_start_date" /> 
                </div>
                <div className="col-md-4 mb-4">
                    <DatePickers fullWidth 
                    label="Period Of Insurance To Date" 
                      defaultValue={state.claim_details.policy_end_date ? state.claim_details.policy_end_date : props.details.policy_end_date}
                           onChange={(e)=>handleChange(e)}
                    name="policy_end_date" 
                    id="policy_end_date" /> 
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Mobile No." 
                      defaultValue={state.claim_details.insured_mobile_no ? state.claim_details.insured_mobile_no : props.details.insured_mobile_no}
                           onChange={(e)=>handleChange(e)}
                    name="insured_mobile_no" 
                    id="insured_mobile_no" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Email Id"
                      defaultValue={state.claim_details.insured_email_id ? state.claim_details.insured_email_id : props.details.insured_email_id}
                           onChange={(e)=>handleChange(e)}
                    
                    name="insured_email_id" 
                    id="insured_email_id" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Nominee Name" 
                      defaultValue={state.claim_details.insured_nominee_name ? state.claim_details.insured_nominee_name : props.details.insured_nominee_name}
                           onChange={(e)=>handleChange(e)}
                    name="insured_nominee_name" 
                    id="insured_nominee_name" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Hypothecation Lease" 
                      defaultValue={state.claim_details.hypothetion_lease ? state.claim_details.hypothetion_lease : props.details.hypothetion_lease}
                           onChange={(e)=>handleChange(e)}
                    name="hypothetion_lease" 
                    id="hypothetion_lease" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Insured Address" 
                      defaultValue={state.claim_details.insured_address1 ? state.claim_details.insured_address1 : props.details.insured_address1}
                           onChange={(e)=>handleChange(e)}
                    name="insured_address1" 
                    id="insured_address1" />
                </div>
            </div>
            </Box>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <div className="row mt-4 ml-1">
                <label><b>Vehicle Details</b></label>
            </div>
            <div className="row">
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Registration" 
                      defaultValue={state.claim_details.vehicle_registration_no ? state.claim_details.vehicle_registration_no : props.details.vehicle_registration_no}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_registration_no" 
                    id="vehicle_registration_no" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Product Type" 
                      defaultValue={state.claim_details.vehicle_product_type ? state.claim_details.vehicle_product_type : props.details.vehicle_product_type}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_product_type" 
                    id="vehicle_product_type" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Make" 
                      defaultValue={state.claim_details.vehicle_make ? state.claim_details.vehicle_make : props.details.vehicle_make}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_make" 
                    id="vehicle_make" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Model" 
                      defaultValue={state.claim_details.vehicle_model ? state.claim_details.vehicle_model : props.details.vehicle_model}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_model" 
                    id="vehicle_model" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Engine No" 
                      defaultValue={state.claim_details.vehicle_engine_no ? state.claim_details.vehicle_engine_no : props.details.vehicle_engine_no}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_engine_no" 
                    id="vehicle_engine_no" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Chassis No" 
                      defaultValue={state.claim_details.vehicle_chassis_no ? state.claim_details.vehicle_chassis_no : props.details.vehicle_chassis_no}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_chassis_no" 
                    id="vehicle_chassis_no" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Odometer Reading" 
                      defaultValue={state.claim_details.vehicle_odometer_reading ? state.claim_details.vehicle_odometer_reading : props.details.vehicle_odometer_reading}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_odometer_reading" 
                    id="vehicle_odometer_reading" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Fuel Type" 
                      defaultValue={state.claim_details.vehicle_fuel_type ? state.claim_details.vehicle_fuel_type : props.details.vehicle_fuel_type}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_fuel_type" 
                    id="vehicle_fuel_type" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Anti Theft Device Status" 
                      defaultValue={state.claim_details.anti_theft_device_status ? state.claim_details.anti_theft_device_status : props.details.anti_theft_device_status}
                           onChange={(e)=>handleChange(e)}
                    name="anti_theft_device_status" 
                    id="anti_theft_device_status" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="MFG Date" 
                      defaultValue={state.claim_details.vehicle_mfg_year ? state.claim_details.vehicle_mfg_year : props.details.vehicle_mfg_year}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_mfg_year" 
                    id="vehicle_mfg_year" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="CC/HP" 
                      defaultValue={state.claim_details.accident_reported_to_police ? state.claim_details.accident_reported_to_police : props.details.accident_reported_to_police}
                           onChange={(e)=>handleChange(e)}
                    name="cc_hp" 
                    id="cc_hp" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Seating Capacity" 
                      defaultValue={state.claim_details.vehicle_seating_capacity ? state.claim_details.vehicle_seating_capacity : props.details.vehicle_seating_capacity}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_seating_capacity" 
                    id="vehicle_seating_capacity" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Color" 
                      defaultValue={state.claim_details.vehicle_color ? state.claim_details.vehicle_color : props.details.vehicle_color}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_color" 
                    id="vehicle_color" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Type Of Body" 
                      defaultValue={state.claim_details.vehicle_type_of_body ? state.claim_details.vehicle_type_of_body : props.details.vehicle_type_of_body}
                           onChange={(e)=>handleChange(e)}
                    name="vehicle_type_of_body" 
                    id="vehicle_type_of_body" />
                </div>
                {/* <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="LPG/CNG" 
                      defaultValue={state.claim_details.accident_reported_to_police ? state.claim_details.accident_reported_to_police : props.details.accident_reported_to_police}
                           onChange={(e)=>handleChange(e)}
                    name="lpg_cng" 
                    id="lpg_cng" />
                </div> */}
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="NIL Depreciation" 
                      defaultValue={state.claim_details.nil_depreciation ? state.claim_details.nil_depreciation : props.details.nil_depreciation}
                           onChange={(e)=>handleChange(e)}
                    name="nil_depreciation" 
                    id="nil_depreciation" />
                </div>
            </div>
            </Box>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                
                <div className="row  mt-4 ml-1">
                    <label><b>Vehicle Insurance Details</b></label>
                </div>
            <div className="row ">
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Engine Protect" 
                      defaultValue={state.claim_details.engine_protect ? state.claim_details.engine_protect : props.details.engine_protect}
                           onChange={(e)=>handleChange(e)}
                    name="engine_protect" 
                    id="engine_protect" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="EMI Protect" 
                      defaultValue={state.claim_details.emi_protect ? state.claim_details.emi_protect : props.details.emi_protect}
                           onChange={(e)=>handleChange(e)}
                    name="emi_protect" 
                    id="emi_protect" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Type Cover" 
                      defaultValue={state.claim_details.tyre_cover ? state.claim_details.tyre_cover : props.details.tyre_cover}
                           onChange={(e)=>handleChange(e)}
                    name="tyre_cover" 
                    id="tyre_cover" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Total Cover" 
                      defaultValue={state.claim_details.total_cover ? state.claim_details.total_cover : props.details.total_cover}
                           onChange={(e)=>handleChange(e)}
                    name="total_cover" 
                    id="total_cover" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="Key Replacement" 
                      defaultValue={state.claim_details.key_replacement ? state.claim_details.key_replacement : props.details.key_replacement}
                           onChange={(e)=>handleChange(e)}
                    name="key_replacement" 
                    id="key_replacement" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    label="NCB Retention" 
                      defaultValue={state.claim_details.ncb_retention ? state.claim_details.ncb_retention : props.details.ncb_retention}
                           onChange={(e)=>handleChange(e)}
                    name="ncb_retention" 
                    id="ncb_retention" />
                </div>
            
            </div>
        </Box>

        <div className="row">
            <div className="col-md-12 mt-4">
                <MaterialButton  
                name="submit"  className="center" text="Submit" />
            </div>
        </div>
    </>
  )
}
