import React, { useRef } from 'react'
import {Table} from 'react-bootstrap';
import { useReactToPrint } from "react-to-print";
class ReportDocument extends React.Component{
  render() {
  return (
    <div style={{margin:"10px"}}>
    <h3>
    Report
    </h3>
     
    <Table bordered hover style={{borderWidth:1}}>
      <thead>
        <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Policy Number :12345</td>
        </tr>
        </thead>
        <tbody>
         <tr>
          <td colSpan={2}>Insured Name</td>
          <td colSpan={2}>ritesh</td>
          <td colSpan={4}>Period of Insurance</td>
          <td colSpan={4}>21-05-2018 to 21-05-2019</td>
        </tr>           
        <tr>
          <td colSpan={2}>Mobile Number</td>
          <td colSpan={2}>9004775596</td>
          <td colSpan={4}>Email-ID</td>
          <td colSpan={4}>rtuj@gmail.com</td>
        </tr>
        <tr>
          <td colSpan={2}>Nominee Name</td>
          <td colSpan={2}>turur</td>
          <td colSpan={4}>Hypothecation/Lease</td>
          <td colSpan={4}>test</td>
        </tr>
        <tr>
          <td colSpan={2}>Insured Address</td>
          <td colSpan={10}>Mumbai</td>
          
        </tr>
      </tbody>
      <br />
      <br />
       <thead>
        <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Insure Vehicle Details</td>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td colSpan={2}>Registration Number</td>
          <td colSpan={2}>MH 06 98</td>
          <td colSpan={4}>Mfg. Month & Year</td>
          <td colSpan={4}>21-05-2018</td>
        </tr>
     
        <tr>
          <td colSpan={2}>Make/Model</td>
          <td colSpan={2}>Maruti Ciaz</td>
          <td colSpan={4}>CC/HP</td>
          <td colSpan={4}>1200</td>
        </tr>
        <tr>
          <td colSpan={2}>Engine No</td>
          <td colSpan={2}>123123123132</td>
          <td colSpan={4}>Seating Capicy</td>
          <td colSpan={4}>4</td>
        </tr>
        <tr>
          <td colSpan={2}>Chasis No</td>
          <td colSpan={2}>6146356</td>
          <td colSpan={4}>Color</td>
          <td colSpan={4}>white</td>
        </tr>
        <tr>
          <td colSpan={2}>Odometer Reading</td>
          <td colSpan={2}>23652</td>
          <td colSpan={4}>Type of Body / LCC</td>
          <td colSpan={4}>Seden</td>
        </tr>
        <tr>
          <td colSpan={2}>Fuel Type</td>
          <td colSpan={2}>Petrol</td>
          <td colSpan={4}>Vehicle Fitted with LPG/CNG</td>
          <td colSpan={4}>no</td>
        </tr>
        <tr>
          <td colSpan={2}>Anti Theft Device Status</td>
          <td colSpan={2}>Yes</td>
          <td colSpan={4}> </td>
          <td colSpan={4}></td>
        </tr>
      </tbody>
      <br />
       <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Loss Assessment First Report</td>
        </tr>
        <br>
        </br>
        <thead>
        <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Metal</td>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td colSpan={2}>S. No</td>
          <td colSpan={2}>Description of Parts</td>
          <td colSpan={2}>Dealer Estimated (Amt in Rs.)</td>
          <td colSpan={2}>Dealer Remarks</td>
          <td colSpan={2}>Assessed (Amt in Rs.)</td>
          <td colSpan={2}>Remarks</td>
        </tr>
        <tr>
          <td colSpan={2}>1</td>
          <td colSpan={2}>Wheel Rim LHS FR</td>
          <td colSpan={2}>15400.00</td>
          <td colSpan={2}>replacement</td>
          <td colSpan={2}>1500.00</td>
          <td colSpan={2}>replacement</td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}>1200.00 </td>
          <td colSpan={4}>1500.00 </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Add GST @ 18% </td>
          <td colSpan={4}>216.00 </td>
          <td colSpan={4}>270.00 </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}>1416.00 </td>
          <td colSpan={4}>1770.00 </td>
        </tr>
      </tbody>
      <br />
      <thead>
        <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Rubber</td>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td colSpan={2}>S. No</td>
          <td colSpan={2}>Description of Parts</td>
          <td colSpan={2}>Dealer Estimated (Amt in Rs.)</td>
          <td colSpan={2}>Dealer Remarks</td>
          <td colSpan={2}>Assessed (Amt in Rs.)</td>
          <td colSpan={2}>Remarks</td>
        </tr>
       
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}>  </td>
          <td colSpan={4}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Add GST @ 18% </td>
          <td colSpan={4}> </td>
          <td colSpan={4}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}> </td>
          <td colSpan={4}> </td>
        </tr>
      </tbody>
      <br />
      <thead>
        <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Glass</td>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td colSpan={2}>S. No</td>
          <td colSpan={2}>Description of Parts</td>
          <td colSpan={2}>Dealer Estimated (Amt in Rs.)</td>
          <td colSpan={2}>Dealer Remarks</td>
          <td colSpan={2}>Assessed (Amt in Rs.)</td>
          <td colSpan={2}>Remarks</td>
        </tr>
       
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}>  </td>
          <td colSpan={4}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Add GST @ 18% </td>
          <td colSpan={4}> </td>
          <td colSpan={4}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}> </td>
          <td colSpan={4}> </td>
        </tr>
      </tbody>
      <br />
      <thead>
        <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Labour Charges</td>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td colSpan={2}>S. No</td>
          <td colSpan={2}>Description of Parts</td>
          <td colSpan={2}>Dealer Estimated (Amt in Rs.)</td>
          <td colSpan={2}>Dealer Remarks</td>
          <td colSpan={2}>Assessed (Amt in Rs.)</td>
          <td colSpan={2}>Remarks</td>
        </tr>
        <tr>
          <td colSpan={2}> 1 </td>
          <td colSpan={2}>Tie Rod End LHS</td>
          <td colSpan={2}>6661.00</td>
          <td colSpan={2}>repair</td>
          <td colSpan={2}>6500.00</td>
          <td colSpan={2}>repair</td>
        </tr>
        <tr>
          <td colSpan={2}> 2 </td>
          <td colSpan={2}>Resonator Box</td>
          <td colSpan={2}>3200.00</td>
          <td colSpan={2}>repair</td>
          <td colSpan={2}>640.00</td>
          <td colSpan={2}>repair</td>
        </tr>
        <tr>
          <td colSpan={2}> 3 </td>
          <td colSpan={2}>W/s Glass Leminated FR</td>
          <td colSpan={2}>6000.00</td>
          <td colSpan={2}>repair</td>
          <td colSpan={2}>5000.00</td>
          <td colSpan={2}>replacement</td>
        </tr>
        <tr>
          <td colSpan={2}> 4 </td>
          <td colSpan={2}>Tie Rod End LHS</td>
          <td colSpan={2}>1500.00</td>
          <td colSpan={2}>repair</td>
          <td colSpan={2}>0.00</td>
          <td colSpan={2}>reject</td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
          <td colSpan={2}> </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}> 12140.00 </td>
          <td colSpan={4}> 12140.00</td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Add GST @ 18% </td>
          <td colSpan={4}> 2185.20</td>
          <td colSpan={4}> 2185.20 </td>
        </tr>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={2}>Total </td>
          <td colSpan={4}> 14325.20 </td>
          <td colSpan={4}> 14325.20</td>
        </tr>
      </tbody>
      <br />
      <br />
      <thead>
        <tr  style={{backgroundColor:"#0FB2C9", color:"black",  fontWeight:"bold" }}>
        <td colSpan={12}>Summary of Estimate and Assessment of Loss</td>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td colSpan={2}> </td>
          <td colSpan={3}> </td>
          <td colSpan={3}>Estimated (Amt in Rs.)</td>
          <td colSpan={3}>Assessed (Amt in Rs.)</td>
          <td colSpan={1}> </td>
         </tr>
         <tr>
          <td colSpan={2}> </td>
          <td colSpan={3}> The Cost of Parts </td>
          <td colSpan={3}>1416.00</td>
          <td colSpan={3}>1770.00</td>
          <td colSpan={1}> </td>
         </tr>
         <tr>
          <td colSpan={2}> </td>
          <td colSpan={3}> Net Labour Charges </td>
          <td colSpan={3}>14325.20</td>
          <td colSpan={3}>14325.20</td>
          <td colSpan={1}> </td>
         </tr>
         <tr>
          <td colSpan={2}> </td>
          <td colSpan={3}> </td>
          <td colSpan={3}> </td>
          <td colSpan={3}> </td>
          <td colSpan={1}> </td>
         </tr>
         <tr>
          <td colSpan={2}> </td>
          <td colSpan={3}> TOTAL </td>
          <td colSpan={3}>15741.20</td>
          <td colSpan={3}>16095.20</td>
          <td colSpan={1}> </td>
         </tr>
       
      </tbody>
      <br /><br/>
      <tbody>
        <tr>
          <td colSpan={12}>
            <div style={{marginLeft:"10"}}>
            <br />
              <p>Net Assessed Loss</p>
              <p>Based on Details Provided Above. The Lowest Liability Under The Subject Policy Of Insurance Works Our To Rs 16095.20</p>
              <br />
              <p>The assessment of loss, as detailed above, is subject to the terms and conditions of the policy of insurance.</p>
              <br />
              (Issued Without Prejudice)
              <br />
              <br />
              <br />
              (Surveyor Name)
              <br />
              <br />
              <br />
            </div>
          </td>
        </tr>
      
</tbody>
    </Table>
    
    
    
    </div>
  )
    }
}

export default function AssesmentReport(){
  const componentRef = useRef();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  return (
    <div>
      <ReportDocument ref={componentRef} />
      <button onClick={handlePrint} className="btn btn-primary" >Print</button>
    </div>
  )
}
