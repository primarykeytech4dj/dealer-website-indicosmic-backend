import React, {useState} from 'react'



import DatePickers from '../../../../Tags/DatePicker'
import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../Tags/MaterialButton'
import Api from '../../../../api'
import Swal from 'sweetalert2'
import { style } from '@mui/system'
import { data } from 'jquery'

// const States = {"Arunachal Pradesh": "Arunachal Pradesh","Assam": "Assam","Bihar": "Bihar","Chhattisgarh": "Chhattisgarh","Goa": "Goa","Gujarat": "Gujarat","Haryana": "Haryana","Himachal Pradesh": "Himachal Pradesh","Jammu and Kashmir": "Jammu and Kashmir","Jharkhand": "Jharkhand","Karnataka": "Karnataka","Kerala": "Kerala","Madhya Pradesh": "Madhya Pradesh","Maharashtra": "Maharashtra","Manipur": "Manipur","Meghalaya": "Meghalaya","Mizoram": "Mizoram","Nagaland": "Nagaland","Odisha": "Odisha","Punjab": "Punjab","Rajasthan": "Rajasthan","Sikkim": "Sikkim", "Tamil Nadu": "Tamil Nadu","Telangana": "Telangana","Tripura": "Tripura","Uttarakhand": "Uttarakhand","Uttar Pradesh": "Uttar Pradesh","West Bengal": "West Bengal","Andaman and Nicobar Islands": "Andaman and Nicobar Islands","Chandigarh": "Chandigarh","Dadra and Nagar Haveli": "Dadra and Nagar Haveli","Daman and Diu": "Daman and Diu","Delhi": "Delhi","Lakshadweep": "Lakshadweep","Puducherry": "Puducherry",};

//     const City = {"Ahmednagar":'Ahmednagar',"Akola":'Akola', "Amravati":'Amravati',"Aurangabad":'Aurangabad',"Bhandara":'Bhandara',"Beed":'Beed',"Buldhana":'Buldhana',"Chandrapur":'Chandrapur',"Dhule":'Dhule',"Gadchiroli":'Gadchiroli',"Gondia":'Gondia',"Hingoli":'Hingoli',"Jalgaon":'Jalgaon',"Jalna":'Jalna',"Kolhapur":'Kolhapur',"Latur":'Latur',"Mumbai City":'Mumbai City',"Mumbai suburban":'Mumbai suburban',"Nandurbar":'Nandurbar',"Nanded":'Nanded',"Nagpur":'Nagpur',"Nashik":'Nashik',"Osmanabad":'Osmanabad',"Parbhani":'Parbhani',"Pune":'Pune',"Raigad":'Raigad',"Ratnagiri":'Ratnagiri',"Sindhudurg":'Sindhudurg',"Sangli":'Sangli',"Solapur":'Solapur',"Satara":'Satara',"Thane":'Thane',"Wardha":'Wardha',"Washim":'Washim',"Yavatmal":'Yavatmal',
//     }
const InsuranceCompany = {
    'Insurance Company 1': 'Insurance Company 1',
    
    "Insurance Company 2" : 'Insurance Company 2',
    
   "Insurance Company 3" : 'Insurance Company 3',
   
   "Insurance Company 4" : 'Insurance Company 4',
   "Insurance Company 5" : 'Insurance Company 5',
   
   };
const YesNo = {"1":"Yes","0":"No"};

export default class PolicyDetails extends React.Component{
    constructor(props) {
        super(props);
        this.apiCtrl = new Api;

        this.state = {
            insComapny : null,
            vehileIDV : null,
            params : {
                claim_code : this.props.data.claimCode,
                policy_details :this.props.data.details?this.props.data.details:{}
            },
            errors:{},
            // insured_mobile_no:"",
            insuranceCompany:[],
            statedata:[""],
            citydata:[""]   ,
            productdata:[""],
            vehiclemake:[""],
            vehiclemodel:[""],
            vehiclevarient:[""]
        }
    }


   
      
    
        
   

    render(){

         
    

    
    const getstatedata = () => {

        if(Object.keys(this.state.statedata) <= 0){
            
            Swal.fire({
                title: 'Loading...',
                didOpen: () => {
                    Swal.showLoading()
                }
            })
            console.log('loader stART', Object.keys(this.state.statedata))
            this.apiCtrl.callAxios('states/list',{search:{country_id:1}}).then(res => {

                var dataOfstate=[]
                res.data.map((value)=>{                  
                    // console.log("STATE==>",value)
                        
                    dataOfstate = {...dataOfstate, [value.id]:value.state_name};
                })     
                this.setState(old => ({...old, statedata: dataOfstate}));
                
            })
            console.log('loader close')
            Swal.close();     
        }
    }
    const getproducttype = () => {
        this.apiCtrl.callAxios('get-vehicle-type').then(res => {

            console .log(res)

            res.data.map((value)=>{                  
                //console.log("STATE==>",value)
                    this.setState(old => ({...old, productdata:{ ...old.productdata, [value.id]:value.vehicle_type}}))                
            })      
        })
    }
    const getvehiclemake = () => {
        Swal.fire({
            title: 'Loading...',
            didOpen: () => {
        Swal.showLoading()
            }
        })
        this.apiCtrl.callAxios('get-vehicle-make').then(res => {

            console .log(res)

            res.data.map((value)=>{                  
                console.log("vehicle==>",value.name)
                    this.setState(old => ({...old, vehiclemake:{ ...old.vehiclemake, [value.id]:value.name}}))                
            })   
        })
        Swal.close();     
    }       
    const getvehiclemodel = () => {

        Swal.fire({
            title: 'Loading...',
            didOpen: () => {
        Swal.showLoading()
            }
        })
        this.apiCtrl.callAxios('get-vehicle-model',{make_id:this.state.params.policy_details.vehicle_make}).then(res => {

            console .log(res)

            res.data.map((value)=>{                  
            //  console.log("vehicle==>",value.name)
                this.setState(old => ({...old,  vehiclemodel:{ ...old. vehiclemodel, [value.id]:value.name}}))                
            })  
        })
        Swal.close();      
    }
    const getvehiclevarient = () => {
        Swal.fire({
            title: 'Loading...',
            didOpen: () => {
        Swal.showLoading()
            }
        })
        this.apiCtrl.callAxios('get-vehicle-variant',{make_id:this.state.params.policy_details.vehicle_model}).then(res => {

            console .log(res)

            res.data.map((value)=>{                  
            //  console.log("vehicle==>",value.name)
                this.setState(old => ({...old,  vehiclevarient:{ ...old. vehiclevarient, [value.id]:value.name}}))                
            })   
        })
        Swal.close();   
    }
    const handlechang =(e)=>{
        const errors={};
        if(e.target.value>1){
        this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
        }else{
            errors.state="Please Select Country"
            this.setState(old=>({...old,errors:errors})) 
          
        }
        
        Swal.fire({
            title: 'Loading...',
            didOpen: () => {
        Swal.showLoading()
            }
        })
        this.setState(old => ({...old, citydata: ""}));
        this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,city:"" } }}))
        this.apiCtrl.callAxios('cities/list',{search:{state_id:e.target.value}}).then(res => {
             
        var dataOfcity=[]
        res.data.map((value)=>{                  
            // console.log("Scity==>",value)
                
            dataOfcity = {...dataOfcity, [value.id]:value.city_name};
        })     
        this.setState(old => ({...old, citydata: dataOfcity}));
        })  
        Swal.close();      
    }
    const handleChange = (e) => {
        

        console.log("lenght====>",e)
        
        this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
        console.log(this.state.params.policy_details)
    

    }
    const handleChangeMo = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.trim().length <=10  && e.target.value.trim().length >=10) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.insured_mobile_no=" Insured mobile no must be at least 10 characters long"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangeName = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.match(/^[A-Za-z\s]*$/) ) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.insured_name=" Insured Name  must have Alphabet"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangeNominee = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.match(/^[a-z]+$/) ) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.insured_nominee_name=" Nominee Name must have Alphabet"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangeAdress1 = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.match(/^[A-Za-z0-9,-\s]*$/) ) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.insured_address1="Insured Adress1 invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangeAdress2 = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.match(/^[A-Za-z0-9,-\s]*$/) ) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.insured_address2="Insured Adress2 invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangeAdress3 = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.match(/^[A-Za-z0-9,-\s]*$/) ) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.insured_address3="Insured Adress3 invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }

    const handleChangeEngineno = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.match(/^[a-z0-9,/]+$/) && e.target.value.trim().length <=6 && e.target.value.trim().length >=6) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.vehicle_engine_no=" Engine Number Invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }

    const handleChangeChesisno = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(e.target.value.match(/^[a-z0-9,/]+$/) && e.target.value.trim().length <=17 && e.target.value.trim().length >=17) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.vehicle_chassis_no=" Chesis Number Invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangeIdv = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(  e.target.value.trim().length >1 ) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.vehicle_idv_value=" Vehicle IDV Invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangePincode = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(  e.target.value.trim().length <=6 && e.target.value.trim().length >=6) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.pincode=" Pincode Invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }
    const handleChangeclr = (e) => {
        
        //console.log("lenght====>",e)
        // const { insured_mobile_no}=this.state.params.policy_details
        // const {name}=e.target
       var isValid =true;
        const errors={};

        if(  e.target.value.match(/^[a-z]+$/)) {
            // isValid= true;
         
             
             this.setState(old=>({...old,errors:errors})) 
            this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))
          
          
           // console.log(errors)
             console.log("===",this.state.params.policy_details)
           }else{

            // console.log("nikhil")
            errors.vehicle_color=" Vehicle Color Invalid"
             this.setState(old=>({...old,errors:errors})) 
            isValid= false;
           }
        
       
    

    }

    const handleDatePicker = (value, name) => {
        
        this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[name]: value
         } }}))
    }
   

    const handleSubmit = (e) => {
        e.preventDefault();


        this.setState(old=>({...old, params:{...old.params, claim_code:this.props.data.claimCode}}))
        console.log("request params",this.state.params);
     
     
            this.apiCtrl.callAxios('claim', this.state.params).then(response => {
                if(response.success) {
        
                    Swal.fire({
                        title: "Policy Details",
                        text: "Policy Details Submitted!",
                        icon: "success",
                        showConfirmButton: false,
                    })
                    this.props.func({claimCode: response.data.claimCode, details: response.data.data});
                } else {
                    Swal.fire({
                        title: "Policy Details",
                        text: response.message,
                        icon: "error",
                        showConfirmButton: false,
                    })
                }
                console.log(response);
                // sessionStorage.setItem('_token', response.data.)
                
            }).catch(function (error) {
                console.log(error);
            });
     
      
    } 
    const insuranceCompany = event=>{
        var data = {role:'insurance-company', claim_code:this.props.data.claimCode}
        this.apiCtrl.callAxios('users/agent-workshop-list', data).then(response => {

        if (response.success == true) {
            this.setState(old => ({...old,userData:{...response.data}}));
            response.data.map((value,index)=>{
            //const{role_id,} =value
            //const agentname=value
        
            
            this.setState(old => ({...old, insuranceCompany:{ ...old.insuranceCompany, [value.id]:value.name}}))
            //console.log(this.state.agent)
            });

        } else {

        }
        })

    }


    var msg = Object.entries(this.state.errors);
  
    var str={};
    //  var msgclr =false
     
         msg.map(([key, msg])=>{
        //   console.log("api controller ",this.state.errors);
        //  // console.log("key ", key, "value"+msg)
          if(msg !== ""){

              str[key] = msg;
           
          } else {
            str[key] = "";
          }
         })

 
  return (
    <>
        <form  method="POST"
         id="assessment_submit" onSubmit={(e) => handleSubmit(e)}>
            <div className="row ml-1">
                <label><b>{this.props.title}</b></label>
            </div>
            <div className="row">
                <div className="col-md-4 mb-4">
            
                    <MaterialSelect data={this.state.insuranceCompany} 
                    defaultValue={this.state.params.policy_details.insurance_company?this.state.params.policy_details.insurance_company:"" }       
                     id="insurance-company" value={this.state.params.policy_details.insurance_company ? this.state.params.policy_details.insurance_company : ''} 
                     labelId="insurance-company-label" 
                     onChange={(e)=>handleChange(e)}  
                     name="insurance_company"  
                     onMouseEnter={insuranceCompany} 
                     required={true}
                     label="Insurance Company *" fullWidth/>
                    
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField 
                    defaultValue={this.state.params.policy_details.insured_name?this.state.params.policy_details.insured_name:""}      fullWidth 
                    value={this.state.params.policy_details.insured_name?this.state.params.policy_details.insured_name:""} 
                    onChange={handleChangeName} 
                    name="insured_name" 
                    helperText={str.insured_name?str.insured_name: ''}
                    error={str.insured_name?true:false}
                  
                        required={true}
                    label="Insured Name " />
                </div>
                <div className="col-md-4 mb-4">
                    <DatePickers  
                    defaultValue={this.state.params.policy_details.policy_start_date?this.state.params.policy_details.policy_start_date:''}  value={this.state.params.policy_details.policy_start_date ? this.state.params.policy_details.policy_start_date :'' }  
                    
                    label="Policy Start Date" 
                    onChange={(e)=>handleDatePicker(e, "policy_start_date")} 
                    name="policy_start_date" fullWidth />
                </div>
                <div className="col-md-4 mb-4">
                    <DatePickers   
                    defaultValue={this.state.params.policy_details.policy_end_date?this.state.params.policy_details.policy_end_date: ''} value={this.state.params.policy_details.policy_end_date ? this.state.params.policy_details.policy_end_date : ''}  
             
                    label="Policy End Date" 
                    onChange={(e)=>handleDatePicker(e, "policy_end_date")} 
                    name="policy_end_date" fullWidth />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth     
                    defaultValue={this.state.params.policy_details.vehicle_idv_value?this.state.params.policy_details.vehicle_idv_value:""}
                 
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=> handleChangeIdv(e)}               
                    name="vehicle_idv_value" 
                    type={"number"}
                   helperText={str.vehicle_idv_value?str.vehicle_idv_value: ''}
                    error={str.vehicle_idv_value?true:false}
                  
                  
                    label="Vehicle IDV Value " />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.insured_mobile_no?this.state.params.policy_details.insured_mobile_no:""}
                     
                    // onChange={(e)=>handleChange(e)} 
                         onChange={(e)=>handleChangeMo(e)} 
                    
                    name="insured_mobile_no" 
                     type={'number'}
                     
//InputProps={{inputProps: { min: 0, max: 10 } }}
                        // min={0} 
                    
                        helperText={str.insured_mobile_no?str.insured_mobile_no: ''}
                        error={str.insured_mobile_no?true:false}
                    label="Insured Mobile No. " />
                
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.insured_email_id?this.state.params.policy_details.insured_email_id:""}      
                    value={this.state.params.policy_details.insured_email_id?this.state.params.policy_details.insured_email_id:""}   
                    onChange={(e)=>handleChange(e)} 
                    name="insured_email_id" 
                     type={'email'}
                        
                    label="Insured Email ID" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth  
                    defaultValue={this.state.params.policy_details.insured_nominee_name?this.state.params.policy_details.insured_nominee_name:""}   
                    value={this.state.params.policy_details.insured_nominee_name?this.state.params.policy_details.insured_nominee_name:""}                
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=> handleChangeNominee(e)}
                    name="insured_nominee_name" 
                        required={true}
                        helperText={str.insured_nominee_name?str.insured_nominee_name: ' '}
                        error={str.insured_nominee_name?true:false}
                       
                    label="Insured Nominee Name " />
                </div>
                {/* <div className="col-md-4 mb-4">
                    <MaterialSelect data={YesNo} 
                    defaultValue={this.state.params.policy_details.hypothetion_lease?this.state.params.policy_details.hypothetion_lease:""}           value={this.state.params.policy_details.hypothecation_lease ? this.state.params.policy_details.hypothecation_lease : ''}  
                     id="hypothetion-lease" 
                     labelId="hypothetion-lease-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="hypothecation_lease"  
                   
                     label="Hypothecation Lease" fullWidth/>
                    
                </div> */}
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.insured_address1?this.state.params.policy_details.insured_address1:""}      
                    value={this.state.params.policy_details.insured_address1?this.state.params.policy_details.insured_address1:""}  
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=>handleChangeAdress1(e)} 
                    name="insured_address1" 
                    helperText={str.insured_address1?str.insured_address1: ' '}
                    error={str.insured_address1 ?true:false}
                     required={true}
                    label="Insured Address1 " />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.insured_address2?this.state.params.policy_details.insured_address2:""} 
                    value={this.state.params.policy_details.insured_address2?this.state.params.policy_details.insured_address2:""}        
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=>handleChangeAdress2(e)} 
                    name="insured_address2" 
                    helperText={str.insured_address2?str.insured_address2: ' '}
                    error={str.insured_address2?true:false}
                    label="Insured Address2" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.insured_address3?this.state.params.policy_details.insured_address3:""}
                    value={this.state.params.policy_details.insured_address3?this.state.params.policy_details.insured_address3:""}     
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=>handleChangeAdress3(e)} 
                    name="insured_address3" 
                    helperText={str.insured_address3?str.insured_address3: ' '}
                    error={str.insured_address3 ?true:false}
                    label="Insured Address3" />
                </div>
                <div className="col-md-4 mb-4">
                    {/* <MaterialSelect 
                    defaultValue={this.state.params.policy_details.state?this.state.params.policy_details.state:""}          data={States} value={this.state.params.policy_details.state ? this.state.params.policy_details.state : ''} 
                     id="state" 
                     labelId="state-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="state"  
            
                     label="State" fullWidth/> */}

                   <MaterialSelect value={this.state.params.policy_details.state?this.state.params.policy_details.state:""}
                    onMouseEnter={getstatedata}       
                    data={this.state.statedata}  id="state_id" labelId="state" name="state"
                    onChange={handlechang}   label="State *" fullWidth
                    helperText={str.state?str.state: ''}
                    error={str.state?true:false}
                    />
                </div>
                <div className="col-md-4 mb-4">
                    {/* <MaterialSelect  
                    defaultValue={this.state.params.policy_details.city?this.state.params.policy_details.city:""}    data={City} value={this.state.params.policy_details.city ? this.state.params.policy_details.city : ''} 
                     id="city" 
                     labelId="city-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="city"  
                     
                     label="City" fullWidth/> */}
                      <MaterialSelect   value={this.state.params.policy_details.city?this.state.params.policy_details.city:""} 
                          data={this.state.citydata}  id="city_id" labelId="city-id" 
                          name="city"    onChange={(e)=>handleChange(e)} 
                          label="City *" fullWidth/>
           
                    
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth   
                    defaultValue={this.state.params.policy_details.pincode?this.state.params.policy_details.pincode:""} 
                     
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=>handleChangePincode(e)}
                    name="pincode"  
                     type={'number'}
                     helperText={str.pincode?str.pincode: ''}
                     error={str.pincode?true:false}
                    
                    label="Pincode" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth   
                    defaultValue={this.state.params.policy_details.vehicle_registration_no?this.state.params.policy_details.vehicle_registration_no:""} 
                    value={this.state.params.policy_details.vehicle_registration_no?this.state.params.policy_details.vehicle_registration_no:""} 
                    onChange={(e)=>handleChange(e)} 
                    name="vehicle_registration_no" 
                
                        required={true}
                    label="Vehicle Registration No. " />
                </div>
                <div className="col-md-4 mb-4">
                    <DatePickers    
                    defaultValue={this.state.params.policy_details.vehicle_registration_date?this.state.params.policy_details.vehicle_registration_date:""} value={this.state.params.policy_details.vehicle_registration_date ? this.state.params.policy_details.vehicle_registration_date : null} 
           
                    label="Vehicle Registration Date" 
                    onChange={(e)=>handleDatePicker(e, "vehicle_registration_date")} 
                    name="vehicle_registration_date" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect 
                    defaultValue={this.state.params.policy_details.vehicle_product_type?this.state.params.policy_details.vehicle_product_type:""}     value={this.state.params.policy_details.vehicle_product_type ? this.state.params.policy_details.vehicle_product_type : ''}  data={this.state.productdata} 
                     id="vehicle-product-type" 
                     labelId="vehicle-product-type-label" 
                     onMouseEnter={getproducttype}
                     onChange={(e)=>handleChange(e)} 
                     name="vehicle_product_type"  
               
                        required={true}
                     label="Vehicle Product Type " fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField    fullWidth 
                    defaultValue={this.state.params.policy_details.cc_hp?this.state.params.policy_details.cc_hp:""}
                    value={this.state.params.policy_details.cc_hp?this.state.params.policy_details.cc_hp:""}    
                    onChange={(e)=>handleChange(e)} 
                    name="cc_hp" 
             
                        required={true}
                    label="CC/HP " />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.less_excess?this.state.params.policy_details.less_excess:""}  
                    value={this.state.params.policy_details.less_excess?this.state.params.policy_details.less_excess:""}      
                    name="less_excess" 
                    onChange={(e)=>handleChange(e)} 
              
                    label="Less Excess" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth     
                    defaultValue={this.state.params.policy_details.less_salvage_adjusted?this.state.params.policy_details.less_salvage_adjusted:""}
                  value={this.state.params.policy_details.less_salvage_adjusted?this.state.params.policy_details.less_salvage_adjusted:""}  
                    name="less_salvage_adjusted" 
                    onChange={(e)=>handleChange(e)} 
                  
                    label="Less Salvage Adjusted" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth   
                    defaultValue={this.state.params.policy_details.voluntary_deductible?this.state.params.policy_details.voluntary_deductible:""}  
                    value={this.state.params.policy_details.voluntary_deductible?this.state.params.policy_details.voluntary_deductible:""}       
                    onChange={(e)=>handleChange(e)}  
                    name="voluntary_deductible" 
                   
                    label="Voluntary Deductible" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect    
                    defaultValue={this.state.params.policy_details.vehicle_make?this.state.params.policy_details.vehicle_make:""}  value={this.state.params.policy_details.vehicle_make ? this.state.params.policy_details.vehicle_make : ''}  data={this.state.vehiclemake} 
                     id="vehicle-make" 
                     labelId="vehicle-make-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="vehicle_make"  
                    onMouseEnter={getvehiclemake}
                        required={true}
                     label="Vehicle Make " fullWidth/>
                </div>
                {/* <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.vehicle_model?this.state.params.policy_details.vehicle_model:""}   value={this.state.params.policy_details.vehicle_model ? this.state.params.policy_details.vehicle_model : ''}  data={this.state.vehiclemodel} 
                     id="vehicle-model" 
                     labelId="vehicle-model-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="vehicle_model"  
                     onMouseEnter={getvehiclemodel}
                        required={true}
                     label="Vehicle Model " fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                <MaterialSelect  
                    defaultValue={this.state.params.policy_details.variant?this.state.params.policy_details.variant:""}   fullWidth 
                    value={this.state.params.policy_details.variant?this.state.params.policy_details.variant:""} 
                    onChange={(e)=>handleChange(e)} 
                    name="variant" 
                    onMouseEnter={getvehiclevarient}
                    data={this.state.vehiclevarient}
                 
                    label="Variant" />
                </div> */}

                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.vehicle_model?this.state.params.policy_details.vehicle_model:""}   value={this.state.params.policy_details.vehicle_model ? this.state.params.policy_details.vehicle_model : ''}  data={["Apache RTR 200 4V Race Edition","Bajaj Pulsar 220F BS6 Price 2022","KTM RC 200 2022 BS6","Hero Splendor Plus XTEC"]} 
                     id="vehicle-model" 
                     labelId="vehicle-model-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="vehicle_model"  
                
                        required={true}
                     label="Vehicle Model " fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField 
                    defaultValue={this.state.params.policy_details.variant?this.state.params.policy_details.variant:""}   fullWidth 
                    onChange={(e)=>handleChange(e)} 
                    name="variant" 
             
                 
                    label="Variant" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField  
                    defaultValue={this.state.params.policy_details.vehicle_engine_no?this.state.params.policy_details.vehicle_engine_no:""}     fullWidth 
                 
                    // onChange={(e)=>handleChange(e)} 

                    onChange={(e)=>handleChangeEngineno(e)}
                    name="vehicle_engine_no"
                     
                    helperText={str.vehicle_engine_no?str.vehicle_engine_no: ''}
                    error={str.vehicle_engine_no?true:false}
                        required={true}
                    label="Vehicle Engine No. " />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth    
                    defaultValue={this.state.params.policy_details.vehicle_chassis_no?this.state.params.policy_details.vehicle_chassis_no:""}
                 
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=>handleChangeChesisno(e)}
                    name="vehicle_chassis_no" 
                    helperText={str.vehicle_chassis_no?str.vehicle_chassis_no: ''}
                    error={str.vehicle_chassis_no?true:false}
                        required={true}
                    label="Vehicle Chasis No. " />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect   
                    defaultValue={this.state.params.policy_details.vehicle_odometer_reading?this.state.params.policy_details.vehicle_odometer_reading:""}  value={this.state.params.policy_details.vehicle_odometer_reading ? this.state.params.policy_details.vehicle_odometer_reading : ''}  data={YesNo}  
                     id="vehicle-odometer-reading" 
                     labelId="vehicle-odometer-reading-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="vehicle_odometer_reading"  
           
                        required={true}
                     label="Vehicle Odometer Reading " fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect   
                    defaultValue={this.state.params.policy_details.vehicle_fuel_type?this.state.params.policy_details.vehicle_fuel_type:""}    value={this.state.params.policy_details.vehicle_fuel_type ? this.state.params.policy_details.vehicle_fuel_type : ''}  data={YesNo} 
                     id="vehicle-fuel-type" 
                     labelId="vehicle-fuel-type-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="vehicle_fuel_type"  
              
                     label="Vehicle Fuel Type" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.anti_theft_device_status?this.state.params.policy_details.anti_theft_device_status:""}  value={this.state.params.policy_details.anti_theft_device_status ? this.state.params.policy_details.anti_theft_device_status : ''}  data={YesNo} 
                     id="anti-theft-device-status" 
                     labelId="anti-theft-device-status-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="anti_theft_device_status"  
        
                        required={true}
                     label="Anti Theft Device Status " fullWidth/>
                </div>
                
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.vehicle_mfg_year?this.state.params.policy_details.vehicle_mfg_year:""} 
                       
                    onChange={(e)=>handleChange(e)} 
                     type={'number'}
        
                    label="Vehicle manufacturing Year "  
                    name="vehicle_mfg_year" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 
                    defaultValue={this.state.params.policy_details.vehicle_seating_capacity?this.state.params.policy_details.vehicle_seating_capacity:""}
                    
                    onChange={(e)=>handleChange(e)} 
                     type={'number'}
        
                    label="Vehicle Seating Capacity "  
                    name="vehicle_seating_capacity" />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth   
                    defaultValue={this.state.params.policy_details.vehicle_color?this.state.params.policy_details.vehicle_color:""}
                   value={this.state.params.policy_details.vehicle_color?this.state.params.policy_details.vehicle_color:""} 
                    // onChange={(e)=>handleChange(e)} 
                    onChange={(e)=>handleChangeclr(e)}
                    name="vehicle_color" 
                    helperText={str.vehicle_color?str.vehicle_color: ''}
                    error={str.vehicle_color?true:false}
                        required={true}
                    label="Vehicle Color " />
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth 

                        required={true}
                    label="Vehicle Type of body "  
                    defaultValue={this.state.params.policy_details.vehicle_type_of_body?this.state.params.policy_details.vehicle_type_of_body:""}
                   value={this.state.params.policy_details.vehicle_type_of_body?this.state.params.policy_details.vehicle_type_of_body:""} 
                    onChange={(e)=>handleChange(e)} 
                    name="vehicle_type_of_body" />
                </div>
                {/* <div className="col-md-4 mb-4">
                    <MaterialTextField fullWidth    
                    onChange={(e)=>handleChange(e)} 
                     type={'number'}
                        required={true}
                    label="Vehicle LPG/CNG" />
                </div> */}
                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.nil_depreciation?this.state.params.policy_details.nil_depreciation:""} value={this.state.params.policy_details.nil_depreciation ? this.state.params.policy_details.nil_depreciation : ''}  data={YesNo} 
                     id="nil-depreciation" 
                     labelId="nil-depreciation-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="nil_depreciation"  

                     label="Nil Depreciation" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.engine_protect?this.state.params.policy_details.engine_protect:""}   value={this.state.params.policy_details.engine_protect ? this.state.params.policy_details.engine_protect : ''}  data={YesNo} 
                     id="engine-protect" 
                     labelId="engine-protect-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="engine_protect"  

                     label="Engine Protect" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect    
                    defaultValue={this.state.params.policy_details.emi_protect?this.state.params.policy_details.emi_protect:""} value={this.state.params.policy_details.emi_protect ? this.state.params.policy_details.emi_protect : ''}  data={YesNo} 
                     id="emi-protect" 
                     labelId="emi-protect-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="emi_protect"  
 
                     label="EMI Protect" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect   
                    defaultValue={this.state.params.policy_details.tyre_cover?this.state.params.policy_details.tyre_cover:""} value={this.state.params.policy_details.tyre_cover ? this.state.params.policy_details.tyre_cover : ''}  data={YesNo} 
                     id="tyre-cover" 
                     labelId="tyre-cover-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="tyre_cover"  

                     label="Tyre Cover" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.total_cover?this.state.params.policy_details.total_cover:""}    value={this.state.params.policy_details.total_cover ? this.state.params.policy_details.total_cover : ''}  data={YesNo} 
                     id="total-cover" 
                     labelId="total-cover-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="total_cover"  

                     label="Total Cover" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.key_replacement?this.state.params.policy_details.key_replacement:""} value={this.state.params.policy_details.key_replacement ? this.state.params.policy_details.key_replacement : ''}  data={YesNo} 
                     id="key-replacement" 
                     labelId="key-replacement-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="key_replacement"  
                     label="Key Replacement" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.ncb_retention?this.state.params.policy_details.ncb_retention:""} value={this.state.params.policy_details.ncb_retention ? this.state.params.policy_details.ncb_retention : ''}  data={YesNo} 
                     id="ncb-reteration" 
                     labelId="ncb-reteration-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="ncb_retention"  

                     label="NCB Reteration" fullWidth/>
                </div>
                <div className="col-md-4 mb-4">
                    <MaterialSelect  
                    defaultValue={this.state.params.policy_details.is_breakin?this.state.params.policy_details.is_breakin:""} value={this.state.params.policy_details.is_breakin ? this.state.params.policy_details.is_breakin : ''}  data={YesNo} 
                     id="is-breakin" 
                     labelId="is-breakin-label" 
                     onChange={(e)=>handleChange(e)} 
                     name="is_breakin"  
        
                     label="Is Breakin" fullWidth/>
                </div>
            </div>
            <div className="row">

                <div className="col-md-6 mt-4">
                    <MaterialButton style={{ backgroundColor: '#fff' , border: '1px solid #183883', color: '#183883'}}  
                    name="back" text="Back" />
                </div>
                <div className="col-md-6 mt-4">
                    <MaterialButton style={{ backgroundColor: '#183883'}} 
                    name="next" className="float-right" text="Next"  type={"submit"} />
                </div>
            </div>

        </form>
    </>
  )
    }
}
