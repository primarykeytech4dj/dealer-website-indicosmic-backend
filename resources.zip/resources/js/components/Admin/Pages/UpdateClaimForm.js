import React from 'react'
import MetaAndTitle from '../../../MetaAndTitle'

export default function UpdateClaimForm() {
  return (
    <div>
      <MetaAndTitle/>
      UpdateClaimForm</div>
  )
}
