import React from 'react'

import Box  from '@mui/material/Box';

import DatePickers from '../../../../Tags/DatePicker'
import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../Tags/MaterialTextArea'
import Api from '../../../../api';

import Swal from 'sweetalert2';

export class CommonDriverDetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            params : {
                claim_code : this.props.data.claimCode,
                driver_details : this.props.data.details ? this.props.data.details : {}
            },
          
        }
    }

    render(){

        const handleChange = (e) => {
            this.setState(param => ({...param , params:{...param.params, driver_details : { ...param.params.driver_details,[e.target.name]: e.target.value } }}))
            console.log(this.state.params.driver_details)
            this.props.func({ details: this.state.params.driver_details});
        }
    
    
        const handleDatePicker = (value, name) => {
            
            this.setState(param => ({...param , params:{...param.params, driver_details : { ...param.params.driver_details,[name]: value
             } }}))
             this.props.func({ details: this.state.params.driver_details});
        }
    

        const YesNo = {"1":"Yes","0":"No"};
        return(

            <>
            <div className="row mt-4 ml-1">
                    <label><b>Driver Details</b></label>
                </div>
                <div className="row ">
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth   
                        defaultValue={this.state.params.driver_details.driver_name ? this.state.params.driver_details.driver_name :''} 
                        onChange={(e)=>handleChange(e)}  
        
                        required={true}
                        label="Driver Name" name="driver_name" id="driver_name" />           
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth   
                        defaultValue={this.state.params.driver_details.driver_mobile_no ? this.state.params.driver_details.driver_mobile_no :''} 
                        onChange={(e)=>handleChange(e)} 
                        type={'number'}
                        required={true}
                        label="Driver Mobile No." name="driver_mobile_no" id="driver-mobile-no" />           
                    </div>
                
                    <div className="col-md-4 mb-4">
                        <MaterialSelect   
                        defaultValue={this.state.params.driver_details.driving_license_type ? this.state.params.driver_details.driving_license_type :''} 
                        value={this.state.params.driver_details.driving_license_type ? this.state.params.driver_details.driving_license_type :''} data={["Personal", "Commercial"]}  
                        onChange={(e)=>handleChange(e)} id="license-type" labelId="license-type-label" name="driving_license_type"  
                        label="Driving License Type" fullWidth/>
                    </div>  
                    <div className="col-md-4 mb-4">
                        <DatePickers  
                        defaultValue={this.state.params.driver_details.driver_license_valid_till ? this.state.params.driver_details.driver_license_valid_till :''}  
                        value={this.state.params.driver_details.driver_license_valid_till ? this.state.params.driver_details.driver_license_valid_till : ''}  
                        onChange={(e)=>handleDatePicker(e, "driver_license_valid_till")} name="driver_license_valid_till" 
                
                        label="Driving License Valid Till" fullWidth  />
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect   
                        defaultValue={this.state.params.driver_details.driver_type ? this.state.params.driver_details.driver_type :''} 
                        value={this.state.params.driver_details.driver_type ? this.state.params.driver_details.driver_type : ''}  data={["Option 1", "Option 2"]} 
                        onChange={(e)=>handleChange(e)}  id="driver-type" labelId="driver-type-label" name="driver_type"  
                  
                        label="Driver Type" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth 
                  
                        required={true}
                        label="Driver License No."    
                        defaultValue={this.state.params.driver_details.driving_license_number ? this.state.params.driver_details.driving_license_number :''} 
                        onChange={(e)=>handleChange(e)} name="driving_license_number" id="driver-license-no" />           
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField
                            multiline
                            rows={1}
                            fullWidth
                            required={true}
                            label="Driver Address"
                            placeholder="Driver Address"
                            
                            onChange={(e)=>handleChange(e)}
                            name="driver_address"
                            id="driver-address"
                            
                            defaultValue={this.state.params.driver_details.driver_address ? this.state.params.driver_details.driver_address :''}
                             />
                            
                        
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect  
                        defaultValue={this.state.params.driver_details.driver_under_influence_of_alcohol ? this.state.params.driver_details.driver_under_influence_of_alcohol :''}  
                        value={this.state.params.driver_details.driver_under_influence_of_alcohol ? this.state.params.driver_details.driver_under_influence_of_alcohol : ''}  data={YesNo}  
                        onChange={(e)=>handleChange(e)}  id="driver-under-influence-alcohol" labelId="driver-under-influence-alcohol-label" name="driver_under_influence_of_alcohol"  
             
                        label="Was The Driver Under Influence of Alcohol" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect   
                        defaultValue={this.state.params.driver_details.driver_involved_in_any_other_accident_in_last_two_years ? this.state.params.driver_details.driver_involved_in_any_other_accident_in_last_two_years :''}  
                        value={this.state.params.driver_details.driver_involved_in_any_other_accident_in_last_two_years ? this.state.params.driver_details.driver_involved_in_any_other_accident_in_last_two_years : ''}  data={YesNo}  
                        onChange={(e)=>handleChange(e)}  id="driver-involved-in-any-accident-past-two-year" labelId="driver-involved-in-any-accident-past-two-yearlabel" name="driver_involved_in_any_other_accident_in_last_two_years"  
                 
                        label="Diver Involved in any other accident in last two years" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField
                        multiline
                        rows={4}

                        fullWidth
                        label="Cause and Nature of Accident-survey Assessment"
                        placeholder="Cause and Nature of Accident-survey Assessment"
                        
                        onChange={(e)=>handleChange(e)}
                        name="cause_and_nature_of_accident
"
                        id="accident-survey-assessment"
                        
                        defaultValue={this.state.params.driver_details.cause_and_nature_of_accident ? this.state.params.driver_details.cause_and_nature_of_accident :''}
                        />
                    </div>
                    
                </div>
            </>
        )
    }
}
export default class ClaimDetails extends React.Component {

    constructor(props){
        super(props);


        this.apiCtrl = new Api;
        this.state = {
            params : {
                claim_code : this.props.data.claimCode,
                claim_details : this.props.data.details ? this.props.data.details : {},
            },
            workshop:[],
            errors:{},
            valiadtion:{
                place_of_accident:{required:true,min:1,max:20 ,type:'alpha'},
                damage:{required:true,min:1,max:20 ,type:'alpha'},
                nitial_estimate:{required:true,min:1,max:20 ,type:'numeric'},
                towing:{required:true,min:1,max:20 ,type:'numeric'},
                driver_name:{required:true,min:1,max:20 ,type:'alpha'},
                driver_mobile_no:{required:true,min:1,max:10 ,type:'numeric'},
                driving_license_number:{required:true,min:16,max:16 ,type:'numeric',type:'numeric'},
                driver_address:{required:true,min:1,max:20 ,type:'numeric'},
                accident_reported_to_police:{required:true},
                
            },
            isValid:false,
        }
    }
    render(){
        


        const YesNo = {"1":"Yes","0":"No"};
    
        
        const handleAccident = event => {
            this.setState({accident : event.target.value})
        
        }

        const workshop = event=>{

            var data = {role:'workshop', claim_code:this.props.data.claimCode}
            this.apiCtrl.callAxios('users/agent-workshop-list', data).then(response => {
                if (response.success == true) {
                    this.setState(old => ({...old,userData:{...response.data}}));
                    response.data.map((value,index)=>{
                    //const{role_id,} =value
                    //const agentname=value
                
                    
                    this.setState(old => ({...old, workshop:{ ...old.workshop, [value.id]:value.name}}))
                    //console.log(this.state.agent)
                    });
        
                } else {

                }
            }) 
        }

        const handleCommonDriverDetails = (data) => {
            this.setState(param => ({...param , params:{...param.params, claim_details : { ...param.params.claim_details, ...data.details } }}))
            // this.setState(param =>({...param,  details:{ ...param.details , ...data.details}}))
        }
    
        const handleChange = (e) => {

            console.log('name'+e.target.name, 'value '+this.state.valiadtion[e.target.name])
            let error={}
            let isValid = this.state.isValid;
           
            if(typeof this.state.valiadtion[e.target.name] !== "undefined"){

                Object.entries(this.state.valiadtion[e.target.name]).map(([key,value])=>{
             
              
                    if(key === 'required'){
                        if(e.target.value.length < 0){
                            error[e.target.name] = `${e.target.name} Field is required`
                            // this.setState(old=>({...old,errors:error})) 
                            isValid = false;
                        } 
                    } else if(key === 'min'){
                        if(e.target.value.length < value){
                              error[e.target.name] = `${e.target.name} must be more than ${value} characters`
                            // error[e.target.name] = `${e.target.name} must be less than ${value} characters`
                            // this.setState(old=>({...old,errors:error})) 
                            isValid = false;
                        }
                    } else if(key === 'max'){
                        if(e.target.value.length > value){
                            // error[e.target.name] = `${e.target.name} must be more than ${value} characters`
                            error[e.target.name] = `${e.target.name} must be less than ${value} characters`
                            isValid = false;
                            // this.setState(old=>({...old,errors:error})) 
                        }
                    } else if(key === 'type'){
                        if(value === 'alpha'){
                            if(!e.target.value.match(/^[A-Za-z\s]*$/)){
                                // this.setState(old=>({...old,errors:error})) 
                                error[e.target.name] = `${e.target.name} must be String characters`
                                isValid = false;
                            }
                        } else if(value === 'Numeric'){
                            if(!e.target.value.match(/^[0-9]*$/)){
                                error[e.target.name] = `${e.target.name} must be String Numeric`
                                // this.setState(old=>({...old,errors:error})) 
                                isValid = false;
                            }
                        }
                           
                    } else {
                        isValid = true;
                        error[e.target.name] = '';
                    }
    
                  //console.log("val",value, key+"  key")
                })
            }

               
                    
                    // this.setState({isValid : isValid});
                    this.setState(param => ({...param , params:{...param.params, claim_details : { ...param.params.claim_details,[e.target.name]: e.target.value } }}))
                    this.setState(old=>({...old,errors:error})) 
                
    
    
          


        }

        var msg = Object.entries(this.state.errors);
  
        var str={};
        //  var msgclr =false
         
             msg.map(([key, msg])=>{
            //   console.log("api controller ",this.state.errors);
            //  // console.log("key ", key, "value"+msg)
              if(msg !== ""){
    
                  str[key] = msg;
               
              } else {
                str[key] = "";
              }
             })


    
    
        const handleDatePicker = (value, name) => {
            
            this.setState(param => ({...param , params:{...param.params, claim_details : { ...param.params.claim_details,[name]: value
             } }}))
        }

        const handleSubmit=  (e) => {
            e.preventDefault();
            var errors = {};
            var isValid = this.state.isValid;
            Object.entries(this.state.valiadtion).map(([key,value])=>{

                if(typeof this.state.params.claim_details[key] === 'undefined') {
                    isValid = true;
                    errors[key] = `${key} Field is Required`;
                    isValid = false;
                } else {
                    errors[key] = '';
                }
                this.setState(old=>({...old,errors:errors})) 
            })
    
            if(errors !== ''){
                return false;
            }
            console.log(this.state.params);
            this.setState(old=>({...old, params:{...old.params, claim_code:this.props.data.claimCode}}))
          this.apiCtrl.callAxios('claim', this.state.params).then(response => {
            if(response.success) {
                Swal.fire({
                    title: "Claim & Driver Details",
                    text: "Claim & Driver Details Submitted!",
                    icon: "success",
                    showConfirmButton: false,
                })
             //   this.props.func({ details: this.state.params.claim_details});

                this.props.func({claimCode: response.data.claimCode, details: response.data.data});
              
            } else {
                Swal.fire({
                    title: "Claim & Driver Details",
                    text: response.message,
                    icon: "error",
                    showConfirmButton: false,
                })
            }
            console.log(response);
            // sessionStorage.setItem('_token', response.data.)
            
          }).catch(function (error) {
            console.log(error);
          });
        } 

        const backButton = () => {
            this.props.func({value: "3", details: this.state.params.claim_details});
        }

        console.log(this.state.params)

      return (
        <>
            <form  method="POST" id="assessment_submit" onSubmit={(e) => handleSubmit(e)}>
                <div className="row ml-1">
                    <label><b>{this.props.title}</b></label>
                </div>
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <div className="row">
                    <div className="col-md-4 mb-4">
                        <DatePickers name="date_of_accident"  
                        defaultValue={this.state.params.claim_details.date_of_accident ? this.state.params.claim_details.date_of_accident : ''}   
                        value={this.state.params.claim_details.date_of_accident ? this.state.params.claim_details.date_of_accident : ''} 
                        onChange={(e)=>handleDatePicker(e, "date_of_accident")}  
                        required={false}
                        label="Date Of Accident" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTimePicker  
                        defaultValue={this.state.params.claim_details.time_of_accident ? this.state.params.claim_details.time_of_accident : null}   
                        value={this.state.params.claim_details.time_of_accident ? this.state.params.claim_details.time_of_accident : null} 
                        onChange={(e)=>handleDatePicker(e, "time_of_accident")}  
                
                        required={false}
                        label="Time Of Accident" name="time_of_accident"  fullWidth />
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth   
                        defaultValue={this.state.params.claim_details.place_of_accident ? this.state.params.claim_details.place_of_accident : null} 
                        onChange={(event)=>handleChange(event)}  
                        helperText={str.place_of_accident?str.place_of_accident: ''}
                        error={str.place_of_accident?true:false}
                        required={true}
                        label="Place Of Accident" name="place_of_accident" id="place-of-accident" />
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth   
                        defaultValue={this.state.params.claim_details.damage ? this.state.params.claim_details.damage : null} 
                        onChange={(event)=>handleChange(event)} 
                        helperText={str.damage?str.damage: ''}
                        error={str.damage?true:false}
                        required={true}
                        label="Damage" name="damage" id="damage" />
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth  
                        defaultValue={this.state.params.claim_details.initial_estimate ? this.state.params.claim_details.initial_estimate : null} 
                        onChange={(event)=>handleChange(event)} 
                        helperText={str.initial_estimate?str.initial_estimate: ''}
                        error={str.initial_estimate?true:false}
                        type={'number'}
                        required={true}
                        label="Initial Estimate" name="initial_estimate" id="initial-estimate" />
                    </div>
                    <div className="col-md-4 mb-4">
                        <DatePickers 
            
                        label="Vehicle Reported Date" 
                        value={this.state.params.claim_details.vehicle_reported_date ? this.state.params.claim_details.vehicle_reported_date : ''} 
                        defaultValue={this.state.params.claim_details.vehicle_reported_date ? this.state.params.claim_details.vehicle_reported_date : ''} 
                        onChange={(e)=>handleDatePicker(e, "vehicle_reported_date")}  name="vehicle_reported_date" id="vehicle-reported-date" fullWidth />
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth 
                        type={'number'}
                        required={true}
                        label="Towing Amount" 
                        defaultValue={this.state.params.claim_details.towing ? this.state.params.claim_details.towing : null}    
                        onChange={(event)=>handleChange(event)} name="towing" id="towing" 
                        helperText={str.towing?str.towing: ''}
                        error={str.towing?true:false}
                        />
                        
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect    
                        // defaultValue={this.state.params.claim_details.accident_reported_to_police ? this.state.params.claim_details.accident_reported_to_police : ''}     
                        value={this.state.params.claim_details.accident_reported_to_police ? this.state.params.claim_details.accident_reported_to_police : ''} data={YesNo} 
                        onChange={(event)=>handleChange(event)}  id="accident-reported-to-police" labelId="accident-reported-to-police-label" name="accident_reported_to_police"  
                        helperText={str.accident_reported_to_police?str.accident_reported_to_police: ''}
                        error={str.accident_reported_to_police?true:false}
                        label="Has Accident been reported to police" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect 
                        defaultValue={this.state.params.claim_details.punchnama_carried_out ? this.state.params.claim_details.punchnama_carried_out : ''}     
                        value={this.state.params.claim_details.punchnama_carried_out ? this.state.params.claim_details.punchnama_carried_out : ''} data={YesNo} 
                        onChange={(event)=>handleChange(event)}  id="punchnama-carried-out" labelId="punchnama-carried-out-label" name="punchnama_carried_out"  
                        
                        label="Has Punchnama Been Carried Out" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect  
                        defaultValue={this.state.params.claim_details.injury_to_driver_occupant ? this.state.params.claim_details.injury_to_driver_occupant : ''}  
                        value={this.state.params.claim_details.injury_to_driver_occupant ? this.state.params.claim_details.injury_to_driver_occupant : ''} data={YesNo} 
                        onChange={(event)=>handleChange(event)} id="injury-to-driver" labelId="injury-to-driver-label" name="injury_to_driver_occupant"  
                        
                        label="Injury To Driver/Occupant (if any)" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect  
                        defaultValue={this.state.params.claim_details.third_party_involved_in_accident ? this.state.params.claim_details.third_party_involved_in_accident : ''} 
                        value={this.state.params.claim_details.third_party_involved_in_accident ? this.state.params.claim_details.third_party_involved_in_accident : ''} data={YesNo} 
                        onChange={(event)=>handleChange(event)} id="third-party-invloved" labelId="third-party-invloved-label" name="third_party_involved_in_accident"  
                        
                        label="Was Any Third Party Involved In Accident" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect    
                        defaultValue={this.state.params.claim_details.thirdy_party_loss ? this.state.params.claim_details.thirdy_party_loss : ''} 
                        value={this.state.params.claim_details.thirdy_party_loss ? this.state.params.claim_details.thirdy_party_loss : ''} data={YesNo} 
                        onChange={(event)=>handleChange(event)} id="thirdy-party-loss" labelId="thirdy-party-loss-label" name="thirdy_party_loss"  
                        
                        label="Particulars Of Third Party Injury/Loss" fullWidth/>
                    </div>
                </div>
                    </Box>
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        
                {/* <CommonDriverDetails {...this.props}  func={handleCommonDriverDetails} /> */}
                <div className="row mt-4 ml-1">
                    <label><b>Driver Details</b></label>
                </div>
                <div className="row ">
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth   
                        defaultValue={this.state.params.claim_details.driver_name ? this.state.params.claim_details.driver_name :''} 
                        onChange={(e)=>handleChange(e)}  
                        helperText={str.driver_name?str.driver_name: ''}
                        error={str.driver_name?true:false}
                        required={true}
                        label="Driver Name" name="driver_name" id="driver_name" />           
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth   
                        defaultValue={this.state.params.claim_details.driver_mobile_no ? this.state.params.claim_details.driver_mobile_no :''} 
                        onChange={(e)=>handleChange(e)} 
                        type={'number'}
                        helperText={str.driver_mobile_no?str.driver_mobile_no: ''}
                        error={str.driver_mobile_no?true:false}
                        required={true}
                        minLength={10}
                        label="Driver Mobile No." name="driver_mobile_no" id="driver-mobile-no" />           
                    </div>
                
                    <div className="col-md-4 mb-4">
                        <MaterialSelect   
                        defaultValue={this.state.params.claim_details.driving_license_type ? this.state.params.claim_details.driving_license_type :''} 
                        value={this.state.params.claim_details.driving_license_type ? this.state.params.claim_details.driving_license_type :''} data={["Personal", "Commercial"]}  
                        onChange={(e)=>handleChange(e)} id="license-type" labelId="license-type-label" name="driving_license_type"  
                        label="Driving License Type" fullWidth/>
                    </div>  
                    <div className="col-md-4 mb-4">
                        <DatePickers  
                        defaultValue={this.state.params.claim_details.driver_license_valid_till ? this.state.params.claim_details.driver_license_valid_till :''}  
                        value={this.state.params.claim_details.driver_license_valid_till ? this.state.params.claim_details.driver_license_valid_till : ''}  
                        onChange={(e)=>handleDatePicker(e, "driver_license_valid_till")} name="driver_license_valid_till" 
                
                        label="Driving License Valid Till" fullWidth  />
                    </div>
                    {/* <div className="col-md-4 mb-4">
                        <MaterialSelect   
                        defaultValue={this.state.params.claim_details.driver_type ? this.state.params.claim_details.driver_type :''} 
                        value={this.state.params.claim_details.driver_type ? this.state.params.claim_details.driver_type : ''}  data={["Option 1", "Option 2"]} 
                        onChange={(e)=>handleChange(e)}  id="driver-type" labelId="driver-type-label" name="driver_type"  
                  
                        label="Driver Type" fullWidth/>
                    </div> */}
                    <div className="col-md-4 mb-4">
                        <MaterialTextField fullWidth 
                  
                        required={true}
                        label="Driver License No."  
                         helperText={str.driving_license_number?str.driving_license_number: ''}
                        error={str.driving_license_number?true:false}  
                        defaultValue={this.state.params.claim_details.driving_license_number ? this.state.params.claim_details.driving_license_number :''} 
                        onChange={(e)=>handleChange(e)} name="driving_license_number" id="driver-license-no" />           
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialTextField
                            multiline
                            rows={1}
                            fullWidth
                            required={true}
                            label="Driver Address"
                            placeholder="Driver Address"
                            helperText={str.driver_address?str.driver_address: ''}
                            error={str.driver_address?true:false}  
                            onChange={(e)=>handleChange(e)}
                            name="driver_address"
                            id="driver-address"
                            
                            defaultValue={this.state.params.claim_details.driver_address ? this.state.params.claim_details.driver_address :''}
                             />
                            
                        
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect  
                        defaultValue={this.state.params.claim_details.driver_under_influence_of_alcohol ? this.state.params.claim_details.driver_under_influence_of_alcohol :''}  
                        value={this.state.params.claim_details.driver_under_influence_of_alcohol ? this.state.params.claim_details.driver_under_influence_of_alcohol : ''}  data={YesNo}  
                        onChange={(e)=>handleChange(e)}  id="driver-under-influence-alcohol" labelId="driver-under-influence-alcohol-label" name="driver_under_influence_of_alcohol"  
             
                        label="Was The Driver Under Influence of Alcohol" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect   
                        defaultValue={this.state.params.claim_details.driver_involved_in_any_other_accident_in_last_two_years ? this.state.params.claim_details.driver_involved_in_any_other_accident_in_last_two_years :''}  
                        value={this.state.params.claim_details.driver_involved_in_any_other_accident_in_last_two_years ? this.state.params.claim_details.driver_involved_in_any_other_accident_in_last_two_years : ''}  data={YesNo}  
                        onChange={(e)=>handleChange(e)}  id="driver-involved-in-any-accident-past-two-year" labelId="driver-involved-in-any-accident-past-two-yearlabel" name="driver_involved_in_any_other_accident_in_last_two_years"  
                 
                        label="Diver Involved in any other accident in last two years" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField
                        multiline
                        rows={4}

                        fullWidth
                        label="Cause and Nature of Accident-survey Assessment"
                        placeholder="Cause and Nature of Accident-survey Assessment"
                        
                        onChange={(e)=>handleChange(e)}
                        name="cause_and_nature_of_accident"
                        id="accident-survey-assessment"
                        
                        defaultValue={this.state.params.claim_details.cause_and_nature_of_accident? this.state.params.claim_details.cause_and_nature_of_accident:''}
                        />
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialSelect 
                    onMouseEnter={workshop} 
                    required={true} 
                    value={this.state.params.claim_details.workshop_id?this.state.params.claim_details.workshop_id:0} 
                    onChange={handleChange}    
                    data={this.state.workshop} 
                    id="workshop_id" 
                    labelId="workshop-id" name="workshop_id"  label={"Select Workshop *"} fullWidth/>
                    </div>
                    
                </div>
        
                </Box>
                <div className="row ">
        
                    <div className="col-md-6 mt-4">
                        <MaterialButton style={{ backgroundColor: '#fff' , border: '1px solid #183883', color: '#183883'}} name="back" text="Back" />
                    </div>
                    <div className="col-md-6 mt-4">
                        <MaterialButton style={{ backgroundColor: '#183883'}} name="next" type="submit" className="float-right" text="Next" />
                    </div>
                </div>
            </form>
        </>
      )
    }

}
