import React from 'react'
import Box  from '@mui/material/Box';



import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../Tags/MaterialTextArea'

const subCategory = ['Bonet', 'Roof', 'Door'];
const remark = {'Repairable':'Repairable', 'Un-Repairable':'Un-Repairable', 'Replace':'Replace'};


import Api from '../../../../api';


 export class CommonDealersEstimationType extends React.Component{
    constructor(props){
        super(props);

        this.apiCtrl = new Api;
        this.state = {
            product : [],
            service : [],
            product_data: '',
            products: '',
            service_data: '',
            services: this.props.service ? this.props.service :[],
            param: '',
            
        }

    }

    getProductByCategory = () =>{
 
        this.apiCtrl.callAxios('product/list', {product_category_id : this.props.category_id}).then(response => {
            if(response.success == true){
                response.data.map((value, index)=>{
                    this.setState(old=>({
                        ...old, product: {...old.product, [value.id] : [value.product]}
                    }))
                    this.setState({
                        products: response.data})
                })
            } 
        })

    }
    

    componentDidMount() {

        this.getProductByCategory(); 
    }


    componentDidUpdate( prevProps, prevState) {
        if(prevState.param !== this.state.param) {
            this.props.funcs(this.state.param)
        }

    }
    
 render() {

    const handleChange = (e) => {
        if("assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][product_id]" === e.target.name) {
            this.state.products.map((value, index)=>{
                if(value.id === e.target.value) {
                    
                    
                    this.setState(old=> ({...old,product_data: value}))
                    // console.log(this.state);
                }
            })
            
            
        }
        console.log('Value', e)
        if(typeof  e.target.id !== 'undefined'){

            console.log('SPLIT', e.target.id)
            var array = e.target.id.split("_");
            var Amnt = 0;
            var qty = 1;
            var amt = 0;
            
            Amnt = parseFloat($("#unitprice_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val()).toFixed(2);
            if(($("#qty_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== "NaN") &&  ($("#qty_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== ""))
            {
                qty =  parseFloat($("#qty_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val()).toFixed(2)
            }
            amt = Amnt*qty;
            var tax = 0.00;
            if(($("#gst_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== "NaN") &&  ($("#gst_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== ""))
            {
                tax = parseFloat($("#gst_"+this.props.category_name +"_"+this.props.id+"_"+array[3]).val()).toFixed(2);
            }
            var total = amt+(amt*tax/100.00);
    console.log('Total', total)
            this.setState(old=> ({...old, param:{...old.param, ["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+array[3]+"][amount_after_tax]"]: total}}))
    
    
            var length = (this.state.services.length);
    
            var estimate = 0;
            var gstAmount = 0;
            var totalEstimate = 0;
            for(var i = 0; i<= length; ++i ){
                console.log('Index', array[1]+"_"+array[2]+i)
                estimate =  parseFloat((estimate +$("#unitprice_"+array[1]+"_"+array[2]+"_"+i).val())).toFixed(2);
                console.log('Estimate ',  estimate)
                totalEstimate =  parseFloat((totalEstimate + $("#estimateAmount_"+array[1]+"_"+array[2]+"_"+i).val())).toFixed(2);
                console.log('totalEstimate Value',  totalEstimate)
            }
    
            // $('#')
            console.log('Estimate ', estimate);
            console.log('TotalEstimate ', totalEstimate);
            this.setState(old=> ({
                ...old, param:{...old.param, ["estimated["+array[1]+"][estimate_total]"]:estimate}
            }))
            
            this.setState(old=> ({
                ...old, param:{...old.param, ["estimated["+array[1]+"][gst]"]:  parseFloat((totalEstimate-estimate)).toFixed(2) }
            }))
            this.setState(old=> ({
                ...old, param:{...old.param, ["estimated["+array[1]+"][total]"]:totalEstimate}
            }))
        }


        
        
        this.setState(old=> ({...old,param:{...old.param, [e.target.name]: [e.target.value]}}))

       
    }

  
    return(
        <>
            <Box sx={{ borderBottom: 1, borderColor: 'divider'}} key={this.props.key}>
            <div className="row">
       
                    <div className="col-md-6">
                        <div className="row">

                            <div className="col-md-4 mb-4">
                                <input type="hidden" 
                                    value={this.state.product_data.is_active?this.state.product_data.is_active: 
                                        (this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][is_product]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][is_product]"]: '')
                                    }
                                    onChange={(e)=>handleChange(e)} 
                                    name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][is_product]"}  
                                />
                                <MaterialSelect 
                                data={this.state.product} 
                                value={this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][product_id]"] ? this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][product_id]"] : ''} 
                                onChange={(e)=>handleChange(e)} 
                                
                                id={"product_"+this.props.category_name+"_"+this.props.id+"_0"} 
                                labelId={"product_label_"+this.props.category_name+"_"+this.props.id+"_product_id"+"_0"}
                                name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][product_id]"}  
                                label="Select Product" fullWidth/>
                            </div>
                            <div className="col-md-4 mb-4">
                                <MaterialSelect data={remark}  
                                onChange={(e)=>handleChange(e)} 
                                id={"remark_"+this.props.category_name+"_"+this.props.id+"_0"} 
                                labelId={"remark_label_"+this.props.category_name+"_"+this.props.id+"_remark_id"+"_0"}
                                name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][remark]"}    
                                value={this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][remark]"] ? this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][remark]"] : ''} 
                                label="--Select Remark--" 
                                fullWidth/>
                            </div>
                            <div className="col-md-4 mb-4">
                                <label ><b >
                                  
                                    <input type="hidden" 
                                        value={this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][product_id]"] ? this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][product_id]"] : ''} 
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][hsn_code]"}  
                                        onChange={(e)=>handleChange(e)} 
                                         />
                                   {this.state.product_data.hsn_code?this.state.product_data.hsn_code: 
                                        (this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][hsn_code]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][hsn_code]"]: '')
                                    }
                                   
                                    </b></label>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="row">
                            {/* <div className="col-md-12 mb-4"> */}
                                {/* <CommonAmountQtyGst key="0" {...this.props} data={this.state.product_data} /> */}
                        
                                <div className="col-md-3 mb-4">
                                    <MaterialTextField fullWidth
                                        label="Part Amount"
                                        //  name="part-amount"
                                        onChange={handleChange}
                                        value={ 
                                            (this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][unit_price]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][unit_price]"]: this.state.product_data.base_price?this.state.product_data.base_price:'')
                                        }
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][unit_price]"}    
                                        id={"unitprice_"+this.props.category_name+"_"+this.props.id+"_0"} 
                                    />
                                </div>
                                <div className="col-md-3 mb-4">
                                    <MaterialTextField fullWidth 
                                        label="Qty"
                                        onChange={handleChange} 
                                        value={ 
                                            (this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][qty]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][qty]"]: this.state.product_data.qty?this.state.product_data.qty:'')
                                        }

                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][qty]"}    
                                        id={"qty_"+this.props.category_name+"_"+this.props.id+"_0"} 
                                    
                                    />
                                </div>
                                <div className="col-md-3 mb-4">
                                    <MaterialTextField fullWidth 
                                        label="GST %" 
                                        onChange={handleChange}
                                        value={
                                            (this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][gst]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][gst]"]: this.state.product_data.gst?this.state.product_data.gst:  '')
                                        }
                            
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][gst]"}    
                                        id={"gst_"+this.props.category_name+"_"+this.props.id+"_0"} 
                                     />
                                    </div>
                                    <div className="col-md-3 mb-4">
                                    <MaterialTextField 
                                        fullWidth 
                                        onChange={handleChange}
                                        label="Total Amount"
                                
                                        value={this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][amount_after_tax]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][amount_after_tax]"]: ''}
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][amount_after_tax]"}    
                                        id={"estimateAmount_"+this.props.category_name+"_"+this.props.id+"_0"}  />
                                    </div>
                            {/* </div> */}
                        </div>
                    </div>
                </div>

                {this.state.services.map((value, index)=>{
                    return(
                        <>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="row">
                                    <div className="col-md-4 mb-4">
                                        <></>
                                       
                                    </div>
                                    <div className="col-md-4 mb-4">
                                    <label><b >{value.product} ({ value.base_price?value.base_price : ''}) </b></label>
                                    </div>
                                    <div className="col-md-4 mb-4">
                                    <label ><b >{value.hsn_code}</b></label>
                                     <input type="hidden" 
                                        value={value.id} 
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][product_id]"}  
                                    />
                                    <input type="hidden" 
                                        value={value.product}
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][hsn_code]"}  
                                    />
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="row">
                                
                                    <div className="col-md-3 mb-4">
                                        <MaterialTextField fullWidth
                                            label="Part Amount"
                                            //  name="part-amount"
                                            onChange={handleChange}
                                            value={
                                                this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][unit_price]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][unit_price]"]: ''
                                            }
                                            name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][unit_price]"}    
                                            id={"unitprice_"+this.props.category_name+"_"+this.props.id+"_"+(index+1)} 
                                        />
                                    </div>
                                    <div className="col-md-3 mb-4">
                                        <MaterialTextField fullWidth 
                                        label="Qty"
                                        onChange={handleChange} 
                                        value={this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][qty]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][qty]"]: '' }

                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][qty]"}    
                                        id={"qty_"+this.props.category_name+"_"+this.props.id+"_"+(index+1)} 
                                        />
                                    </div>
                                    <div className="col-md-3 mb-4">
                                    <MaterialTextField fullWidth 
                                        label="GST %" 
                                        onChange={handleChange}
                                        value={value.gst?value.gst: 
                                            (this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][gst]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][gst]"]: '')
                                        }
                            
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][gst]"}    
                                        id={"gst_"+this.props.category_name+"_"+this.props.id+"_"+(index+1)}  />
                                    </div>
                                    <div className="col-md-3 mb-4">
                                        <MaterialTextField 
                                        fullWidth 
                                        onChange={handleChange}
                                        label="Estimated Amount"
                                
                                        value={this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][amount_after_tax]"]?this.state.param["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][amount_after_tax]"]: ''}
                                        name={"assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+(index+1)+"][amount_after_tax]"}    
                                        id={"estimateAmount_"+this.props.category_name+"_"+this.props.id+"_"+(index+1)}  />
                                    </div>
                                    
                                </div>
                            </div>
                        
                        </div>
                        
                        </>
                    )
                   
                })}
                {/*  */}
            </Box>
        </>
    )
 }
}
export function DealersEstimationMetal(props) {


  return (
    <>
        <div className="row mb-4">
            <div className="col-md-12">
            <CommonDealersEstimationType {...props} />
                
            </div>
        </div>
    </>
  )
}


export function DealersEstimationPlastic(props) {


  return (
    <>
        <div className="row mb-4">
            <div className="col-md-12">
            <CommonDealersEstimationType {...props} />
                
            </div>
        </div>
    </>
  )
}

export function DealersEstimationPlasticRubber(props) {
    
    


  return (
    <>
       <div className="row mb-4">
            <div className="col-md-12">
            <CommonDealersEstimationType {...props} />
                
            </div>
        </div>
    </>
  )
}

export class CommonAmountQtyGst extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        }
    }

    render(){
    const handleChange = (e) => {
        this.setState(old =>({...old, [e.target.name]: [e.target.value]}))
     

    }
    return(
        <>
        <div className="row" >
        
        </div>
        </>
    );
    }
}