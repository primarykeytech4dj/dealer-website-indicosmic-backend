import React from 'react'

import Box  from '@mui/material/Box';
import MaterialButton from '../../../../Tags/MaterialButton'
import MaterialTextField from '../../../../Tags/MaterialTextField'

import {DealersEstimationMetal, DealersEstimationPlastic, DealersEstimationPlasticRubber} from './DealersEstimationType'

import Api from '../../../../api';
import { param } from 'jquery';

export default class DealersEstimation extends React.Component{
     constructor(props) {
        super(props);

        this.apiCtrl = new Api;
        this.state = {
            assessment : null,
            assessment_details : [],
            productCategory : [],
            services: [],
            tab: [],
            buttonClick: '', 
            params: ''
        }
        this.AssessmentState = React.createRef();
     }
     


    getProductCategory = () =>{
        this.apiCtrl.callAxios('product/product-category-list', []).then(response => {
            if(response.success == true){
                this.setState({productCategory: response.data})
                this.state.productCategory.map((value,index) => {
                    this.setState((prev) => {
                        return {...prev, tab: [...prev.tab, {[value.category_name]: { [0]:  <DealersEstimationMetal funcs={this.handleFunction.bind(this)} service={this.state.services} key={'0'}  id={'0'} category_id={value.id} category_name={value.category_name}  />}} ]}
                   }) 
                
                    // this.setState(prevState=>{
                    //    ...prevState.tab, [...prev.tab[value.category_name],{ [0]: Math.random()+"@learnbestcoding.com"}]
                    //     [value.category_name] = { ...tabs[value.category_name], [0]: <DealersEstimationMetal key={0} id={0} category_id={value.id}  />  }
                    //     // return {tabs} 
                    // });

                        // ...old, tab: [...old.tab,  value.category_name,  [...old.tab[value.category_name] ,  <DealersEstimationMetal key={0} id={0} category_id={value.id}  /> ]]})
                    // this.setState(old=>({...old, tab: {...old.tab, [value.category_name]: { ...old.tab[value.category_name] , [1] :<DealersEstimationMetal key={1} id={1} category_id={value.id}  /> }}}))
                })
            } 
        })
    }
    getServices() {
        this.apiCtrl.callAxios('service-list', []).then(response => {
            if(response.success == true){
           
                    this.setState({services: response.data})
            
            } 
        })
    }

    componentDidMount() {
        this.getServices();
       
    }

    componentDidUpdate( prevProps, prevState) {
        if(prevState.services !== this.state.services) {
            this.getProductCategory();
        }

    }
    handleFunction = (data) =>{
      this.setState(old=>({...old, params:{...old.params, ...data}}))
      console.log(this.state);
    }

    render(){
  
     const handleTab = (e, category_name, category_id) => {
        this.setState(old => ({...old, buttonClick: {...old.buttonClick, [e.target.name]: e.target.value+1 }}))
        this.setState((prev) => {
            return {...prev, tab: [...prev.tab, {[category_name]:{ [e.target.value] :  <DealersEstimationMetal funcs={ this.handleFunction.bind(this)} service={this.state.services} key={++e.target.value} id={++e.target.value} category_id={category_id} category_name={category_name}  />}} ]}
        })
        
    }

  


    const handleSubmit = (e) => {
        e.preventDefault();
        var params = {};

        var formData = new FormData();
       var x = $("form").serializeArray();
       console.log(x);
    //    return;
        // $.each(x, function(i, field) {
        //     // $("#output").append(field.name + ":"
        //     //         + field.value + " ");
        //     if( field.value !== ''){

        //         formData.append(field.name, field.value);
        //         //params = [...params, [...param[field.name], [field.value]]]
        //         console.log(field.name + ":"+ field.value + " ", params);
        //     }
        // })
        this.apiCtrl.callAxios('assessment',x).then(response => {
            if(response.success == true){
                Swal.fire({
                    title: "Create Product",
                    text: "Created!",
                    icon: "success",
                    showConfirmButton: false,
                })
            } else {
                console.log('Something Went Wrong')
            }
            console.log(response)
        })

        // this.setState(old=>({...old,param: params}))


    }

    return (
    <>
        <form method="POST" id="assessment_submit" onSubmit={(e)=>handleSubmit(e)}>
        
        {/* <input type="hidden" name="claim_code" value={this.state.data.claim_code} /> */}
        <input type="hidden" name="claim_code" value='eR3u5ieKhACx' />
            {this.state.productCategory.map((value,index) => {
                return(

        <Box sx={{ borderBottom: 1, borderColor: 'divider'}} key={index}>
            <div className="row mb-4">
                <div className="col-md-2 ">
                    <label><b style={{color:"black"}}>{value.category_name}</b></label>
                </div>
                <div className="col-md-2 ">
                <label><b style={{color:"black"}}>Activity</b></label>
                </div>
                <div className="col-md-2 ">
                    <label><b style={{color:"black"}}>HSN Code</b></label>
                </div>
                <div className="col-md-6 ">
                    <div className="row">
                        <div className="col-md-3"> <label><b style={{color:"black"}}>Unit Price</b></label></div>
                        <div className="col-md-3"> <label><b style={{color:"black"}}>QTY</b></label></div>
                        <div className="col-md-3"> <label><b style={{color:"black"}}>GST</b></label></div>
                        <div className="col-md-3">

                            <MaterialButton style={{ backgroundColor: '#183883'}} onClick={(e)=>{handleTab(e, value.category_name,value.id)}} value={this.state.buttonClick[value.category_name]?this.state.buttonClick[value.category_name]:0} name={value.category_name} className="float-right" text={"Add "+value.category_name} />
                        </div>
                    </div>
                    
                </div>
            </div>
            {
            Object.entries(this.state.tab).map(([index1, value1])=>{
                
               if(value1[value.category_name]){

                   return Object.entries(value1[value.category_name]).map(([key, tabs]) => {
                    
                    return tabs
                   })
               }
 
            })

            }
            <div className="row mt-4">
                <div className="col-md-12">
                    <Box sx={{ border: 1, borderColor: 'grey.300', borderRadius: 1, backgroundColor: 'grey.50'}}>
                        <div className="row mt-4 m-1">
                
                            <div className="col-md-4 mb-4">
                            <MaterialTextField  fullWidth label="Estimated Total"
                             name={"estimated["+value.id+"][estimate_total]"} 
                             value={this.state.params["estimated["+value.id+"][estimate_total]"]?this.state.params["estimated["+value.id+"][estimate_total]"]:''}
                             id="estimated_total" />
                            </div>
                            <div className="col-md-4 mb-4">
                            <MaterialTextField fullWidth 
                            label="Add GST" 
                            name={"estimated["+value.id+"][gst]"} 
                            value={this.state.params["estimated["+value.id+"][gst]"]?this.state.params["estimated["+value.id+"][gst]"]:''}
                            id="gst" />
                            </div>
                            <div className="col-md-4 mb-4">
                            <MaterialTextField fullWidth 
                            label="Total" 
                            name={"estimated["+value.id+"][total]"} 
                            value={this.state.params["estimated["+value.id+"][total]"]?this.state.params["estimated["+value.id+"][total]"]:''}
                            id="total" />
                            </div>
                        </div>
                    </Box>
                </div>
            </div>
        </Box>
                )
            })}

        <Box sx={{borderBottom: 2, borderTop: 1, borderColor: 'divider'}}>
            <div className="row mb-4 mt-4">
                <div className="col-md-12 ">
                    <label><b style={{color:"black"}}>Summary Estimation And Assesment of loss</b></label>
                   
                </div>
            </div>
            <div className="row mt-4">
    
                <div className="col-md-4 mb-4">
                <MaterialTextField fullWidth label="Total Cost Of Parts" name="assesssment[part_charges]" id="part_charges" />
                </div>
                <div className="col-md-4 mb-4">
                <MaterialTextField fullWidth label="Net Labour Charges" name="assesssment[labour_charges]" id="labour_charges" />
                </div>
                <div className="col-md-4 mb-4">
                <MaterialTextField fullWidth label="Total" name="assesssment[grand_total]" id="grand_total" />
                <input type="hidden" name="assesssment[status]" value="1"/>
                </div>
            </div>
        </Box>

        <div className="row">

            <div className="col-md-9 mt-4">
                <MaterialButton color="primary" style={{ backgroundColor: '#fff' , border: '1px solid #183883', color: '#183883'}} name="back" text="Back" />
            </div>
            <div className="col-md-3 mt-4 d-flex justify-content-center">
                <MaterialButton style={{ backgroundColor: '#183883'}} type="submit" name="save" className=" " text="Save" />&nbsp;&nbsp;&nbsp;&nbsp;
                <MaterialButton style={{ backgroundColor: '#183883'}} name="save-and-initiate" className=" " text="Save And Initiate" />
            </div>
        </div>
        </form>
    </>
  )
    }
}
