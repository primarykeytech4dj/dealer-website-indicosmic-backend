import React from 'react'

import Api from "../../../../api";

import Box from "@mui/material/Box";
import MaterialButton from "../../../../Tags/MaterialButton";
import MaterialTextField from "../../../../Tags/MaterialTextField";

import MaterialSelect from "../../../../Tags/MaterialSelect";
import Swal from "sweetalert2";

const remark = {
    repair: "Repair",
    replace: "Replace",
    open: "Kept Open" 
};
const status = { closed: "Closed", open: "Kept Open" };


export default class EditDealerEstimation extends React.Component {
    constructor(props){
        super(props);

        this.apiCtrl = new Api();
        this.state = {
            otherData: {
                claimCode:  this.props.claimCode,
            },
            estimation: {
                //orders data
                amount_before_tax: 0.0,
                tax: 0.0,
                amount_after_tax: 0.0,
            },
            estimationDetails: [],
            innerfields: {
                //order details
                category_id: "",
                is_product: "",
                product_id: "",
                remark: "",
                hsn_code: "",
                unit_price: "",
                qty: "",
                gst: "",
                amount_after_tax: "",
                product_info: {},
            },
            productCategory: [],
            services: [],
            tab: [],
            buttonClick: "",
            params: "",
            serviceCategories: {},
            productCategories: {},
            productBatch: [],
            categorywiseProductList: [],
            categoryWiseproductData: [],
        }
    }


    getEstimationDetails = async () => {
        await this.apiCtrl.callAxios("get-assessment-details-new", {assessment_id: this.props.assessment_id}).then((response)=>{
            if(response.success === true){
                
                Object.entries(response.data.assessmentDetails).map(([key, val])=>{
                    var x = this.state.estimationDetails;
                    var services =  val.services;
            
                    this.setState((prev) => ({
                        ...prev,
                        estimationDetails: {
                            ...prev.estimationDetails,
                            [val.category]: {
                                //category id
                                ...prev.estimationDetails[val.category],
                                [val.batch_code]: [], //batch //row
                            },
                        },
                    }));
                    var x = this.state.estimationDetails;
                    x[val.category][val.batch_code][0] = val;
                    this.setState((prev) => ({
                        ...prev,
                        estimationDetails: x,
                    }));
                    // console.log('Value', this.state.estimationDetails)
                    // console.log('STATE', this.state.estimationDetails)
                    var i = 1;
                    services.map((value,index)=>{
                        var y = this.state.estimationDetails;
                        y[val.category][val.batch_code][i++] = value;
                        this.setState((prev) => ({
                            ...prev,
                            estimationDetails: y,
                        }))
                    })
                    
                })
                this.setState({ estimation:  response.data.assessment})
            } else {

            }
        })
    }

    
    componentDidMount() {
        this.getEstimationDetails();
        //this.getServices();
    }

    render(){
        const handleSubmit = (e) => {
            e.preventDefault();
            // var params = {};

            // var formData = new FormData();
            // var x = $("form").serializeArray();
            // //console.log(x);
            // formData.append("assessment_detail", this.state.estimationDetails);
            var data = {
                'claim_code': this.props.claimCode,
                'assessment': this.state.estimation,
                'assessment_id':  this.props.assessment_id,
                'assessment_detail': this.state.estimationDetails
            }
            this.apiCtrl.callAxios("assessment", data).then((response) => {
                if (response.success == true) {
                    Swal.fire({
                        title: "Update Assessment",
                        text: "Updated!",
                        icon: "success",
                        showConfirmButton: false,
                    });
                    // location.reload('/claim-list')
                } else {
                    Swal.fire({
                        title: "Update Assessment",
                        text: JSON.stringify(response.message),
                        icon: "error",
                        showConfirmButton: false,
                    });
                    // console.log("Something Went Wrong");
                }
                // console.log(response);
            });

            // this.setState(old=>({...old,param: params}))
        };

        const handleInputChanges = (data) => {

            var key = Object.keys(data.data);
            var value = Object.values(data.data);
            // data.data.map((val, index) => {
            //     console.log(val, index);
            // });
 
            Object.entries(data.data).map(([productIndex, productValue])=>{

                var x = this.state.estimationDetails;
                x[data.position.category][data.position.batch][data.position.key][productIndex]= productValue;
                // x[1][0][0]['product_id'] = 2;
                
     
                this.setState((prev) => ({
                    ...prev,
                    estimationDetails: {
                        ...prev.estimationDetails,
                        ...x
                    },
                }));
            })
            
            // console.log("Estimation Details Input Changes",this.state.estimationDetails);
        };

        return(
            <>
            <form
                method="POST"
                id="assessment_submit"
                onSubmit={(e) => handleSubmit(e)}
            >
                {/* <input type="hidden" name="claim_code"*/}
                <input
                    type="hidden"
                    name="claim_code"
                    value="eR3u5ieKhACx"
                />
                <div className="row mb-4">
                    <div className="col-md-6">
                        <div className="row">
                            <div className="col-md-4">
                                <label>
                                    <b style={{ color: "black" }}>
                                        Category
                                    </b>
                                </label>
                            </div>
                            {/* <div className="col-md-4">
                                <label>
                                    <b style={{ color: "black" }}>Status</b>
                                </label>
                            </div> */}
                            <div className="col-md-4">
                                <label>
                                    <b style={{ color: "black" }}>
                                        Activity
                                    </b>
                                </label>
                            </div>
                            <div className="col-md-4">
                                <label>
                                    <b style={{ color: "black" }}>
                                        HSN Code
                                    </b>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="row">
                            <div className="col-md-3">
                                {" "}
                                <label>
                                    <b style={{ color: "black" }}>
                                        Unit Price
                                    </b>
                                </label>
                            </div>
                            <div className="col-md-3">
                                {" "}
                                <label>
                                    <b style={{ color: "black" }}>QTY</b>
                                </label>
                            </div>
                            <div className="col-md-3">
                                {" "}
                                <label>
                                    <b style={{ color: "black" }}>GST</b>
                                </label>
                            </div>
                            <div className="col-md-3">
                                <label>
                                    <b style={{ color: "black" }}>Total</b>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                {Object.entries(this.state.estimationDetails).map(
                    ([index, value]) => {
                        // console.log('index', index)
                        return(
                            <>
                                {/* <div  key={index} className="row" >
                                    <div className="col-md- mt-4"> */}
                                    <Box  sx={{ border:1, borderRadius:4, padding:2,  marginBottom:2, borderColor: 'divider' }}>
                                    <div key={index} className="row" id={index}>
                                        <div className="col-md-12 mt-4">
                                    <span style={{color:'black',fontWeight:'bold'}}>{index}</span>
                                        {  Object.entries(value).map(([batchIndex, batchVal]) => {
                                                // console.log('batchIndex',batchVal);
                                                
                                               
                                                    return (
                                                        <>
                                                          <Box  sx={{ borderBottom: 1, borderColor: 'divider', marginBottom:2, }}>
                                                        {Object.entries(batchVal).map(([productIndex,productValue]) => {
                                                                //    console.log(productValue);
                                                                  
                                                                if(productValue.is_product === '1'){
                                                                    return (<ProductInput 
                                                                        data={
                                                                            productValue
                                                                        }
                                                                        position={{ 
                                                                            category: productValue.category_id, 
                                                                            batch: batchIndex, 
                                                                            key: productIndex
                                                                        }} 
                                                                        inputChanges={
                                                                            handleInputChanges
                                                                        }
                                                                        key={productIndex}
                                                                        />)
                                                                } else{
                                                                    return(<ServiceInput
                                                                        data={
                                                                            productValue
                                                                        }
                                                                        position={{ 
                                                                            category: productValue.category_id, 
                                                                            batch: batchIndex, 
                                                                            key: productIndex
                                                                        }} 
                                                                        inputChanges={
                                                                            handleInputChanges
                                                                        }
                                                                        key={productIndex}
                                                                         />)
                                                                }
                                                            }
                                                            
                                                        )}
                                                        </Box>
                                                        </>
                                                    )
                                                    

                                                 
                                            })
                                        }
                                    </div>
                                </div>
                                </Box>
                            </>
                        )
                    })
                    

                        
                }
                  <div className="row">
                
                        <div className="col-md-12 mt-4 d-flex " style={{justifyContent: "right"}}>
                            <MaterialButton
                                style={{ backgroundColor: "#183883" }}
                                type="submit"
                                name="save"
                                className=" "
                                text="Update"
                            />
               
                                &nbsp;&nbsp;&nbsp;&nbsp;
                             <MaterialButton
                                style={{ backgroundColor: "#183883" }}
                                name="save-and-initiate"
                                className=" "
                                type="submit"
                                data-bs-toggle="modal" size='small' href="#exampleModalToggle2" 
                                text="Reject"
                            />
                        </div>
                    </div>

            </form>
            </>
        )
    }
}

function ProductInput(props){
    const [state, setState] = React.useState({
  
        product: {'': "select Product" },
        is_product: "",
        product_id: "",
 

    });

    React.useEffect(()=>{
        setState({...state, ...props.data})
    },[])

    // var productAmt = 0;
    const [productAmt, setProductAmt] = React.useState(0);

    const data = { yes: "product1", product2: "product2" };

    const handleChange = (e) => {
      
            setState({
                ...state,
                [e.target.name]: e.target.value,
            });
            props.inputChanges({
                data: { [e.target.name]: e.target.value},
                position: props.position,
            });
        
    };
    React.useEffect(()=>{
        handleCalculate();
    },[state])

    const handleCalculate  = async () => {

        if((state.unit_price !== '') && (typeof state.unit_price !== 'undefined')){

            var Amnt = parseFloat(state.unit_price).toFixed(2);
            var qty = 1;
            if((state.qty !== '') && (typeof state.qty !== 'undefined'))
            {
                qty =  parseFloat(state.qty).toFixed(2)
            }
            var amt = Amnt*qty;
            var tax = 0.00;
            if((state.gst !== '') && (typeof state.gst !== 'undefined'))
            {
                tax = parseFloat(state.gst).toFixed(2);
            }
            var total = amt+(amt*tax/100.00);
            setProductAmt(total);
        }
        
    }

    return(
        <div className="row mt-4" key={props.key}>
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-4 mb-4">
                        <input type="hidden" name={"is_product"} />
                        <MaterialTextField
                            value={state.product ? state.product: ""}
                    
                            id={"product_0"}
                            labelId={
                                "product_label_product_id_0"
                            }
                            disabled={true}
                            name={"product_id"}
                            label="Select Product"
                            fullWidth
              
                       
                        />
                    </div>
                    {/* <div className="col-md-4 mb-4">
                        <MaterialSelect
                            data={status}
                            onChange={(e) => handleChange(e)}
                            id={"status_0"}
                            labelId={
                                "status_label_status_id_0"
                            }
                            name="status"
              
                            value={state.status ? state.status : ""}
                            label="--Select Status--"
                            fullWidth
                        />
                    </div> */}
                    <div className="col-md-4 mb-4">
                        <MaterialSelect
                            data={remark}
                            onChange={(e) => handleChange(e)}
                            id={"remark_0"}
                            labelId={
                                "remark_label_remark_id_0"
                            }
                            name="remark"
                 
                            value={state.remark ? state.remark : ""}
                            label="--Select Remark--"
                            fullWidth
                        />
                    </div>
                    <div className="col-md-4 mb-4">
                        <label>
                            <b>
                                <input
                                    type="hidden"
                          
                                    name="hsn_code"
                                    value={state.hsn_code ? state.hsn_code : ""}
                                    onChange={(e) => {handleChange(e)}}
                                />
                                {state.hsn_code ? state.hsn_code : ""}
                            </b>
                        </label>
                    </div>
                </div>
            </div>
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="Part Amount"
                            name="unit_price"
                            id={"unitprice_"}
                            required={true}
                            value={state.unit_price?state.unit_price:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="Qty"
                            name="qty"
                            id={"qty_"}
                            required={true}
                            value={state.qty?state.qty:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="GST %"
                            name="gst"
                            id={"gst_"}
                            required={true}
                            value={state.gst?state.gst:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="Estimated Amount"
                            name={"amount_after_tax"}
                            id={"estimateAmount_"}
                            value={productAmt?productAmt:''}
                            // onChange={(e) => {handleChange(e)}}
                        />
                    </div>
                </div>
            </div>
        </div>
    )
}

function ServiceInput(props) {

    const apiCtrl = new Api();
    const [state, setState] = React.useState({
        product_id: "",
        product: {'': "select Product" },
    });

    const [productAmt, setProductAmt] = React.useState(0);

    React.useEffect(()=>{
        setState({...state, ...props.data})
    },[])

    React.useEffect(()=>{
        handleCalculate();
    },[state])
    const handleChange = (e) => {
    
        setState({
            ...state,
            [e.target.name]: e.target.value,
        });
        props.inputChanges({
            data: { [e.target.name]: e.target.value},
            position: props.position,
        });
    
    };

    const handleCalculate  = async () => {

        if((state.unit_price !== '') && (typeof state.unit_price !== 'undefined')){

            var Amnt = parseFloat(state.unit_price).toFixed(2);
            var qty = 1;
            if((state.qty !== '') && (typeof state.qty !== 'undefined'))
            {
                qty =  parseFloat(state.qty).toFixed(2)
            }
            var amt = Amnt*qty;
            var tax = 0.00;
            if((state.gst !== '') && (typeof state.gst !== 'undefined'))
            {
                tax = parseFloat(state.gst).toFixed(2);
            }
            var total = amt+(amt*tax/100.00);
            setProductAmt(total);
        }
        
    }
    return (
        <div className="row">
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-4 mb-4">
                    <span><b> {props.data.product}</b></span>
                    </div>
                    {/* <div className="col-md-4 mb-4"></div> */}
                    <div className="col-md-4 mb-4"></div>
                    <div className="col-md-4 mb-4">
                        <span><b>{props.data.hsn_code}</b></span>
                        <input type="hidden" value={props.data.id?props.data.id:''} name={"product_id"} />
          
                    </div>
                </div>
            </div>
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="Part Amount"
                            name={"unit_price"}
                            id={"unitprice_"}
                            required={true}
                            value={state.unit_price?state.unit_price:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="Qty"
                            name={"qty"}
                            id={"qty_"}
                            required={true}
                            value={state.qty?state.qty:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="GST %"
                            name={"gst"}
                            id={"gst_"}
                            required={true}
                            value={state.gst?state.gst:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField
                            fullWidth
                            label="Estimated Amount"
                            name={"amount_after_tax"}
                            id={"estimateAmount_"}
                            value={productAmt?productAmt:''}
                        />
                    </div>
                </div>
            </div>
   
        </div>


    );
}