import React, { useEffect } from "react";

import Box from "@mui/material/Box";
import MaterialButton from "../../../../Tags/MaterialButton";
import MaterialTextField from "../../../../Tags/MaterialTextField";

import MaterialSelect from "../../../../Tags/MaterialSelect";

import Api from "../../../../api";
import { param } from "jquery";
import Swal from "sweetalert2";
import AssignClaim from "../AssignClaim/AssignClaim";


const remark = {
    repair: "Repair",
    replace: "Replace",
    open: "Kept Open" 
};
const status = { closed: "Closed", };



export default class DealersEstimation extends React.Component {
    constructor(props) {
        super(props);

        this.apiCtrl = new Api();
        this.state = {
            otherData: {
                claimCode: this.props.data.claimCode,
            },

            estimation: {
                //orders data
                type:this.props.type,
                amount_before_tax: 0.0,
                tax: 0.0,
                amount_after_tax: 0.0,
            },
            estimationDetails: [],
            innerfields: {
                //order details
                category_id: "",
                is_product: "",
                product_id: "",
                remark: "",
                hsn_code: "",
                unit_price: "",
                qty: "",
                gst: "",
                amount_after_tax: "",
                product_info: {},
            },
            productCategory: [],
            services: [],
            tab: [],
            buttonClick: "",
            params: "",
            serviceCategories: {},
            productCategories: {},
            productBatch: [],
            categorywiseProductList: [],
            categoryWiseproductData: [],
        };
        this.AssessmentState = React.createRef();
    }

    getProductCategory = () => {
        this.apiCtrl
            .callAxios("product/product-category-list", [])
            .then((response) => {
                if (response.success == true) {
                    this.setState({ productCategory: response.data });
                    this.state.productCategory.map((value, index) => {
                        this.setState((prev) => ({
                            ...prev,
                            estimationDetails: {
                                ...prev.estimationDetails,
                                [value.id]: {
                                    //category id
                                    ...prev.estimationDetails[value.id],
                                    [0]: [], //batch //row
                                },
                            },
                        }));
                        var x = this.state.estimationDetails;
                        x[value.id][0][0] = this.state.innerfields;
                        this.setState((prev) => ({
                            ...prev,
                            estimationDetails: x,
                        }));

                        this.setState((prev) => ({
                            ...prev,
                            productBatch: {
                                ...prev.productBatch,
                                [value.id]: value.category_name,
                            },
                        }));
                    });
                    // console.log(
                    //     "1st estimation=",
                    //     this.state.estimationDetails
                    // );
                }
            })
            .then((res) => {
                this.getServices();
            });
    };
    getServices = async () => {
        await this.apiCtrl.callAxios("service-list", []).then((response) => {
            if (response.success == true) {
                //console.log("hii");
                this.setState({ services: response.data });
                const batch = Object.keys(this.state.productBatch);

                // console.log(inner);
                // return;
                var a = [];
                batch.map((bvalue, bindex) => {
                    //console.log(bindex + " " + bvalue);
                    //var x = this.state.estimationDetails[bvalue][0];
                    this.state.services.map((serviceVal, serviceIndex) => {
                        var inner = {
                            //order details
                            category_id: "",
                            is_product: "",
                            product_id: "",
                            remark: "",
                            hsn_code: "",
                            unit_price: "",
                            qty: "",
                            gst: "",
                            amount_after_tax: "",
                            product_info: {},
                        };
                        //console.log("inner before", inner);
                        // console.log("service val=", serviceVal);
                        inner.is_product = '0';
                        inner.product_info = serviceVal;
                        inner.product_id = serviceVal.id;
                        inner.remark = serviceVal.product;
                        inner.hsn_code = serviceVal.hsn_code;
                        inner.product_name = serviceVal.product;
                        inner.category_id = serviceVal.product_category_id;
                        //console.log(inner);
                        //console.log("inner after", inner);
                        // this.setState((prev) => ({
                        //     ...prev,
                        //     estimationDetails: {
                        //         ...prev.estimationDetails,
                        //         [bvalue]: {
                        //             //category id
                        //             ...prev.estimationDetails[bvalue],
                        //             [0]: [], //batch //row
                        //         },
                        //     },
                        // }));
                        // // console.log("after inner=", inner);
                        var x = this.state.estimationDetails;
                        x[bvalue][0][serviceIndex + 1] = inner;
                        this.setState((prev) => ({
                            ...prev,
                            estimationDetails: x,
                        }));
                    });
                });

                //console.log("2nd estimation=", this.state.estimationDetails);
            }
        });
    };

    componentDidMount() {
        this.getProductCategory();
        //this.getServices();
    }

    componentDidUpdate(prevProps, prevState) {
        // if(prevState.services !== this.state.services) {
        //     this.getProductCategory();
        // }
    }

    render() {
        const handleComponentChange = (data) => {
            this.setState((old) => ({
                ...old,
                categorywiseProductList: {...old.categorywiseProductList, ...data },
            }));

            console.log("categorywiseProductList", data);
        };

        const handlecategoryWiseproductData = (data) => {
            this.setState((old) => ({
                ...old,
                categoryWiseproductData: {...old.categoryWiseproductData, ...data },
            }));
        }

        const handleInputChanges = (data) => {
            console.log("input triggered ", data);
            var key = Object.keys(data.data);
            var value = Object.values(data.data);
            // data.data.map((val, index) => {
            //     console.log(val, index);
            // });
            console.log("key", key[0]);
            Object.entries(data.data).map(([productIndex, productValue])=>{

                var x = this.state.estimationDetails;
                x[data.position.categoryId][data.position.batch][data.position.key][productIndex]= productValue;
                // x[1][0][0]['product_id'] = 2;
                
                console.log("estimation object",x);
                this.setState((prev) => ({
                    ...prev,
                    estimationDetails: {
                        ...prev.estimationDetails,
                        ...x
                    },
                }));
            })
            
            // console.log("Estimation Details Input Changes",estimationDetails);
        };
        const handleSubmit = (e) => {
            e.preventDefault();
            // var params = {};

            // var formData = new FormData();
            // var x = $("form").serializeArray();
            // //console.log(x);
            // formData.append("assessment_detail", this.state.estimationDetails);
            var data = {
                'claim_code': this.props.data.claimCode,
                'assessment': this.state.estimation,
                'assessment_detail': this.state.estimationDetails
            }
            this.apiCtrl.callAxios("assessment", data).then((response) => {
                if (response.success == true) {
                    Swal.fire({
                        title: "Create Assessment",
                        text: "Created!",
                        icon: "success",
                        showConfirmButton: false,
                    });
                    location.reload('/claim-list')
                } else {
                    Swal.fire({
                        title: "Create Assessment",
                        text: JSON.stringify(response.message),
                        icon: "error",
                        showConfirmButton: false,
                    });
                    console.log("Something Went Wrong");
                }
                console.log(response);
            });

            // this.setState(old=>({...old,param: params}))
        };

        const categoryList = this.state.productCategory;

        const handleAddMore = (e, categoryId) => {
            var batch = this.state.estimationDetails;
            batch[categoryId][Object.keys(batch[categoryId]).length] =batch[categoryId][0];
            this.setState((prev) => ({
                ...prev,
                estimationDetails: {
                    ...prev.estimationDetails,
                   ...batch
                },
            }));

            console.log("ADD MORE", batch)

            console.log("Estimation Details State",this.state.estimationDetails);
           console.log("ADD MORE LENGTH", Object.keys(batch).length)
        }
        return (
            <>
                {/* <form
                    method="POST"
                    id="assessment_submit"
                    onSubmit={(e) => handleSubmit(e)}
                > */}
                    {/* <input type="hidden" name="claim_code"*/}
                    <input
                        type="hidden"
                        name="claim_code"
                        value="eR3u5ieKhACx"
                    />
                    <div className="row mb-4">
                        <div className="col-md-6">
                            <div className="row">
                                <div className="col-md-4">
                                    <label>
                                        <b style={{ color: "black" }}>
                                            Category
                                        </b>
                                    </label>
                                </div>
                                {/* <div className="col-md-4">
                                    <label>
                                        <b style={{ color: "black" }}>Status</b>
                                    </label>
                                </div> */}
                                <div className="col-md-4">
                                    <label>
                                        <b style={{ color: "black" }}>
                                            Activity
                                        </b>
                                    </label>
                                </div>
                                <div className="col-md-4">
                                    <label>
                                        <b style={{ color: "black" }}>
                                            HSN Code 
                                        </b>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="row">
                                <div className="col-md-3">
                                    {" "}
                                    <label>
                                        <b style={{ color: "black" }}>
                                            Unit Price
                                        </b>
                                    </label>
                                </div>
                                <div className="col-md-3">
                                    {" "}
                                    <label>
                                        <b style={{ color: "black" }}>QTY</b>
                                    </label>
                                </div>
                                <div className="col-md-3">
                                    {" "}
                                    <label>
                                        <b style={{ color: "black" }}>GST</b>
                                    </label>
                                </div>
                                <div className="col-md-3">
                                    <label>
                                        <b style={{ color: "black" }}>Total</b>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    {Object.entries(this.state.estimationDetails).map(
                        ([index, value]) => {
                            //console.log(value);

                            return(
                                <>
                                            <Box  sx={{ border:1, borderRadius:4, padding:2,  marginBottom:2, borderColor: 'divider' }}>
                                    <div key={index} className="row" id={index}>
                                        <div className="col-md-12 mt-4">
                                           
                                        
                                            {
                                                this.state.productBatch[
                                                    index
                                                ]
                                            }
                                            {    Object.entries(value).map(
                                                ([batchIndex, batchVal]) => {
                                                    //console.log(batchIndex);
                                                    return (
                                                    
                                                         <Box  sx={{ borderBottom: 1, borderColor: 'divider', marginBottom:2, }}>
                                                            {Object.entries(
                                                                batchVal
                                                            ).map(
                                                                ([
                                                                    productIndex,
                                                                    productValue,
                                                                ]) => {
                                                                    if (productIndex == 0) {
                                                                        return (
                                                                            <ProductInput
                                                                                key={
                                                                                    productIndex
                                                                                }
                                                                                data={
                                                                                    productValue
                                                                                }
                                                                                position={{
                                                                                    categoryId:
                                                                                        index,
                                                                                    batch: batchIndex,
                                                                                    key: productIndex,
                                                                                }}
                                                                                func={
                                                                                    handleComponentChange
                                                                                }
                                                                                inputChanges={
                                                                                    handleInputChanges
                                                                                }
                                                                                categorywiseProductList={
                                                                                    this
                                                                                        .state
                                                                                        .categorywiseProductList
                                                                                }
                                                                                categoryWiseproductData={
                                                                                    this.state.categoryWiseproductData
                                                                                }

                                                                                producData={
                                                                                    handlecategoryWiseproductData
                                                                                }
                                                                            />
                                                                        );
                                                                    } else {
                                                                        return (
                                                                            <ServiceInput
                                                                                key={
                                                                                    productIndex
                                                                                }
                                                                                data={
                                                                                    productValue
                                                                                }
                                                                                position={{
                                                                                    categoryId:
                                                                                        index,
                                                                                    batch: batchIndex,
                                                                                    key: productIndex,
                                                                                }}
                                                                                func={
                                                                                    handleComponentChange
                                                                                }
                                                                                inputChanges={
                                                                                    handleInputChanges
                                                                                }
                                                                                categorywiseProductList={
                                                                                    this
                                                                                        .state
                                                                                        .categorywiseProductList
                                                                                }
                                                                            />
                                                                        );
                                                                    }
                                                                }
                                                            )}
                                                        </Box>
                                                        
                                                    );
                                                }
                                            )}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-12 d-flex" style={{justifyContent:"right"}}>
                                            <MaterialButton style={{ backgroundColor: '#183883'}} onClick={(e)=>{handleAddMore(e, index)}} className="float-right" text={"Add More "+ this.state.productBatch[index]+ " Part"} />
                                        </div>
                                    </div>
                                                </Box>
                                </>
                                
                            )
                        }
                    )}

                    <div className="row">
                        <div className="col-md-3 mt-4">
                            <MaterialButton
                                color="primary"
                                style={{
                                    backgroundColor: "#fff",
                                    border: "1px solid #183883",
                                    color: "#183883",
                                }}
                                name="back"
                                text="Back"
                            />
                        </div>
                        <div className="col-md-9 mt-4 d-flex " style={{justifyContent: "right"}}>
                            <MaterialButton
                                style={{ backgroundColor: "#183883" }}
                                // type="submit"
                                name="save"
                                className=" "
                                text="Save as Draft"
                                onClick={(e) => handleSubmit(e)}
                            />
                            {/* &nbsp;&nbsp;&nbsp;&nbsp;
                            <MaterialButton
                                style={{ backgroundColor: "#183883" }}
                                name="save-and-initiate"
                                className=" "
                                // type="submit"
                                data-bs-toggle="modal" size='small' href="#exampleModalToggle1" 
                                text="Save And Assign Agent"
                                onClick={(e) => handleSubmit(e)}
                            /> */}
                                {/* &nbsp;&nbsp;&nbsp;&nbsp;
                             <MaterialButton
                                style={{ backgroundColor: "#183883" }}
                                name="save-and-initiate"
                                className=" "
                                // type="submit"
                                data-bs-toggle="modal" size='small' href="#exampleModalToggle2" 
                                text="Save And Assign Workshop"
                                onClick={(e) => handleSubmit(e)}
                            /> */}
                        </div>
                    </div>
                         <Model claimCode={this.props.data.claimCode} />
                {/* </form> */}
            </>
        );
    }
}

// function AssessmentCategoryWise(props)

function ServiceInput(props) {

    const apiCtrl = new Api();
    const [state, setState] = React.useState({
        product_id: "",
        product: {'': "select Product" },
    });

    const [productAmt, setProductAmt] = React.useState(0);

    React.useEffect(()=>{
        handleCalculate();
    },[state])

    const handleChange = (e) => {
    
        setState({
            ...state,
            [e.target.name]: e.target.value,
        });
        props.inputChanges({
            data: { [e.target.name]: e.target.value},
            position: props.position,
        });
    
    };

    const handleCalculate  = async () => {

        if((state.unit_price !== '') && (typeof state.unit_price !== 'undefined')){

            var Amnt = parseFloat(state.unit_price).toFixed(2);
            var qty = 0;
            if((state.qty !== '') && (typeof state.qty !== 'undefined'))
            {
                qty =  parseFloat(state.qty).toFixed(2)
            }
            var amt = Amnt*qty;
            var tax = 0.00;
            if((state.gst !== '') && (typeof state.gst !== 'undefined'))
            {
                tax = parseFloat(state.gst).toFixed(2);
            }
            var total = amt+(amt*tax/100.00);
            setProductAmt(total);
        }
        
    }
    return (
        <div className="row">
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-4 mb-2">
                        {props.data.product_info.product}
                    </div>
                    <div className="col-md-4 mb-2"></div>
                    {/* <div className="col-md-3 mb-2"></div> */}
                    <div className="col-md-4 mb-2">
                        {props.data.product_info.hsn_code}
                        <input type="hidden" value={props.data.product_info.id?props.data.product_info.id:''} name={"product_id"} />
          
                    </div>
                </div>
            </div>
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="Part Amount"
                            name={"unit_price"}
                            id={"unitprice_"}
                           
                            value={state.unit_price?state.unit_price:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="Qty"
                            name={"qty"}
                            id={"qty_"}
                           
                            value={state.qty?state.qty:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="GST %"
                            name={"gst"}
                            id={"gst_"}
                           
                            value={state.gst?state.gst:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="Estimated Amount"
                            name={"amount_after_tax"}
                            id={"estimateAmount_"}
                            value={productAmt?productAmt:''}
                        />
                    </div>
                </div>
            </div>
   
        </div>


    );
}

function ProductInput(props) {
    const apiCtrl = new Api();
    const [state, setState] = React.useState({
  
        product: {'': "select Product" },
        is_product: "",
        product_id: "",
 

    });

    React.useEffect(()=>{
        handleCalculate();
    },[state])
    // var productAmt = 0;
    const [productAmt, setProductAmt] = React.useState(0);

    const data = { yes: "product1", product2: "product2" };

    const handleChange = (e) => {
        if("product_id" === e.target.name) {
            props.categoryWiseproductData[props.position.categoryId].map((value, index)=>{
                
                if(value.id === e.target.value){                  
                    var products = {category_id:value.product_category_id, product_id : value.id, hsn_code: value.hsn_code, unit_price:value.base_price, gst:value.gst, product_info:value, is_product:'1'}
                    setState({
                        ...state,
                        ...products
                    });
                    props.inputChanges({
                        data: { ...products},
                        position: props.position,
                    });
                }
                
            })
        } else {
                setState({
                ...state,
                [e.target.name]: e.target.value,
            });
            props.inputChanges({
                data: { [e.target.name]: e.target.value},
                position: props.position,
            });
        }
    };

    const handleCalculate  = async () => {

        if((state.unit_price !== '') && (typeof state.unit_price !== 'undefined')){

            var Amnt = parseFloat(state.unit_price).toFixed(2);
            var qty = 1;
            if((state.qty !== '') && (typeof state.qty !== 'undefined'))
            {
                qty =  parseFloat(state.qty).toFixed(2)
            }
            var amt = Amnt*qty;
            var tax = 0.00;
            if((state.gst !== '') && (typeof state.gst !== 'undefined'))
            {
                tax = parseFloat(state.gst).toFixed(2);
            }
            var total = amt+(amt*tax/100.00);
            setProductAmt(total);
        }
        
    }

    const loadCategorywiseProducts = (categoryId) => {
        //on click
        //alert(props.categorywiseProductList[categoryId]);
        console.log('Categroywise Prduclisy', props.categorywiseProductList)
        if ( props.categorywiseProductList.hasOwnProperty(categoryId) ) {
            setState((old) => ({
                ...old,
                product: {
                    ...old.product, ... props.categorywiseProductList[categoryId]
                },
            }));
        } else {
            apiCtrl.callAxios("product/list", {product_category_id: categoryId,})
                .then((response) => {
                    // console.log(response.data);

                    if (response.success == true) {

                        props.producData({[categoryId]: response.data})

                        var product = {};
                        response.data.map((pvalue, pindex) => {
                            product = {...product, [pvalue.id]: pvalue.product}
                            //     setState({
                            //         products: response.data,
                            //     });
                        });
                        setState((old) => ({
                            ...old,
                            product: {
                                ...old.product, ...product
                            },
                        }));
                        props.func({
                            [categoryId]: product,
                        });

                        console.log('Prodducts', product);
                    }
                });
        }
    };
    // useEffect(() => {
    //     loadCategorywiseProducts(props.position.categoryId);
    // }, []);
    return (
        <div className="row">
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-4 mb-2">
                        <input type="hidden" name={"is_product"} />
                        <MaterialSelect
                            data={state.product}
                            value={state.product_id ? state.product_id : ""}
                            onChange={(e) => handleChange(e)}
                            id={"product_" + +"_" + +"_0"}
                            labelId={
                                "product_label_" + +"_" + +"_product_id" + "_0"
                            }
                            name={"product_id"}
                            label="Select Product"
                            fullWidth
                           
                            onMouseEnter={(e) =>
                                {loadCategorywiseProducts(
                                    props.position.categoryId
                                )}
                            }
                        />
                    </div>
                    {/* <div className="col-md-4 mb-2">
                        <MaterialSelect
                            data={status}
                            onChange={(e) => handleChange(e)}
                            id={"status_" + +"_" + +"_0"}
                            labelId={
                                "status_label_" + +"_" + +"_status_id" + "_0"
                            }
                            name="status"
                           
                            value={state.status ? state.status : ""}
                            label="--Select Status--"
                            fullWidth
                        />
                    </div> */}
                    <div className="col-md-4 mb-2">
                        <MaterialSelect
                            data={remark}
                            onChange={(e) => handleChange(e)}
                            id={"remark_" + +"_" + +"_0"}
                            labelId={
                                "remark_label_" + +"_" + +"_remark_id" + "_0"
                            }
                            name="remark"
                           
                            value={state.remark ? state.remark : ""}
                            label="--Select Remark--"
                            fullWidth
                        />
                    </div>
                    <div className="col-md-4 mb-2">
                        <label>
                            <b>
                                <input
                                    type="hidden"
                          
                                    name="hsn_code"
                                    value={state.hsn_code ? state.hsn_code : ""}
                                    onChange={(e) => {handleChange(e)}}
                                />
                                {state.hsn_code ? state.hsn_code : ""}
                            </b>
                        </label>
                    </div>
                </div>
            </div>
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="Part Amount"
                            name="unit_price"
                            id={"unitprice_"}
                           
                            value={state.unit_price?state.unit_price:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="Qty"
                            name="qty"
                            id={"qty_"}
                           
                            value={state.qty?state.qty:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="GST %"
                            name="gst"
                            id={"gst_"}
                           
                            value={state.gst?state.gst:''}
                            onChange={(e) => {handleChange(e), handleCalculate(e)}}
                        />
                    </div>
                    <div className="col-md-3 mb-2">
                        <MaterialTextField
                            fullWidth
                            label="Estimated Amount"
                            name={"amount_after_tax"}
                            id={"estimateAmount_"}
                            value={productAmt?productAmt:''}
                            // onChange={(e) => {handleChange(e)}}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}


function Model(props){
    // var id=props.userid.id
    // console.log("id=====>",id)

   //console.log(props.eventid)
    return(
      <>
     
        <div className="modal fade" id="exampleModalToggle1" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
          <div className="modal-header">
              {/* <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5> */}
              <div className="row ml-1" style={{ paddingTop: '2%'}}>
                  {/* <label><b>{props.params.any} Details</b></label> */}
              </div>
              <button type="button"   data-bs-dismiss="modal" className="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            
            <div className="modal-body m-body">
              
            <div className="row">
              {/* <AddUsers  params={this.props.params}  /> */}
              <AssignClaim  claim_code={props.claimCode} userType={'agent'}/>
  
            </div>
              
           
            </div>  
  
            
          </div>
        </div>
        </div>
  
        <div className="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabe2" tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
          <div className="modal-header">
              {/* <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5> */}
              <div className="row ml-1" style={{ paddingTop: '2%'}}>
                  {/* <label><b>{props.params.any} Details</b></label> */}
              </div>
              <button type="button"   data-bs-dismiss="modal" className="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            
            <div className="modal-body m-body">
              
            <div className="row">
              {/* <AddUsers  params={this.props.params}  /> */}
              <AssignClaim  claim_code={props.claimCode} userType={'workshop'}/>
  
            </div>
              
           
            </div>  
  
            
          </div>
        </div>
        </div>
      </>
    )
  }