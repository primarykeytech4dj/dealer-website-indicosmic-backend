import React, { useEffect } from 'react'
import Box  from '@mui/material/Box';



import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../Tags/MaterialTextArea'

const subCategory = ['Bonet', 'Roof', 'Door'];
const remark = {'Repairable':'Repairable', 'Un-Repairable':'Un-Repairable', 'Replace':'Replace'};


import Api from '../../../../api';


 export class CommonDealersEstimationType extends React.Component{
    constructor(props){
        super(props);

        this.apiCtrl = new Api;
        this.state = {
            product : [],
            service : [],
            product_data: '',
            products: '',
            service_data: '',
            services: this.props.service ? this.props.service :[],
            params: {
                [0]:'',

            },
            ["category_"+this.props.category_id]:{
                ["row_"+this.props.id]:{

                }
            }
            
        }

    }

    getProductByCategory = () =>{
 
        this.apiCtrl.callAxios('product/list', {product_category_id : this.props.category_id}).then(response => {
            if(response.success == true){
                response.data.map((value, index)=>{
                    this.setState(old=>({
                        ...old, product: {...old.product, [value.id] : [value.product]}
                    }))
                    this.setState({
                        products: response.data})
                })
            } 
        })

    }
    

    componentDidMount() {

        this.getProductByCategory(); 
    }


    componentDidUpdate( prevProps, prevState) {
        if(prevState.param !== this.state.param) {
            this.props.funcs(...this.state.param)
        }

    }
    
 render() {

    const handleChange = (e) => {
        if("assessment_detail["+this.props.category_name+"]["+this.props.id+"][0][product_id]" === e.target.name) {
            this.state.products.map((value, index)=>{
                if(value.id === e.target.value) {
                    
                    
                    this.setState(old=> ({...old,product_data: value}))
                    // console.log(this.state);
                }
            })
            
            
        }
        console.log('Value', e)
        if(typeof  e.target.id !== 'undefined'){

            console.log('SPLIT', e.target.id)
            var array = e.target.id.split("_");
            var Amnt = 0;
            var qty = 1;
            var amt = 0;
            
            Amnt = parseFloat($("#unitprice_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val()).toFixed(2);
            if(($("#qty_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== "NaN") &&  ($("#qty_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== ""))
            {
                qty =  parseFloat($("#qty_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val()).toFixed(2)
            }
            amt = Amnt*qty;
            var tax = 0.00;
            if(($("#gst_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== "NaN") &&  ($("#gst_"+this.props.category_name+"_"+this.props.id+"_"+array[3]).val() !== ""))
            {
                tax = parseFloat($("#gst_"+this.props.category_name +"_"+this.props.id+"_"+array[3]).val()).toFixed(2);
            }
            var total = amt+(amt*tax/100.00);
            
            console.log('Total', total)

            this.setState(old=> ({...old, param:{...old.param, ["assessment_detail["+this.props.category_name+"]["+this.props.id+"]["+array[3]+"][amount_after_tax]"]: total}}))
    
    
            var length = (this.state.services.length);
    
            var estimate = 0;
            var gstAmount = 0;
            var totalEstimate = 0;
            for(var i = 0; i<= length; ++i ){
                console.log('Index', array[1]+"_"+array[2]+i)
                estimate =  parseFloat((estimate +$("#unitprice_"+array[1]+"_"+array[2]+"_"+i).val())).toFixed(2);
                console.log('Estimate ',  estimate)
                totalEstimate =  parseFloat((totalEstimate + $("#estimateAmount_"+array[1]+"_"+array[2]+"_"+i).val())).toFixed(2);
                console.log('totalEstimate Value',  totalEstimate)
            }
    
            // $('#')
            console.log('Estimate ', estimate);
            console.log('TotalEstimate ', totalEstimate);
            this.setState(old=> ({
                ...old, param:{...old.param, ["estimated["+array[1]+"][estimate_total]"]:estimate}
            }))
            
            this.setState(old=> ({
                ...old, param:{...old.param, ["estimated["+array[1]+"][gst]"]:  parseFloat((totalEstimate-estimate)).toFixed(2) }
            }))
            this.setState(old=> ({
                ...old, param:{...old.param, ["estimated["+array[1]+"][total]"]:totalEstimate}
            }))
        }


        
        
        this.setState(old=> ({...old,param:{...old.param, [e.target.name]: [e.target.value]}}))

       
    }

    const handleCommonProductRow = (data) => {
        this.setState(old=>({...old, }))
        this.props.funcs({data:data.data, category_id:"category_id"+this.props.category_id, row: this.props.id, id:data.id})
        // console.log('handleCommonProductRow', data);
    }

  
    return(
        <>
            <Box sx={{ borderBottom: 1, borderColor: 'divider'}} key={this.props.key}>
            <CommonProductRow 
            product={this.state.product} 
            products={this.state.products} 
            category_name={this.props.category_name} 
            category_id={this.props.category_id}
            id={this.props.id}
            funcsss={handleCommonProductRow}
             />
          

                {this.state.services.map((value, index)=>{
                    return(
                        <>
                        <CommonServicesRows func2={handleCommonProductRow} value={value} id={(index)} />
                        
                        </>
                    )
                   
                })}
                {/*  */}
            </Box>
        </>
    )
 }
}

export function CommonProductRow (props){


    const [state, setState] = React.useState({
    
            is_product:'',
            product_id: '',
            remark:'',
            hsn_code:'',
            unit_price: '',
            qty: '',
            gst: '',
            amount_after_tax: '',

        
    })

    const [productData, setProductData] = React.useState({});
    const handleChange = (e) => {
        if("product_id" === e.target.name) {
            props.products.map((value, index)=>{
                if(value.id === e.target.value) {
                    
                    
                    setProductData(value)
                    // console.log(this.state);
                }
            })
            
            
        }
        setState(old =>({...old,[e.target.name]: e.target.value}))
     
    }

    useEffect(()=>{
    
        props.funcsss({data:state, id:0});

    },[state])
    return(
        <>
        <div className="row">
            
            <div className="col-md-6">
                <div className="row">

                    <div className="col-md-4 mb-4">
                        <input type="hidden" 
                            value={productData.is_active?productData.is_active: 
                                (state.is_product?state.is_product: '')
                            }
                            onChange={(e)=>handleChange(e)} 
                            name={"is_product"}  
                        />
                        <MaterialSelect 
                        data={props.product} 
                        value={state.product_id ? state.product_id : ''} 
                        onChange={(e)=>handleChange(e)} 
                        
                        id={"product_"+props.category_name+"_"+props.id+"_0"} 
                        labelId={"product_label_"+props.category_name+"_"+props.id+"_product_id"+"_0"}
                        name={"product_id"}  
                        label="Select Product" fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <MaterialSelect data={remark}  
                        onChange={(e)=>handleChange(e)} 
                        id={"remark_"+props.category_name+"_"+props.id+"_0"} 
                        labelId={"remark_label_"+props.category_name+"_"+props.id+"_remark_id"+"_0"}
                        name={"remark"}    
                        value={state.remark ? state.remark : ''} 
                        label="--Select Remark--" 
                        fullWidth/>
                    </div>
                    <div className="col-md-4 mb-4">
                        <label ><b >
                        
                            <input type="hidden" 
                                value={productData.hsn_code ? productData.hsn_code : ''} 
                                name={"hsn_code"}  
                                onChange={(e)=>handleChange(e)} 
                                />
                        {productData.hsn_code?productData.hsn_code: 
                                (state.hsn_code?state.hsn_code: '')
                            }
                        
                            </b></label>
                    </div>
                </div>


            
            </div>
            <div className="col-md-6">
                <div className="row">
                    {/* <div className="col-md-12 mb-4"> */}
                        {/* <CommonAmountQtyGst key="0" {...props} data={state.product_data} /> */}
                
                        <div className="col-md-3 mb-4">
                            <MaterialTextField fullWidth
                                label="Part Amount"
                                //  name="part-amount"
                                onChange={handleChange}
                                value={ 
                                    (state.unit_price?state.unit_price: productData.base_price?productData.base_price:'')
                                }
                                name={"unit_price"}    
                                id={"unitprice_"+props.category_name+"_"+props.id+"_0"} 
                            />
                        </div>
                        <div className="col-md-3 mb-4">
                            <MaterialTextField fullWidth 
                                label="Qty"
                                onChange={handleChange} 
                                value={ 
                                    (state.qty?state.qty: productData.qty?productData.qty:'')
                                }

                                name={"qty"}    
                                id={"qty_"+props.category_name+"_"+props.id+"_0"} 
                            
                            />
                        </div>
                        <div className="col-md-3 mb-4">
                            <MaterialTextField fullWidth 
                                label="GST %" 
                                onChange={handleChange}
                                value={
                                    (state.gst?state.gst: productData.gst?productData.gst:  '')
                                }
                    
                                name={"gst"}    
                                id={"gst_"+props.category_name+"_"+props.id+"_0"} 
                                />
                            </div>
                            <div className="col-md-3 mb-4">
                            <MaterialTextField 
                                fullWidth 
                                onChange={handleChange}
                                label="Total Amount"
                        
                                value={state.amount_after_tax?state.amount_after_tax: ''}
                                name={"amount_after_tax"}    
                                id={"estimateAmount_"+props.category_name+"_"+props.id+"_0"}  />
                            </div>
                    {/* </div> */}
                </div>
            </div>
        </div>
        </>
    );
    
}


function CommonServicesRows(props){

    const [state, setState] = React.useState({
        is_product:0,
        product_id: props.value.id,
        remark:'',
        hsn_code:props.value.hsn_code,
        unit_price: '',
        qty: '',
        gst: '',
        amount_after_tax: '',
    })

    const handleChange = (e) => {
 
        setState(old =>({...old,[e.target.name]: e.target.value}))
     
    }

    useEffect(()=>{
        
        props.func2({data:state, id:props.id});
        // props.func2({[]:state});


    },[state])

    console.log('Props', props)
    return(
        <div className="row">
            <div className="col-md-6">
                <div className="row">
                    <div className="col-md-4 mb-4">
                        <></>
                        
                    </div>
                    <div className="col-md-4 mb-4">
                    <label><b >{props.value.product} ({ props.value.base_price?props.value.base_price : ''}) </b></label>
                    </div>
                    <div className="col-md-4 mb-4">
                    <label ><b >{props.value.hsn_code}</b></label>
                        <input type="hidden" 
                        value={props.value.id} 
                        name={"product_id"}  
                    />
                    <input type="hidden" 
                        value={props.value.hsn_code}
                        name={"hsn_code"}  
                    />
                    </div>
                </div>
            </div>
            <div className="col-md-6">
                <div className="row">
                
                    <div className="col-md-3 mb-4">
                        <MaterialTextField fullWidth
                            label="Part Amount"
                            //  name="part-amount"
                            onChange={handleChange}
                            value={
                                state.unit_price?state.unit_price: ''
                            }
                            name={"unit_price"}    
                            id={"unitprice_"+(props.id)} 
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField fullWidth 
                        label="Qty"
                        onChange={handleChange} 
                        value={state.qty?state.qty: '' }

                        name={"qty"}    
                        id={"qty_"+(props.id)} 
                        />
                    </div>
                    <div className="col-md-3 mb-4">
                    <MaterialTextField fullWidth 
                        label="GST %" 
                        onChange={handleChange}
                        value={props.value.gst?props.value.gst: 
                            (state.gst?state.gst: '')
                        }
            
                        name={"gst"}    
                        id={"gst_"+(props.id)}  />
                    </div>
                    <div className="col-md-3 mb-4">
                        <MaterialTextField 
                        fullWidth 
                        onChange={handleChange}
                        label="Estimated Amount"
                
                        value={state.amount_after_tax?state.amount_after_tax: ''}
                        name={"amount_after_tax"}    
                        id={"estimateAmount_"+(props.id)}  />
                    </div>
                    
                </div>
            </div>
        
        </div>
    )
}


export function DealersEstimationMetal(props) {


    return (
      <>
          <div className="row mb-4">
              <div className="col-md-12">
              <CommonDealersEstimationType {...props} />
                  
              </div>
          </div>
      </>
    )
  }
  
  
  export function DealersEstimationPlastic(props) {
  
  
    return (
      <>
          <div className="row mb-4">
              <div className="col-md-12">
              <CommonDealersEstimationType {...props} />
                  
              </div>
          </div>
      </>
    )
  }
  
  export function DealersEstimationPlasticRubber(props) {
      
      
  
  
    return (
      <>
         <div className="row mb-4">
              <div className="col-md-12">
              <CommonDealersEstimationType {...props} />
                  
              </div>
          </div>
      </>
    )
  }
  