import React from 'react'
import Box  from '@mui/material/Box';



import DatePicker from '../../../../Tags/DatePicker'
import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../Tags/MaterialButton'
import MaterialTimePicker from '../../../../Tags/MaterialTimePicker'
import MaterialTextArea from '../../../../Tags/MaterialTextArea'
export default function DealersEstimationMetal(props) {
    
    
    const subCategory = ['Bonet', 'Roof', 'Door'];
    const remark = ['Repairable', 'Un-Repairable', 'Replace'];

  return (
    <>
        <div className="row mb-4">
            <div className="col-md-12">
                <Box sx={{ borderBottom: 1, borderColor: 'divider'}} key={props.key}>
                        <div className="row">
                            <div className="col-md-2 mb-4">
                                <MaterialSelect data={subCategory}  id="sub-category" labelId="sub-category-label" name="sub-category"  label="Select Sub Category" fullWidth/>
                            </div>
                            <div className="col-md-2 mb-4">
                            <label><b style={{color:"black"}}>HSN Code: </b></label>
                            </div>
                            <div className="col-md-2 mb-4">
                                <MaterialSelect data={remark}  id="reamrk-out" labelId="reamrk-out-label" name="reamrk-out"  label="--Select Remark--" fullWidth/>
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Part Amount" name="part-amount" id="part-amount" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="GST %" name="gst" id="gst" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Estimated Amount" name="estimated-amount" id="estimated-amount" />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-2 mb-4">
                            <label><b style={{color:"black"}}>Remove Refit: </b></label>
                            </div>
                            <div className="col-md-2 mb-4">
                                <MaterialSelect data={remark}  id="select-category" labelId="select-category-label" name="select-category"  label="Select Category" fullWidth/>
                            </div>
                            <div className="col-md-2 mb-4">
                                <MaterialSelect data={subCategory}  id="sub-category" labelId="sub-category-label" name="sub-category"  label="Select Sub Category" fullWidth/>
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Part Amount" name="part-amount" id="part-amount" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="GST %" name="gst" id="gst" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Estimated Amount" name="estimated-amount" id="estimated-amount" />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6 mb-4">
                            <label><b style={{color:"black"}}>Paint: </b></label>
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Part Amount" name="part-amount" id="part-amount" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="GST %" name="gst" id="gst" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Estimated Amount" name="estimated-amount" id="estimated-amount" />
                            </div>
                        </div>
                </Box>
                
            </div>
        </div>
    </>
  )
}
