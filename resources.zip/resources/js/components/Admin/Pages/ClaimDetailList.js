import React, { Component } from 'react'

import Box  from '@mui/material/Box';
import MetaAndTitle from '../../../MetaAndTitle'
import ReactDatatable from '../ReactDatatable/ReactDatatable'

import BreadCrumb from '../BreadCrumb/BreadCrumb'

// const response = {
//   firstName:'ajay',
//   lastName:'kewat',
//   age:21,
//   visits:2,
//   progress:10,
//   statusbar:"completed"
// };

 class ClaimDetailList extends Component {
  render() {

    return (
      <div>
        
    <MetaAndTitle/>
        <BreadCrumb breadcrumb="Dealer Bucket" breadcrumbItem1='Claim Details' />
        <Box sx={{ width: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px" }}>
          {/* <h1>hello</h1> */}
        <ReactDatatable />
        </Box>
      </div>
    )
  }
}

export default ClaimDetailList;