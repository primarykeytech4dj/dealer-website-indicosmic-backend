import React from 'react'

import Box  from '@mui/material/Box';

import TabContext from '@mui/lab/TabContext';
import { Tabs, Tab } from "@mui/material";
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

import  makeStyles  from "@mui/styles/makeStyles";

import BreadCrumb from '../../BreadCrumb/BreadCrumb'

import MetaAndTitle from '../../../../MetaAndTitle'

import ClaimIntimation from '../ClaimAssesment/ClaimIntimation/ClaimIntimation'
import VehicleInspection from '../ClaimAssesment/VehicleInspection/VehicleInspection'
import Assesment from '../ClaimAssesment/Assesment/Assesment'
import AddPolicy from '../ClaimAssesment/AddPolicy/AddPolicy';
import ClaimFormUpdate from '../ClaimAssesment/ClaimFormUpdate/ClaimFormUpdate';
import ReviewImages from '../ReviewImages/ReviewImages';
import DealerStatus from '../ClaimAssesment/DealerStatus/DealerStatus'


import Images from '../ClaimAssesment/VehicleInspection/InspectionData.json'


const useTabStyles = makeStyles({
    root: {
      justifyContent: "center"
    },
    scroller: {
      flexGrow: "0"
    }
  });

export default function CompanyClaim() {
    const [value, setValue] = React.useState('1');
    
  const handleChange = (event, value) => {
    setValue(value);
  };
  const classes = useTabStyles();
  return (
    <>
        <MetaAndTitle/>
        <BreadCrumb breadcrumb="Company" breadcrumbItem1='Claim Management' />
        <Box sx={{ width: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px" }}>

      
                
        <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={value} onChange={handleChange} aria-label="Company Claim"  variant={"scrollable"}
          scrollButtons={"auto"}>
            <Tab value="1"  label={<b>Claim Intimation</b>} />
            <Tab value="2" label={<b>Add Policy</b>}/>
            <Tab value="3" label={<b>Claim Form Update</b>}/>
            <Tab value="4" label={<b>Assessment</b>}/>
            <Tab value="5" label={<b>Accident Image</b>}/>
            <Tab value="6" label={<b>Vehicle Inspection</b>}/>

        </Tabs>
        </Box>
        <TabPanel value="1"><ClaimIntimation title="Claim Intimation"/></TabPanel> 
        <TabPanel value="2" ><AddPolicy title="Add Policy" /></TabPanel> 
        <TabPanel value="3" ><ClaimFormUpdate title="Update Claim Form"/></TabPanel> 
        <TabPanel value="4" ><Assesment title="Assessment" name="assessment" data={Images} /></TabPanel> 
        <TabPanel value="5" ><ReviewImages data={Images} title="Accident Images"/></TabPanel> 
        <TabPanel value="6" ><VehicleInspection title="Vehicle Inspection"/></TabPanel> 
   
      </TabContext>
               
               
           
       
         
        </Box>
    </>
  )
  
}
