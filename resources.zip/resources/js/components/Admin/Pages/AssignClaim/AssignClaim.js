import React from "react";
import MaterialSelect from '../../../../Tags/MaterialSelect';
import Button  from '@mui/material/Button';

import { Box, Divider } from '@mui/material';
import BreadCrumb from '../../BreadCrumb/BreadCrumb';
import Api from "../../../../api";
import { data } from "jquery";
import { useParams } from 'react-router-dom';
import Swal from "sweetalert2";


export default class AssignClaim extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            // user_id:"",
            // role_id,
          users:[],
          userData:[],
          data:[],
          agent:[],
          workshop:[],
          assign:'',
            
        }
        this.apiCtrl = new Api;
        
      }
    
     componentDidMount(){
       
        //   res.data.agent.map((value,index)=>{
        //         //const{role_id,} =value
        //    //const agentname=value
           
        //     const name= value.role_name
        //     this.setState(old => ({...old, user:{ ...old.user, [value.id]:value.name}}))
        //  //   console.log(this.state.agent)
        //     });

          //   res.data.workshop.map((value,index)=>{
          //       this.setState(old => ({...old, workshop:{ ...old.workshop, [value.id]:value.name}}))
          //  //   console.log(this.state.workshop)
              
          //   })
          
              
           
       
     }

    render(){
        
      const handleClick = async (e)=> {
        var data = {role:this.props.userType, claim_code:this.props.claim_code}
        this.apiCtrl.callAxios('users/agent-workshop-list', data).then(response => {

          if (response.success == true) {
            this.setState(old => ({...old,userData:{...response.data}}));
            response.data.map((value,index)=>{
              //const{role_id,} =value
              //const agentname=value
          
            
              this.setState(old => ({...old, users:{ ...old.users, [value.id]:value.name}}))
              //console.log(this.state.agent)
            });
  
          } else {

          }
        })
      }
      const handleSubmit=async (e)=>{
        e.preventDefault();
         Object.entries(this.state.userData).map(([index, value])=>{

            if(value.id === this.state.assign){
              var data = {claim_code:this.props.claim_code, assessment_id: this.props.assessment_id, user_id: value.id, role_id: value.role_id }
              this.apiCtrl.callAxios('users/assign-claim', data).then(response => {

                if (response.success == true) {
                  Swal.fire({
                    title: this.props.userType.toUpperCase()+" Assign",
                    text: "Assigned!",
                    icon: "success",
                    showConfirmButton: false,
                });
        
                $('.close').trigger('click')
                } else {
                  Swal.fire({
                    title: this.props.userType.toUpperCase()+" Assign",
                    text: response.message,
                    icon: "success",
                    showConfirmButton: false,
                });
                }
                setTimeout(()=>{ Swal.close()},2000)
              })
            }

          })

          // const val={
          //     agent:this.state.agent,
          //     workshop:this.state.workshop
          // }
        }
      //  this.setState(param => ({...param , params:{...param.params, policy_details : { ...param.params.policy_details,[e.target.name]: e.target.value } }}))

        // const selecteduser=(e)=>{
        //    // this.setState()
        //     this.setState(old => ({...old, data:{...old.data,[e.target.name]:e.target.value }}))
        // }
        
        const handleChange=(e)=>{
        // this.setState()
          this.setState(old => ({...old, assign: e.target.value}))
        }
        
        // console.log("selectuser",this.state.data)
        // console.log('USER ROLE', this.props)
        
        // console.log("workshopuser",this.state.data)
        let user =  this.props.userType.replace(/-/g, " ");

        var userType = user
        .toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
      return(
        <>



        <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>

          <div className="row ml-1">
            <label><b>Assign To {userType}</b></label>
          </div>


          {/* <form id="assessment_submit" onSubmit={(e) => handleSubmit(e)}> */}
            <div className="row  mt-4 mb-4">

            {/* <div className='col-md-4'>

<MaterialSelect value={this.state.data.user_id?this.state.data.user_id:''} onChange={selecteduser}    data={this.state.agent} id="product_category_id" labelId="product-category-id" name="user_id"  label="Agent " fullWidth/>
</div> */}

              <div className='col-md-8'>

              <MaterialSelect onMouseEnter={handleClick} required={true} value={this.state.assign?this.state.assign:''} onChange={handleChange}   data={this.state.users} id="product_category_id" labelId="product-category-id" name="role_id"  label={"Select "+userType} fullWidth/>
              </div>
              <div className="col-md-4 mt-2">
              <Button style={{ backgroundColor: '#183883', color:'white' }}  onClick={(e) => handleSubmit(e)}>Assign</Button>
              </div>

            </div>
          <Divider />





          {/* </form> */}
        </Box>

        </>
        )
    }

}

