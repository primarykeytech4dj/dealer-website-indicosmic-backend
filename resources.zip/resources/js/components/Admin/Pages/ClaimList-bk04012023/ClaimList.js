import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { useState } from 'react';
import { useEffect } from 'react';
import { Box } from '@mui/material';
import {TextField} from '@mui/material';
import BreadCrumb from '../../BreadCrumb/BreadCrumb';
import { Button } from 'react-bootstrap';
import Api from '../../../../api';

import {Link, useNavigate} from 'react-router-dom';
import { filter } from 'lodash';

import  swal from 'sweetalert'

import Swal from 'sweetalert2'

export default class ClaimList extends React.Component {
    constructor(props){
        super(props);
        
        this.apiCtrl = new Api;
        this.state = {
            data : [],
            isLoading: false,
            page: 0,
            pageSize: 10,
            filter : null,

        }
        // this.getClaimList();
    }

    componentWillMount = () => {
        this.getClaimList();
      }

 
    getClaimList = () => {
       
   
        this.setState(old => ({...old, isLoading:true}))
        var data = {length:this.state.pageSize, start:this.state.page*this.state.pageSize};

        if(this.state.filter !== null){
          data = {...data, filter: this.state.filter};
        }
        this.apiCtrl.callAxios('claim_list', data).then(response => {
            console.log(response);
            
            if(response.success == true){
                this.setState(old => ({...old, data:response.data.aaData, total:response.data.iTotalRecords}))
       
    
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Something went wrong!',
               
              })
            }
            this.setState(old => ({...old, isLoading:false}))
            // sessionStorage.setItem('_token', response.data.)
            
        }).catch(function (error) {
            this.setState(old => ({...old, isLoading:false}))
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something went wrong!',
             
            })
        });
    }
    componentDidUpdate(prevProps, prevState){
        // console.log('update')
        if ((prevState.page !== this.state.page) || (prevState.filter !== this.state.filter)) {
            this.getClaimList();
        } 
      }



    render(){

      
        const columns = [
            { field: 'sr_no', headerName: 'ID', width: 100},
            { field: 'claim_code', headerName: 'Claim Code',  width: 120},
            { field: 'policy_id', headerName: 'Policy ID',  width: 120},
            { field: 'insurance_company', headerName: 'Insurance Company',  width: 190},
            { field: 'insured_name', headerName: 'Insured Name',  width: 100},
            { field: 'policy_start_date', headerName: 'Policy Start Date',  width: 190},
            { field: 'policy_end_date', headerName: 'Policy End Date',  width: 190},
            { field: 'action', headerName: 'Action',  width: 100,  renderCell: (params) => <Action param={params.row} />, },
          ];
    

  return (
    <>
    <BreadCrumb breadcrumb="Claim" breadcrumbItem1='Claim List' />

    <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>

<div className="row mb-4">
  <div className='col-md-6'></div>
  <div className='col-md-6' style={{display:'flex', justifyContent:"flex-end"}}>
    <span style={{marginTop: '5px'}}>Search:   </span>&nbsp;&nbsp;&nbsp;
  <TextField size="small" name='search' InputProps={{ style: {height:"37px", width:"130px"}}} onChange={(e)=>this.setState(old => ({...old, filter: e.target.value}))}/>
  </div>
</div>
    <div style={{ height: 650, width: '100%' }}>
   
      <DataGrid
        sx={{width:"100%", overflowX:"auto"}}
        rows={this.state.data}
        rowCount={this.state.total}
        page={this.state.page}
        
        loading={this.state.isLoading}
        columns={columns}
        pagination
        paginationMode='server'

        pageSize={this.state.pageSize}
        rowsPerPageOptions={[10, 30, 50, 70, 100]}
        // checkboxSelection

        onPageChange={(newPage) => this.setState(old=>({...old, page: newPage}))}
        onPageSizeChange={(newPageSize) => this.setState(old=>({...old, pageSize: newPageSize}))}
        />
        {/* {rows.map((item) => {
            return <Action id={item.id} item={item.action} />
            // return <Button name='Edit'>Edit</Button>
          })} */}
    </div>
    </Box>
    </>
  );
    }
}
// function
function Action(props) {

  return(
   <Link to='/assessor/claim-assessment' state={{claim_code : props.param.claim_code}}><Button claim_code={props.param.claim_code} >Edit</Button></Link>

  )
}
