import React, { useEffect, useState } from "react"
import Box  from '@mui/material/Box';
import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialSelect from '../../../../Tags/MaterialSelect'
import MaterialButton from '../../../../Tags/MaterialButton'
import { DataGrid } from '@mui/x-data-grid';

import Button  from '@mui/material/Button';

import Api from '../../../../api';


export default function Vehicle(Props)  {
    const [inputrow,setInputrow] = useState([<Inputrow key={0} />]);
    const [state,setState]= useState({
        data : [],
        isLoading: false,
        page: 0,
        pageSize: 10,  
        paramsdata:[],
    }
    )

  const  apiCtrl = new Api;

    let handleAddPerson = (e) => {
        e.preventDefault()
        setInputrow([...inputrow,<Inputrow key={inputrow.length} />]);
    }

       var product={
        1:"string",
        2:"string"
       }
       useEffect(() => {
        //getUserList()
       })
    


       
 const  getUserList = () =>{



    //  console.log("urldata===>",data)

    setState(old => ({...old, isLoading:true}))
    apiCtrl.callAxios('users/list',{role_name:"agent",length:state.pageSize, start:state.page*state.pageSize}).then(response => {
        console.log("res===",response);
        
        if(response.success == true){
            setState(old => ({...old, data:response.data.aaData, total:response.data.iTotalRecords}))

        } else {
        alert("No Data Available")
        }
        setState(old => ({...old, isLoading:false}))
        // sessionStorage.setItem('_token', response.data.)
        
    }).catch(function (error) {
        setState(old => ({...old, isLoading:false}))
        console.log(error);
    });
    
      }


       const columns = [
        { field: 'sr_no', headerName: 'ID', width: 100 },
        { field: 'name', headerName: 'Name', width: 190 },
        { field: 'email', headerName: 'Email', width: 300 },
        { field: 'mobile', headerName: 'Mobile', width: 190 },
        { field: 'action', headerName: 'Action',  width: 190,   },
      ];



        return(
            <>
           <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>
                <div className="row">
                    <div className="col-md-12">
                        <div className="row">
                            <div className="col-md-10 mb-4">
                                <MaterialSelect id="sub-category" labelId="sub-category-label" data={product} name="manufactuarer_make"  label="Manufactuarer (Make)" fullWidth/>
                            </div>
                            
                            <div className="col-md-2 mb-4">
                   
                            <Button type="submit" style={{ backgroundColor: '#183883',width:"96px",color:"#fff", height: "50px",marginTop:"4px"}} data-bs-toggle="modal" size='small' href="#exampleModalToggle">Make</Button>
                            </div>
                        </div>
                    </div>
                    
                    <div className="col-md-6">
                        <div className="row">
                            <div className="col-md-12 mb-4">      
                            <div className="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabIndex="-1">
                                <div className="modal-dialog modal-dialog-centered">
                                <div className="modal-content">
                                <div className="modal-header">
                                    {/* <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5> */}
                                    <div className="row ml-1" style={{ paddingTop: '2%'}}>
                                        <label><b>Manufactuarer Make</b></label>
                                    </div>
                                    <button type="button"   data-bs-dismiss="modal" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>                              
                                <div className="modal-body m-body">                               
                                <div className="row">
                                    <div className="col-md-12 mb-4">
                                    <MaterialTextField fullWidth label="Manufactuarer Make" name="manufactuarer_make" id="estimated-amount" />
                                    </div>
                                </div>
                                <div className="modal-footer">
                                        

                                        <Button data-bs-dismiss="modal" style={{ backgroundColor: 'rgb(108 110 116)',color:"#fff"}}>Close</Button>&nbsp;&nbsp;
                                        
                                
                                        <Button data-bs-dismiss="modal" style={{ backgroundColor: '#183883',color:"#fff"}} >Submit</Button>
                                        
                                 </div>
                                </div>         
                                </div>
                            </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>

                {inputrow}   <div className="col-md-12 mb-4 d-flex" style={{justifyContent:"right",marginTop:"-4rem",marginBottom:"auto"}}>
                             <Button type="submit" onClick={handleAddPerson}style={{ backgroundColor: '#183883',width:"96px",color:"#fff", marginTop: "-11px", height: "48px"}}   size='medium'>Add More</Button>
                            </div>

                            

                            <Button type="submit" onClick={getUserList}style={{ backgroundColor: '#183883',width:"96px",color:"#fff", marginTop: "-11px", height: "48px"}}   size='medium'>Add More</Button>

                <div className="mt-4"style={{ height: 400, width: '100%' }}>
                 <DataGrid
                    autoHeight
                    rows={state.data}
                    rowCount={state.total}
                    page={state.page}
                    
                    loading={state.isLoading}
                    columns={columns}
                    pagination
                    paginationMode='server'

                    pageSize={state.pageSize}
                    rowsPerPageOptions={[10, 30, 50, 70, 100]}
                    checkboxSelection

                    onPageChange={(newPage) => setState(old=>({...old, page: newPage}))}
                    onPageSizeChange={(newPageSize) => setState(old=>({...old, pageSize: newPageSize}))}
                 />

                </div>           
            </Box>       

     




            </>
        )
    
}


 function Inputrow(props){
    


    var product={
        1:"string",
        2:"string"
       }

    return(
        <>
               <div className="row">
                    <div className="col-md-12">
                        <div className="row">
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Model Code" name="model_code" id="estimated-amount" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Name" name="name" id="estimated-amount" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Oem" name="oem" id="estimated-amount" />
                            </div>
                            <div className="col-md-2 mb-4">
                            <MaterialTextField fullWidth label="Oem Subtype" name="oem_subtype" id="estimated-amount" />
                            </div>
                            <div className="col-md-2 mb-4">
                                <MaterialSelect id="sub-category" labelId="Model Make" data={product} name="model_make"  label="Model Make" fullWidth/>
                            </div>
                           
                            


                            
                            
                           
                        </div>
                    </div>
                    
                </div>
        </>
    )
 }