import React, {useState, useEffect} from 'react'

import Container  from '@mui/material/Container';
import TextField  from '@mui/material/TextField';
import Button  from '@mui/material/Button';
import MaterialTextField from '../../../../Tags/MaterialTextField'
import Swal from 'sweetalert2'
// import MaterialButton from '../../../../Tags/MaterialButton';
import { useForm } from 'react-hook-form';
import Api from '../../../../api';
 class AddPolicy extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      btnVariant : "contained",
      policy_id : '',
      errors : '',
  
      
    }
    this.apiCtrl = new Api;
  }

  componentWillMount = () => {
    var errors = {
      policy_id: '',
    }

    this.setState({errors: errors})
  }


  
  formValidation =()=>{
    const {policy_id}=this.state;
    let isValid =true;
    const errors={};
    if(policy_id.trim().length< 1){
        errors.policy_id ="Please Enter Your Policy Number"
        isValid= false;
    }else if(!policy_id.match(/^[0-9a-z]+$/)){
        errors.policy_id ="Policy must have a b,a,c"
        isValid= false;
    } 

  

    
   // this.setState({errors:errors});
    return  errors;
}
  
  render(){
    // const [btnVariant, setBtnVariant] = useState('contained')
    
    // const [policyNo, setPolicyNo] = useState('');
    // const { register, handleSubmit } = this.props;

    console.log("URL : "+process.env.MIX_API_URL);
  
    

    
    // alert(process.env.MIX_API_URL);
   
    const handleSubmit = (e) => {
      e.preventDefault();
      
      const isValid =this.formValidation()
      console.log("isvalid",isValid)
      var msg = Object.entries(isValid);
      console.log("message=",msg);
      var str = '';
      msg.map((msg, key)=>{
        console.log("api controller ".msg);
        str+=msg[1]+"<br>";
      })

      console.log("str--",str)

      

      if(typeof this.state.policy_id === 'undefined' || this.state.policy_id === '' ||isValid.policy_id){
        Swal.fire({
          title: "Add Policy",
         // text:"Please Enter Your Policy Number",
         html:` ${str}`,
          icon: "error",
          showConfirmButton: false,
      })
        
        //return false;
      }else{
        this.apiCtrl.callAxios('claim', {policy_id: this.state.policy_id}).then(response => {
  
          console.log(response);
          if(response.success){

    
            this.props.func({policyNo: this.state.policy_id ,claimCode: response.data.claimCode, details:response.data.data});
          } else {
            

          
            Swal.fire({
              title: "Add Policy",
              text: response.message,
              icon: "error",
              showConfirmButton: false,
          })
          }
          // sessionStorage.setItem('_token', response.data.)
          
          this.setState({errors: ''})
          return  true;
        }).catch(function (error) {
          console.log(error);
        });
      }
      
      
      //if(typeof this.state.policy_id  !== 'undefined' || this.state.policy_id !== ''){
          
            
      //  /////////////////////////


        // } else {
        //   this.setState({errors: 'TextField Required'})
        // }
   
      // axios(config).then(function (response) {
      //   console.log(JSON.stringify(response.data));
      //   var result = response.data;
      //   if(result.status === "success") {

        
      //     sessionStorage.setItem("policy_no", this.state.policyNo);

      //       console.log(success);
      //   } else {
      //     console.log(error);
      //   }
      // })
      // .catch(function (error) {
      //   console.log(error);
      // });

    } 

    // $(document).on('submit', '#policy_id', function(e){
  
    //   var formdata = new FormData($("#policy_id")[0]);
    //   console.log( formdata, e);
    //   console.log(e);
    // })
    const handleChange = (e) => {

      console.log(e.target.value)
      this.setState({policy_id : e.target.value})
      
      this.setState({errors: ''})
    }
    return (
      <>

      <form onSubmit={handleSubmit}>


          <div className="row mt-4 ">

              <div className="col-md-4 mb-2">
                  <MaterialTextField 
                  label="Policy No" 
                  onChange={(e)=>handleChange(e)} 
                  size="small" 
                  autoComplete="policy_id"
                  fullWidth 
                  id="policy_id"
                  autoFocus
                
                  value={this.state.policy_id !== '' ? this.state.policy_id:''}
                  // required
                  helperText={this.state.errors.policy_id !== '' ? this.state.errors.policy_id : ''}
                  // {...register('policy_id')}
                  error={this.state.errors.policy_id && this.state.errors.policy_id.length ? true : false}
                  />
              </div>
              <div className="col-md-3">

                  <Button variant={this.state.btnVariant} type="submit" style={{ backgroundColor: '#183883'}}  onMouseLeave={()=>this.setState({btnVariant :'contained'})}  onMouseEnter={()=>this.setState({btnVariant : 'outlined'})} >Next</Button>
              </div>
          </div>
        </form>
    

      </>
    )
  }
} 


export default(props) => {
  const form = useForm();
  return <AddPolicy {...props} {...form} />
}