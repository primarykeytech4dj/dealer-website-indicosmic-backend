import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { useState } from 'react';
import { useEffect } from 'react';
import { Box } from '@mui/material';
import {TextField} from '@mui/material';
import BreadCrumb from '../../BreadCrumb/BreadCrumb';
import { Button } from 'react-bootstrap';
import Api from '../../../../api';
import MaterialButton from "../../../../Tags/MaterialButton";
import {Link, useNavigate} from 'react-router-dom';
import { filter } from 'lodash';

import  swal from 'sweetalert'

import Swal from 'sweetalert2'

import AssignClaim from '../AssignClaim/AssignClaim';

export default class ClaimList extends React.Component {
    constructor(props){
        super(props);
        
        this.apiCtrl = new Api;
        this.state = {
            data : [],
            isLoading: false,
            page: 0,
            pageSize: 10,
            filter : null,
            claimData : null,

        }
        // this.getClaimList();
    }

    componentWillMount = () => {
        this.getClaimList();
      }

 
    getClaimList = () => {
       
   
        this.setState(old => ({...old, isLoading:true}))
        var data = {length:this.state.pageSize, start:this.state.page*this.state.pageSize};

        if(this.state.filter !== null){
          data = {...data, filter: this.state.filter};
        }
        this.apiCtrl.callAxios('claim_list', data).then(response => {
            console.log(response);
            
            if(response.success == true){
                this.setState(old => ({...old, data:response.data.aaData, total:response.data.iTotalRecords}))
       
    
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Something went wrong!',
               
              })
            }
            this.setState(old => ({...old, isLoading:false}))
            // sessionStorage.setItem('_token', response.data.)
            
        }).catch(function (error) {
            this.setState(old => ({...old, isLoading:false}))
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something went wrong!',
             
            })
        });
    }
    componentDidUpdate(prevProps, prevState){
        // console.log('update')
        if ((prevState.page !== this.state.page) || (prevState.filter !== this.state.filter)) {
            this.getClaimList();
        } 
      }



    render(){

      
      const handleModel = (data) => {
        this.setState({claimData:data})
      }
        const columns = [
            // { field: 'sr_no', headerName: 'ID', width: 100},
            { field: 'claim_code', headerName: 'Claim Code',  width: 120},
            { field: 'policy_id', headerName: 'Policy ID',  width: 120},
            { field: 'insurance_company', headerName: 'Insurance Company',  width: 190},
            { field: 'insured_name', headerName: 'Insured Name',  width: 100},
            { field: 'policy_start_date', headerName: 'Policy Start Date',  width: 190},
            { field: 'policy_end_date', headerName: 'Policy End Date',  width: 190},
            { field: 'action', headerName: 'Action',  width: 210,  renderCell: (params) => <Action key={params.row.id} func={handleModel} param={params.row} />, },
          ];
    

  return (
    <>
    <BreadCrumb breadcrumb="Claim" breadcrumbItem1='Claim List' />

    <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>

<div className="row mb-4">
  <div className='col-md-6'></div>
  <div className='col-md-6' style={{display:'flex', justifyContent:"flex-end"}}>
    <span style={{marginTop: '5px'}}>Search:   </span>&nbsp;&nbsp;&nbsp;
  <TextField size="small" name='search' InputProps={{ style: {height:"37px", width:"130px"}}} onChange={(e)=>this.setState(old => ({...old, filter: e.target.value}))}/>
  </div>
</div>
    <div style={{ height: 650, width: '100%' }}>
   
      <DataGrid
        sx={{width:"100%", overflowX:"auto"}}
        autoHeight
        rows={this.state.data}
        rowCount={this.state.total}
        page={this.state.page}
        
        loading={this.state.isLoading}
        columns={columns}
        pagination
        // paginationMode='server'

        pageSize={this.state.pageSize}
        rowsPerPageOptions={[10, 30, 50, 70, 100]}
        // checkboxSelection

        onPageChange={(newPage) => this.setState(old=>({...old, page: newPage}))}
        onPageSizeChange={(newPageSize) => this.setState(old=>({...old, pageSize: newPageSize}))}
        />

        <Model {...this.state.claimData} />
        {/* {rows.map((item) => {
            return <Action id={item.id} item={item.action} />
            // return <Button name='Edit'>Edit</Button>
          })} */}
    </div>
    </Box>
    </>
  );
    }
}
// function
function Action(props) {

  const step=props.param.form_step
  let value= step.slice(5)


  var roles = JSON.parse(localStorage.getItem('user_roles'))
  if( roles[0].role_code === "SA" || roles[0].role_code === "AD" || roles[0].role_code === "AS"  ){


    const handleClick = (e) => {
      props.func(props.param)
    }
    return(
      <>
      <Link to='/assessor/claim-assessment' state={{claim_code : props.param.claim_code, assessment_id : props.param.assessment_id}}><Button claim_code={props.param.claim_code} >Verify Inspection</Button></Link>  
      {(props.param.agent_name === 'Not Assigned') && (value === '5' )?
    <>
  
    &nbsp;&nbsp;
    &nbsp;&nbsp;
     <Button
     
     style={{ backgroundColor: "#183883" }}
     name="Assign Agent"
     className=" "
     // type="submit"
     data-bs-toggle="modal" 
      
     href="#exampleModalToggle1" 
     text="Assign Agent"
     onClick={handleClick}
     >
      Assign Agent
      </Button>
   
 
      </>
      :<></>}
      </>
    )
  } else if( roles[0].role_code === "CC" ){


    const handleClick = (e) => {
      props.func(props.param)
    }
    return(
      <>
      <Link to='/add-claim' state={{value : value, details : props.param}}><Button claim_code={props.param.claim_code} >Edit</Button></Link>  
      {(props.param.agent_name === 'Not Assigned') && (value === '5' )?
    <>
  
    &nbsp;&nbsp;
    &nbsp;&nbsp;
     <Button
     
     style={{ backgroundColor: "#183883" }}
     name="Assign Agent"
     className=" "
     // type="submit"
     data-bs-toggle="modal" 
      
     href="#exampleModalToggle1" 
     text="Assign Agent"
     onClick={handleClick}
     >
      Assign Agent
      </Button>
   
 
      </>
      :<></>}
      </>
    )
  } else if( roles[0].role_code === "WO"){
    return   <Link to='/assessor/claim-assessment' state={{claim_code : props.param.claim_code, assessment_id : props.param.assessment_id}}><Button claim_code={props.param.claim_code} >View</Button></Link>  
  } else {
   
    return(
      <Link to='/add-claim' state={{value : value, details : props.param}}><Button claim_code={props.param.claim_code} >Edit</Button></Link>  
     )
  }
}

function Model(props){
  // var id=props.userid.id
  console.log("id=====>",props.claim_code)

 //console.log(props.eventid)
  return(
    <>
   
      <div  key={(props.key+1)} className="modal fade" id="exampleModalToggle1" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabIndex="-1">
        <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
        <div className="modal-header">
            {/* <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5> */}
            <div className="row ml-1" style={{ paddingTop: '2%'}}>
                {/* <label><b>{props.params.any} Details</b></label> */}
            </div>
            <button type="button"   data-bs-dismiss="modal" className="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          
          <div className="modal-body m-body">
            
          <div className="row">
            {/* <AddUsers  params={this.props.params}  /> */}
            <AssignClaim  claim_code={props.claim_code? props.claim_code : ''} assessment_id={props.assessment_id? props.assessment_id : ''} userType={'agent'}/>

          </div>
            
         
          </div>  

          
        </div>
      </div>
    </div>
  </>
  )
}