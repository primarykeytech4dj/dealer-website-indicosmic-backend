import React, { useEffect } from 'react';

import { BrowserRouter as Router , Routes, Route} from 'react-router-dom';

import Dashboard from '../Dashboard/Dashboard';
import NavBar from '../NavBar/NavBar';

import UpdateClaimForm from '../Pages/UpdateClaimForm';
import ClaimAssesment from '../Pages/ClaimAssesment/ClaimAssesment';
import ClaimDetailList from '../Pages/ClaimDetailList';
import CompanyClaim from '../Pages/CompanyClaim/CompanyClaim';
import  Login  from '../Pages/Login/Login';
import { ForgotPassword } from '../Pages/Login/ForgotPassword';
import UserList from '../Pages/Users/UserList'; 
import AddUsers from '../Pages/Users/AddUsers';
import ClaimList from '../Pages/ClaimList/ClaimList';
import AddRoles from '../Pages/Roles/AddRoles'
import RolesList from '../Pages/Roles/RolesList';
import AddClaim from '../Pages/AddClaim';

import Product from '../Pages/Product/Product';
import ProductList from '../Pages/Product/ProductList';
import Setup from '../Pages/setup/Setup';
import ProductCategory from '../Pages/ProductCategory/ProductCategory';
import AssignClaim from '../Pages/AssignClaim/AssignClaim';
import EditDealerEstimation from '../Pages/DealersEstimation/EditDealerEstimation'

export default function Layout() {

  var roles = JSON.parse(localStorage.getItem('user_roles'))
     

  return (
    <Router>
      <div  className=" body fixed-nav sticky-footer" id="page-top">

        <NavBar />
        <div className="content-wrapper" style={{backgroundColor: "#EEF5FF"}}>
          <div className="container-fluid" style={{backgroundColor: "#EEF5FF"}}>
            
          { roles === "" ? 
             <Routes>
              <Route path='/login' element={<Login />} />
              <Route exact path="/" element={<Dashboard />} />
              <Route path='/forgotpassword' element={<ForgotPassword/>}/>
              </Routes> 
              :''}
              
          { roles[0].role_code === "WO" || roles[0].role_code === "IN" || roles[0].role_code === "DA" || roles[0].role_code === "AG" ? 
              <Routes>
                 <Route exact path="/" element={<Dashboard />} />
                <Route path="/claim-list" element={<ClaimList />} /> 
                <Route path="/assessor/claim-assessment" element={<ClaimAssesment />} />
              </Routes> 
              :''}


              { roles[0].role_code === "SA" || roles[0].role_code === "AD" || roles[0].role_code === "AS"  || roles[0].role_code === "CC" ?  
              <Routes>
              <Route exact path="/" element={<Dashboard />} />

              <Route path="/add-claim" element={<AddClaim />} />
              <Route path="/update-claim-form" element={<UpdateClaimForm />} />
              
              <Route path="/assessor/claim-assessment" element={<ClaimAssesment />} />
              <Route path="/company/add-claim" element={<CompanyClaim />} />  
              <Route path="/create/:any" element={<AddUsers />} />
              <Route path="/claim-list" element={<ClaimList />} /> 
              <Route path="/user-list/:any" element={<UserList />} /> 
              <Route path="/create-role" element={<AddRoles />} /> 
              <Route path="/role-list" element={<RolesList />} /> 
              <Route path="/product/add-product" element={<Product />} /> 
              <Route path="/product/product-list" element={<ProductList />} /> 
              <Route path="/product-category" element={<ProductCategory/>}/>
              <Route path="/setup" element={<Setup/>}/>
              <Route path="/assign_claim" element={<AssignClaim />}/>
              <Route path="/edit-dealer-estimation" element={<EditDealerEstimation />}/>
              </Routes>
               :""}
                
               
              
               
              
        
           

            
            
          </div>
        </div>
    
        <a className="scroll-to-top rounded" href="#page-top">
          <i className="fa fa-angle-up"></i>
        </a>
      
      </div>
    </Router>
  )
}
