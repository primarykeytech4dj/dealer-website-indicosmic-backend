import React from "react";
import Button  from '@mui/material/Button';
import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialButton from '../../../../Tags/MaterialButton';
import MaterialSelect from "../../../../Tags/MaterialSelect";
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import { Box, Divider } from '@mui/material';
import BreadCrumb from '../../BreadCrumb/BreadCrumb';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import DatePickers from '../../../../Tags/DatePicker'
import MaterialTextArea from '../../../../Tags/MaterialTextArea'
import Api from '../../../../api';
import { useParams } from 'react-router-dom';
import axios from "axios";
import Swal from "sweetalert2";
import { FileUploader } from "react-drag-drop-files";

export  class Products extends React.Component {
    constructor(props){
      super(props);
      this.state = {
        
        data: [],
        is_pack:0,
        show_on_website:0,
        is_sale:0,
        is_new:0,
        is_gift:0,
        is_featured:0,
        other_images:[]
      }
      this.apiCtrl = new Api;
      
    }
    render(){
        const type={
            "1":"Product",
            "2":"Service",
             "0":"Both"
        }
        const fileTypes = ["JPG", "PNG", "GIF", "JPEG"];

        const submitdata=(e)=>{
            e.preventDefault();
                      var data = new FormData();
                      if(Object.keys(this.state).length > 0){

                        Object.entries(this.state).map(([index, value])=>{
                            if(index !== "data"){
                                if(index === 'other_images'){

                                    value.map((val1, key1)=>{

                                        data.append(`${index}[]`, value[key1]);
                                    })
                                } else {
                                    data.append(`${index}`, value);
                                }
                            }
                        })
                    }

                    this.apiCtrl.callAxiosFile("product/create-product",data,true).then((response)=>{
        
            if(response.success === true){
                // console.log("response=>",response)
                 Swal.fire({
                  title: "Product",
                  text:"Created",
                  icon: "success",
                  showConfirmButton: false,
              })
      
              } else {
                  Swal.fire({
                                title: "Product",
                                text: "Not Created!",
                                icon: "error",
                                showConfirmButton: false,
                            })
              }
        })
       
    
      


      
          
      } 
  

        const productCategory = () => {
            this.apiCtrl.callAxios('product/get-product-category').then(res => {
              // const array={}
               this.setState({data: res.data});
              
                
                })
          }

          const handleChange = (file) => {
            console.log(file)
            Object.entries(file).map(([index, value])=>{

                this.setState(old=>({...old,other_images:[...old.other_images,value]}))
            })
             console.log("stae=>",this.state)
          };
          
        return(<>

            <BreadCrumb breadcrumb={"Products"} breadcrumbItem1='Create' />

            <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>

                <div className="row mb-3 ml-1">
                    <label><b>{"Product Basic Info"}</b></label>
                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />

                <div className="row ">

                    <div className='col-md-4'>
                
                    <MaterialSelect  
                    onMouseEnter={productCategory} 
                    value={this.state.product_category_id?this.state.product_category_id: ''} 
                    onChange={(e)=>this.setState({product_category_id : e.target.value})}   
                    data={this.state.data}  id="product_category_id" labelId="product-category-id" 
                    name="product_category_id"  label={"product Category"} fullWidth/>
                    </div>

                    <div className="col-md-4">
                    <MaterialSelect
                     name={"product_type"}
                     label={"Product Type"}                    
                     value={this.state.product_type?this.state.product_type: ''} 
                     onChange={(e)=>this.setState({product_type : e.target.value})}   
                     data={type}
                     fullWidth
                     />

                    </div>

                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Product"} placeholder="Product"  fullWidth name='product' onChange={(e)=>this.setState({product : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Tally Name"} placeholder="Tally Name"  fullWidth name='tally_name' onChange={(e)=>this.setState({tally_name : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextArea multiline label={"Description" } placeholder=" Description" fullWidth name='description' onChange={(e)=>this.setState({description : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Base Price"} type={'number'} placeholder="Base Price"  fullWidth name='base_price' onChange={(e)=>this.setState({base_price : e.target.value})}/>
                    </div>

                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Base Uom" }  placeholder="Base Uom"  fullWidth name='base_uom' onChange={(e)=>this.setState({base_uom : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Meta Keyword" }  placeholder="Meta Keyword" fullWidth name='meta_keyword' onChange={(e)=>this.setState({meta_keyword : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Meta Title" } placeholder="Meta Title"  fullWidth name='meta_title' onChange={(e)=>this.setState({meta_title : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextArea multiline label={"Meta Description" } placeholder="Meta Description" fullWidth name='meta_description' onChange={(e)=>this.setState({meta_description : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Priority" } type={"number"} placeholder="Priority" fullWidth name='priority' onChange={(e)=>this.setState({priority : e.target.value})}/>
                    </div>
                  
                   
                    
                    <div className="col-md-4 mb-4">
                            <FormControlLabel control={<Checkbox    onChange={(e)=>this.setState({is_pack:e.target.checked?1:0})}/>} label={"Is Pack"} />
                    </div>
                    <div className="col-md-4 mb-4">
                            <FormControlLabel control={<Checkbox    onChange={(e)=>this.setState({show_on_website:e.target.checked?1:0})}/>} label={"Show On Website"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox    onChange={(e)=>this.setState({is_sale:e.target.checked?1:0})}/>} label={"Is Sale"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox    onChange={(e)=>this.setState({is_new:e.target.checked?1:0})}/>} label={"Is New"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox    onChange={(e)=>this.setState({is_gift:e.target.checked?1:0})}/>} label={"Is Gift"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox    onChange={(e)=>this.setState({overall_stock_mgmt:e.target.checked?1:0})}/>} label={"Overall Stock Mgmt"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox    onChange={(e)=>this.setState({is_featured:e.target.checked?1:0})}/>} label={"Is Featured"} />
                    </div>
                   
                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />
                <div className="row mb-3 ml-1">
                    <label><b>{"Product Image"}</b></label>
                </div>

                <div className="row">
                    <div className="col-md-6">
                        <MaterialTextField type={"file"} onChange={(e)=>this.setState({banner_image:e.target.files[0]})} name="banner_image" label="Banner Image"/>

                    </div>
                    <div className="col-md-6">
                        <MaterialTextField type={"file"} onChange={(e)=>this.setState({featured_image:e.target.files[0]})} name="featured_image" label="Featured Image"/>

                    </div>

                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />
                <div className="row mt-3 ml-1">
                    <label><b>{"Other Images"}</b></label>
                </div>
                  
                <div className="row">
                <FileUploader handleChange={handleChange}  multiple={true} name="other_images[]" types={fileTypes} />
                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />
                <div className="col-md-12 mb-4 d-flex"style={{justifyContent:"right",marginBottom:"auto"}}>
                <MaterialButton style={{ backgroundColor: '#183883' , marginTop: "14px", border: '1px solid #183883',height:55}}  onClick={submitdata}name="submit" text="Submit" />
                </div>
            </Box>

            
        </>)
    }
}  


