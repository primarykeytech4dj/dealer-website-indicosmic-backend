import React from "react";
import { DataGrid } from '@mui/x-data-grid';

import { Box, Divider } from '@mui/material';
import BreadCrumb from '../../BreadCrumb/BreadCrumb';
import { Button } from 'react-bootstrap';
import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialSelect from "../../../../Tags/MaterialSelect";
import MaterialTextArea from "../../../../Tags/MaterialTextArea";
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import MaterialButton from '../../../../Tags/MaterialButton';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import Swal from 'sweetalert2';
import Api from '../../../../api';
import { Link } from "react-router-dom";
import { useState } from "react";
import { Products } from "./Products";

export default class ProductsList extends React.Component {
    constructor(props){
      super(props)
      this.apiCtrl = new Api;
  
      this.state = {
        data : [],
        isLoading: false,
        page: 0,
        pageSize: 10,
        productData:[],
        product_type:this.props.title
  
    }
  
    }
  
    componentWillMount = () => {
      this.getProductList();
    }

    

    componentDidUpdate(prevProps, prevState){
      // console.log('update')
      if (prevState.page !== this.state.page) {
          this.getProductList();
      }
    }
  
  
    getProductList = () =>{
  
      this.setState(old => ({...old, isLoading:true}))
      var data = {product_type:this.state.product_type,length:this.state.pageSize, start:this.state.page*this.state.pageSize};

      this.apiCtrl.callAxios('product/list',data).then(response => {
          console.log(response);
          
          if(response.success == true){
              this.setState(old => ({...old, data:response.data, total:response.data.iTotalRecords}))
  
          } else {
          alert("No Data Available")
          }
          this.setState(old => ({...old, isLoading:false}))
          // sessionStorage.setItem('_token', response.data.)
          
      }).catch(function (error) {
          this.setState(old => ({...old, isLoading:false}))
          console.log(error);
      });
    }
  
    
    render() {
  
  
      const  handleClick = (data) => {
        // console.log("dataproduct===",data)
         this.setState({productData: data})
       }
  
      const columns = [
        { field: 'id', headerName: 'ID', width: 100 },
        { field: 'product', headerName: 'Product', width: 190 },
        { field: 'product_code', headerName: 'Product Code', width: 190 },
        { field: 'slug', headerName: 'Slug', width: 150 },
        { field: 'base_price', headerName: 'Base Price', width: 100 },
        // { field: 'gst', headerName: 'GST', width: 150 },
        { field: 'action', headerName: 'Action',  width: 190,  renderCell: (params) => <Action key={params.row.id} fun={handleClick} param={params.row} />, },
      ];
  
  
    return (
      <>
      <BreadCrumb breadcrumb="Product List" />
      <Button  type="button" style={{ backgroundColor: '#183883',width:"139px", marginBottom: "20px", marginLeft:"47rem",color:"#fff"}} href="#exampleModalToggle1" data-bs-toggle="modal" size='large' >Add Products</Button>
      <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>
  
      <div style={{ height: '100%', width: '100%' }}>
     
      <DataGrid
          autoHeight
          rows={this.state.data}
          rowCount={this.state.total}
          page={this.state.page}
          
          loading={this.state.isLoading}
          columns={columns}
          pagination
  
          pageSize={this.state.pageSize}
          rowsPerPageOptions={[10, 30, 50, 70, 100]}
          checkboxSelection
          onPageChange={(newPage) => this.setState(old=>({...old, page: newPage}))}
          onPageSizeChange={(newPageSize) => this.setState(old=>({...old, pageSize: newPageSize}))}

  
          />
         
      </div>

      <Model/>
  
      
      </Box>
      </>
    );
  }
  }


function Action(props){

  const [state,setState]=useState(props.param)

  return(<>

{/* <Button type='button'  size='small' key={props} onClick={deleteProductdata({param:props.param})} >Edit</Button> */}
    {/* <Link to={{
      pathname:'/product/edit',
      state: props.param
    }} > Edit</Link> */}
    <Link key={props.key} to='/product/edit' state={{param:props.param}}><Button>Edit</Button></Link>  
    
  </>)
}


function Model(props){

  //  console.log( "modelprops==>",props)
   
    return(
      <>
     
        <div className="modal fade" id="exampleModalToggle1" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered  modal-lg">
          <div className="modal-content">
          <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLongTitle">Create {props.title}</h5>
              <div className="row ml-1" style={{ paddingTop: '2%'}}>
                  {/* <label><b>{props.params.any} Details</b></label> */}
              </div>
              <button type="button"   data-bs-dismiss="modal" className="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            
            <div className="modal-body m-body">
              
            <div className="row">
              
              <Products/>
  
            </div>
              
            {/* <div className="modal-footer">
                    
  
                    <Button data-bs-dismiss="modal" style={{ backgroundColor: 'rgb(108 110 116)',color:"#fff"}}>Close</Button>&nbsp;&nbsp;
                  
            
                    {/* <Button data-bs-dismiss="modal" style={{ backgroundColor: '#183883',color:"#fff"}} onClick={ submituser }>Submit</Button> 
                  
                  </div>*/}
            </div>  
  
            
          </div>
        </div>
        </div>
  
  
      </>
    )
  }