import React from "react";
import MaterialTextField from '../../../../Tags/MaterialTextField'
import MaterialButton from '../../../../Tags/MaterialButton';
import MaterialSelect from "../../../../Tags/MaterialSelect";
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import { Box, Divider } from '@mui/material';
import BreadCrumb from '../../BreadCrumb/BreadCrumb';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import DatePickers from '../../../../Tags/DatePicker'
import MaterialTextArea from '../../../../Tags/MaterialTextArea'
import Api from '../../../../api';
import { useParams } from 'react-router-dom';
import axios from "axios";
import Swal from "sweetalert2";
import { FileUploader } from "react-drag-drop-files";
export  class BasicInfo extends React.Component {
    constructor(props){
        super(props);
        this.state = {
          
            data:[]
        }
        this.apiCtrl = new Api;
        
      }

      componentDidUpdate(prevProps,prevState){
        if(prevProps.data.id !== this.props.data.id){
          console.log('Propps', this.props.data)
          this.setState(this.props.data)
        } 
       
      }
      componentDidMount(){
        this.setState(this.props.data)
        this.apiCtrl.callAxios('product/get-product-category').then(res => {
            // const array={}
             this.setState({data: res.data});
            
              
        })
      }
      
      render(){
        const fileTypes = ["JPG", "PNG", "GIF"];
        const type={
            "1":"Product",
            "2":"Service",
             "0":"Both"
        }

        const submitdata=(e)=>{
            e.preventDefault();
                      var data = new FormData();
                      if(Object.keys(this.state).length > 0){

                        Object.entries(this.state).map(([index, value])=>{
                            if(index !== "data"){
                                if(index === 'other_images'){

                                    value.map((val1, key1)=>{

                                        data.append(`${index}[]`, value[key1]);
                                    })
                                } else {
                                    data.append(`${index}`, value);
                                }
                            }
                        })
                    }

                    this.apiCtrl.callAxiosFile("product/create-product",data,true).then((response)=>{
        
            if(response.success === true){
                // console.log("response=>",response)
                 Swal.fire({
                  title: "Product",
                  text:"Updated",
                  icon: "success",
                  showConfirmButton: false,
              })
      
              } else {
                  Swal.fire({
                                title: "Product",
                                text: "Not Updated!",
                                icon: "error",
                                showConfirmButton: false,
                            })
              }
        })
       
    
      


      
          
      } 

      
      const handleChange = (file) => {
        console.log(file)
        Object.entries(file).map(([index, value])=>{

            this.setState(old=>({...old,other_images:[...old.other_images,value]}))
        })
         console.log("stae=>",this.state)
      };
        console.log("props=>",this.props)
        return(<>


            <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>

                <div className="row mb-3 ml-1">
                    <label><b>{"Product Basic Info"}</b></label>
                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />

                <div className="row ">

                    <div className='col-md-4'>
                
                    <MaterialSelect  
                     value={this.state.product_category_id?this.state.product_category_id:""}
                    data={this.state.data}  id="product_category_id" labelId="product-category-id" 
                    name="product_category_id"  label={"product Category"} fullWidth/>
                    </div>

                    <div className="col-md-4">
                    <MaterialSelect
                     name={"product_type"}
                     label={"Product Type"}                    
                      value={this.state.product_type?this.state.product_type:""}
                     data={type}
                     fullWidth
                     />

                    </div>

                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Product"} value={this.state.product?this.state.product:""} placeholder="Product"  fullWidth name='product' onChange={(e)=>this.setState({product : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Tally Name"} value={this.state.tally_name?this.state.tally_name:""} placeholder="Tally Name"  fullWidth name='tally_name' onChange={(e)=>this.setState({tally_name : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextArea multiline label={"Description" } value={this.state.description?this.state.description:""} placeholder=" Description" fullWidth name='description' onChange={(e)=>this.setState({description : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Base Price"} type={'number'} value={this.state.base_price?this.state.base_price:""} placeholder="Base Price"  fullWidth name='base_price' onChange={(e)=>this.setState({base_price : e.target.value})}/>
                    </div>

                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Base Uom" }  placeholder="Base Uom" value={this.state.base_uom?this.state.base_uom:""} fullWidth name='base_uom' onChange={(e)=>this.setState({base_uom : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Meta Keyword" }  placeholder="Meta Keyword" value={this.state.meta_keyword?this.state.meta_keyword:""}  fullWidth name='meta_keyword' onChange={(e)=>this.setState({meta_keyword : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Meta Title" } placeholder="Meta Title" value={this.state.meta_title?this.state.meta_title:""}  fullWidth name='meta_title' onChange={(e)=>this.setState({meta_title : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextArea multiline label={"Meta Description" } placeholder="Meta Description" value={this.state.meta_description?this.state.meta_description:""} fullWidth name='meta_description' onChange={(e)=>this.setState({meta_description : e.target.value})}/>
                    </div>
                    <div className="col-md-4 mb-4">
                    <MaterialTextField label={"Priority" } type={"number"} value={this.state.priority?this.state.priority:""} placeholder="Priority" fullWidth name='priority' onChange={(e)=>this.setState({priority : e.target.value})}/>
                    </div>
                  
                   
                    
                    <div className="col-md-4 mb-4">
                            <FormControlLabel control={<Checkbox checked={this.state.is_pack=="1"?true:false}    onChange={(e)=>this.setState({is_pack:e.target.checked?1:0})}/>} label={"Is Pack"} />
                    </div>
                    <div className="col-md-4 mb-4">
                            <FormControlLabel control={<Checkbox checked={this.state.show_on_website=="1"?true:false}    onChange={(e)=>this.setState({show_on_website:e.target.checked?1:0})}/>} label={"Show On Website"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox checked={this.state.is_sale=="1"?true:false}   onChange={(e)=>this.setState({is_sale:e.target.checked?1:0})}/>} label={"Is Sale"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox  checked={this.state.is_new=="1"?true:false}   onChange={(e)=>this.setState({is_new:e.target.checked?1:0})}/>} label={"Is New"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox  checked={this.state.is_gift=="1"?true:false}  onChange={(e)=>this.setState({is_gift:e.target.checked?1:0})}/>} label={"Is Gift"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox  checked={this.state.overall_stock_mgmt=="1"?true:false}  onChange={(e)=>this.setState({overall_stock_mgmt:e.target.checked?1:0})}/>} label={"Overall Stock Mgmt"} />
                    </div>
                    <div className="col-md-4 mb-4">
                    <FormControlLabel control={<Checkbox  checked={this.state.is_featured=="1"?true:false}   onChange={(e)=>this.setState({is_featured:e.target.checked?1:0})}/>} label={"Is Featured"} />
                    </div>
                   
                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />
                <div className="row mb-3 ml-1">
                    <label><b>{"Product Image"}</b></label>
                </div>

                <div className="row">
                    <div className="col-md-6">
                        <MaterialTextField type={"file"} onChange={(e)=>this.setState({banner_image:e.target.files[0]})} name="banner_image" label="Banner Image"/>

                    </div>
                    <div className="col-md-6">
                        <MaterialTextField type={"file"} onChange={(e)=>this.setState({featured_image:e.target.files[0]})} name="featured_image" label="Featured Image"/>

                    </div>
                    {this.state.banner_image!==""?
                    <div className="col-md-6 mb-2">
                    <img  style={{width:"58px",marginLeft:"2px"}} src={this.state.banner_image?this.state.banner_image:""} />
                    </div>:""
                     }
                      {this.state.featured_image!==""?
                    <div className="col-md-4 mb-2">
                    <img  style={{width:"58px",marginLeft:"2px"}} src={this.state.featured_image?this.state.featured_image:""} />
                    </div>:""
                     }

                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />
                <div className="row mt-3 ml-1">
                    <label><b>{"Other Images"}</b></label>
                </div>
                  
                <div className="row">
                <FileUploader handleChange={handleChange} multiple={true} name="other_image" types={fileTypes} />
                </div>

                <Divider sx={{ borderColor: '#dac4c4'}} />
                <div className="col-md-12 mb-4 d-flex"style={{justifyContent:"right",marginBottom:"auto"}}>
                <MaterialButton style={{ backgroundColor: '#183883' , marginTop: "14px", border: '1px solid #183883',height:55}}  onClick={submitdata} name="submit" text="Submit" />
                </div>
            </Box>

            
        </>)
      }
}