import React from "react";
import Api from "../../../../api";
import MaterialSelect from "../../../../Tags/MaterialSelect";
import MaterialTextField from "../../../../Tags/MaterialTextField";
import Button  from '@mui/material/Button';

import TextEditor from "../TextEditor/Text_Editor";
import MaterialButton from "../../../../Tags/MaterialButton";
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Box, Divider } from '@mui/material';
import BreadCrumb from '../../BreadCrumb/BreadCrumb';
import axios from "axios";
import Swal from "sweetalert2";
export default class TestiMonial extends React.Component{
    constructor(props){
        super(props);
        this.state = {    
            is_active:1
         
        }
        this.apiCtrl = new Api;
        
      }
     

      render(){

        const submitdata=(e)=>{
            e.preventDefault();
                      var data = new FormData();

                    //   data.append('name', this.state.name);
                    
                    Object.entries(this.state).map(([index, value])=>{
                        // console.log('key', index)
                        // console.log('Value', value)
                        data.append(`${index}`, value);
                    })
                    // if(Object.keys(this.state).length > 0){
                    // }
                    //   data.append('description', this.state.description);                  
                    //   data.append('image', this.state.image);
                    //   data.append('is_active', this.state.is_active)
                    //   data.append("priority",this.state.priority)
                   
                    console.log('DATA',this.state)
                    this.apiCtrl.callAxiosFile("testimonial/create-update",data,true).then((res)=>{
                        if(res.success   === true){
                                      // console.log("response=>",response)
                                       Swal.fire({
                                        title: "TestiMonial",
                                        text:"Created",
                                        icon: "success",
                                        showConfirmButton: false,
                                    })
                            
                                    } else {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Oops...',
                                        text: 'Something went wrong!',
                                    
                                    })
                                    }
                    })
                   
      
      } 
  
        

        const ImageUpload=(e)=>{
            
           this.setState(old=>({...old,image:e.target.files[0]}))

        
        }

        const onhandlechange =({val})=>{
            // console.log("val=>",val)
             this.setState(old=>({...old,description:val}))
           }
        return(
            <>

                <BreadCrumb breadcrumb={"TestiMonial"} breadcrumbItem1='Create' />

                <Box sx={{ width: '100%', height: '100%', typography: 'body1', backgroundColor:'white', borderRadius:"6px", padding: '2%' }}>

                    <div className="row ml-1">
                        <label><b>{"TestiMonial"}</b></label>
                    </div>

                    <Divider sx={{ borderColor: '#dac4c4'}} />

                    <div className="row mt-3">
                        {/* <div className="col-md-3 mb-2">
                            <MaterialTextField name="name" label="Name" fullWidth onChange={(e)=>this.setState({name : e.target.value})}/>
                             
                        </div> */}
                        <div className="col-md-3 mb-2">
                            <MaterialTextField name="title" label="Title" fullWidth onChange={(e)=>this.setState({title : e.target.value})}/>
                             
                        </div>
                        <div className="col-md-3 mb-2">
                            <MaterialTextField name="priority" label="Priority" fullWidth onChange={(e)=>this.setState({priority : e.target.value})}/>
                             
                        </div>

                        <div className="col-md-3 mb-2">
                            <MaterialTextField type="file" name="image" label="Image"  fullWidth onChange={(e)=>ImageUpload(e)}/>
                             
                        </div>
                        <div className="col-md-4 mb-4">
                            <FormControlLabel control={<Checkbox checked={this.state.is_active=="1"?true:false} onChange={(e)=>this.setState({is_active:e.target.checked?1:0})}/>}   label={"Enable" } />
                        </div>
                        <strong>Description</strong>
                        <div style={{ border: "1px solid black", padding: '2px', minHeight: '400px' }}>
                        
                            <TextEditor func={onhandlechange}/>
                        
                
                        </div>

                    </div>
                    <Divider sx={{ borderColor: '#dac4c4'}} />
                    <div className='row mt-3'>
                    
                        <div className="col-md-3">
                            <Button style={{ backgroundColor: '#183883' }} onClick={ submitdata }>Submit</Button>
                        </div>
                    </div>
                </Box>
                            
            
            
            </>
        )
      }
}