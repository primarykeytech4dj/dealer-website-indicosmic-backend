import React from 'react'


function About_us() {
  return (
    <div>
      <h1>Hello About</h1>
    </div>
  )
}

export default About_us