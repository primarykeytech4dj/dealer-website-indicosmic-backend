export const websiteJson = 'Website.json';
export const productsJson = 'Products.json';
export const AboutusJson = 'Aboutus.json';

// Website related Constants
export const HomeJson = 'Home.json';